<?php exit(); ?>

<!--             2025-10-26 09:00:53             -->

<!--  **    SAVE THIS FILE AS hoteld_backup.php     **  -->

<!--  **  SALVA QUESTO FILE COME hoteld_backup.php  **  -->


<backup>
<versione>3.07</versione>
<log>NO</log>
<file>
<nomefile>./dati/lingua.php</nomefile>
<contenuto>
<?php
$lingua[1] = "es";
?></contenuto>
</file>
<file>
<nomefile>./dati/unit.php</nomefile>
<contenuto>
<?php
$unit['s_n'] = $trad_var['room'];
$unit['p_n'] = $trad_var['rooms'];
$unit['gender'] = $trad_var['room_gender'];
$unit['special'] = 0;
$car_spec = explode(",",$trad_var['special_characters']);
for ($num1 = 0 ; $num1 < count($car_spec) ; $num1++) if (substr($unit['p_n'],0,strlen($car_spec[$num1])) == $car_spec[$num1]) $unit['special'] = 1;
?></contenuto>
</file>
<file>
<nomefile>./dati/unit_single.php</nomefile>
<contenuto>
<?php
$unit['s_n'] = $trad_var['bed'];
$unit['p_n'] = $trad_var['beds'];
$unit['gender'] = $trad_var['bed_gender'];
$unit['special'] = 0;
$car_spec = explode(",",$trad_var['special_characters']);
for ($num1 = 0 ; $num1 < count($car_spec) ; $num1++) if (substr($unit['p_n'],0,strlen($car_spec[$num1])) == $car_spec[$num1]) $unit['special'] = 1;
?></contenuto>
</file>
<file>
<nomefile>./dati/tema.php</nomefile>
<contenuto>
<?php
$parole_sost = 0;
$tema[1] = "blu";
?></contenuto>
</file>
<file>
<nomefile>./dati/selectappartamenti.php</nomefile>
<contenuto>
<?php 
echo '
<option value="15">15</option>
<option value="16">16</option>
<option value="18">18</option>
<option value="20">20</option>
<option value="21">21</option>
<option value="22">22</option>
<option value="23">23</option>
<option value="24">24</option>
<option value="25">25</option>
<option value="26">26</option>
<option value="27">27</option>
<option value="28">28</option>
<option value="29">29</option>
<option value="30">30</option>
<option value="31">31</option>
<option value="32">32</option>
<option value="33">33</option>
<option value="34">34</option>
<option value="35">35</option>
<option value="36">36</option>
<option value="37">37</option>
<option value="38">38</option>
<option value="39">39</option>
<option value="40">40</option>
<option value="41">41</option>
<option value="42">42</option>
<option value="43">43</option>
<option value="44">44</option>
<option value="45">45</option>
<option value="46">46</option>
<option value="201">201</option>
<option value="202">202</option>
<option value="203">203</option>
<option value="204">204</option>
<option value="205">205</option>
<option value="206">206</option>
<option value="207">207</option>
<option value="208">208</option>
<option value="209">209</option>
<option value="210">210</option>
<option value="211">211</option>
';
?></contenuto>
</file>
<file>
<nomefile>./dati/versione.php</nomefile>
<contenuto>
<?php
define('C_VERSIONE_ATTUALE',3.07);
define('C_DIFF_ORE',0);
define('C_MIN_SESSIONE',90);
define('C_USA_COOKIES',0);
?></contenuto>
</file>
<file>
<nomefile>./dati/selectperiodi2025.1.php</nomefile>
<contenuto>
<?php 

$y_ini_menu = array();
$m_ini_menu = array();
$d_ini_menu = array();
$n_dates_menu = array();
$d_increment = array();
$y_ini_menu[0] = "2025";
$m_ini_menu[0] = "0";
$d_ini_menu[0] = "01";
$n_dates_menu[0] = "731";
$d_increment[0] = "1";
$d_names = "\" Do\",\" Lu\",\" Ma\",\" Mi\",\" Ju\",\" Vi\",\" Sá\"";
$m_names = "\"Ene\",\"Feb\",\"Mar\",\"Abr\",\"May\",\"Jun\",\"Jul\",\"Ago\",\"Sep\",\"Oct\",\"Nov\",\"Dic\"";

$dates_options_list = "

<option value=\"2025-01-01\">Ene 01 Mi, 2025</option>
<option value=\"2025-01-02\">Ene 02 Ju, 2025</option>
<option value=\"2025-01-03\">Ene 03 Vi, 2025</option>
<option value=\"2025-01-04\">Ene 04 Sá, 2025</option>
<option value=\"2025-01-05\">Ene 05 Do, 2025</option>
<option value=\"2025-01-06\">Ene 06 Lu, 2025</option>
<option value=\"2025-01-07\">Ene 07 Ma, 2025</option>
<option value=\"2025-01-08\">Ene 08 Mi, 2025</option>
<option value=\"2025-01-09\">Ene 09 Ju, 2025</option>
<option value=\"2025-01-10\">Ene 10 Vi, 2025</option>
<option value=\"2025-01-11\">Ene 11 Sá, 2025</option>
<option value=\"2025-01-12\">Ene 12 Do, 2025</option>
<option value=\"2025-01-13\">Ene 13 Lu, 2025</option>
<option value=\"2025-01-14\">Ene 14 Ma, 2025</option>
<option value=\"2025-01-15\">Ene 15 Mi, 2025</option>
<option value=\"2025-01-16\">Ene 16 Ju, 2025</option>
<option value=\"2025-01-17\">Ene 17 Vi, 2025</option>
<option value=\"2025-01-18\">Ene 18 Sá, 2025</option>
<option value=\"2025-01-19\">Ene 19 Do, 2025</option>
<option value=\"2025-01-20\">Ene 20 Lu, 2025</option>
<option value=\"2025-01-21\">Ene 21 Ma, 2025</option>
<option value=\"2025-01-22\">Ene 22 Mi, 2025</option>
<option value=\"2025-01-23\">Ene 23 Ju, 2025</option>
<option value=\"2025-01-24\">Ene 24 Vi, 2025</option>
<option value=\"2025-01-25\">Ene 25 Sá, 2025</option>
<option value=\"2025-01-26\">Ene 26 Do, 2025</option>
<option value=\"2025-01-27\">Ene 27 Lu, 2025</option>
<option value=\"2025-01-28\">Ene 28 Ma, 2025</option>
<option value=\"2025-01-29\">Ene 29 Mi, 2025</option>
<option value=\"2025-01-30\">Ene 30 Ju, 2025</option>
<option value=\"2025-01-31\">Ene 31 Vi, 2025</option>
<option value=\"2025-02-01\">Feb 01 Sá, 2025</option>
<option value=\"2025-02-02\">Feb 02 Do, 2025</option>
<option value=\"2025-02-03\">Feb 03 Lu, 2025</option>
<option value=\"2025-02-04\">Feb 04 Ma, 2025</option>
<option value=\"2025-02-05\">Feb 05 Mi, 2025</option>
<option value=\"2025-02-06\">Feb 06 Ju, 2025</option>
<option value=\"2025-02-07\">Feb 07 Vi, 2025</option>
<option value=\"2025-02-08\">Feb 08 Sá, 2025</option>
<option value=\"2025-02-09\">Feb 09 Do, 2025</option>
<option value=\"2025-02-10\">Feb 10 Lu, 2025</option>
<option value=\"2025-02-11\">Feb 11 Ma, 2025</option>
<option value=\"2025-02-12\">Feb 12 Mi, 2025</option>
<option value=\"2025-02-13\">Feb 13 Ju, 2025</option>
<option value=\"2025-02-14\">Feb 14 Vi, 2025</option>
<option value=\"2025-02-15\">Feb 15 Sá, 2025</option>
<option value=\"2025-02-16\">Feb 16 Do, 2025</option>
<option value=\"2025-02-17\">Feb 17 Lu, 2025</option>
<option value=\"2025-02-18\">Feb 18 Ma, 2025</option>
<option value=\"2025-02-19\">Feb 19 Mi, 2025</option>
<option value=\"2025-02-20\">Feb 20 Ju, 2025</option>
<option value=\"2025-02-21\">Feb 21 Vi, 2025</option>
<option value=\"2025-02-22\">Feb 22 Sá, 2025</option>
<option value=\"2025-02-23\">Feb 23 Do, 2025</option>
<option value=\"2025-02-24\">Feb 24 Lu, 2025</option>
<option value=\"2025-02-25\">Feb 25 Ma, 2025</option>
<option value=\"2025-02-26\">Feb 26 Mi, 2025</option>
<option value=\"2025-02-27\">Feb 27 Ju, 2025</option>
<option value=\"2025-02-28\">Feb 28 Vi, 2025</option>
<option value=\"2025-03-01\">Mar 01 Sá, 2025</option>
<option value=\"2025-03-02\">Mar 02 Do, 2025</option>
<option value=\"2025-03-03\">Mar 03 Lu, 2025</option>
<option value=\"2025-03-04\">Mar 04 Ma, 2025</option>
<option value=\"2025-03-05\">Mar 05 Mi, 2025</option>
<option value=\"2025-03-06\">Mar 06 Ju, 2025</option>
<option value=\"2025-03-07\">Mar 07 Vi, 2025</option>
<option value=\"2025-03-08\">Mar 08 Sá, 2025</option>
<option value=\"2025-03-09\">Mar 09 Do, 2025</option>
<option value=\"2025-03-10\">Mar 10 Lu, 2025</option>
<option value=\"2025-03-11\">Mar 11 Ma, 2025</option>
<option value=\"2025-03-12\">Mar 12 Mi, 2025</option>
<option value=\"2025-03-13\">Mar 13 Ju, 2025</option>
<option value=\"2025-03-14\">Mar 14 Vi, 2025</option>
<option value=\"2025-03-15\">Mar 15 Sá, 2025</option>
<option value=\"2025-03-16\">Mar 16 Do, 2025</option>
<option value=\"2025-03-17\">Mar 17 Lu, 2025</option>
<option value=\"2025-03-18\">Mar 18 Ma, 2025</option>
<option value=\"2025-03-19\">Mar 19 Mi, 2025</option>
<option value=\"2025-03-20\">Mar 20 Ju, 2025</option>
<option value=\"2025-03-21\">Mar 21 Vi, 2025</option>
<option value=\"2025-03-22\">Mar 22 Sá, 2025</option>
<option value=\"2025-03-23\">Mar 23 Do, 2025</option>
<option value=\"2025-03-24\">Mar 24 Lu, 2025</option>
<option value=\"2025-03-25\">Mar 25 Ma, 2025</option>
<option value=\"2025-03-26\">Mar 26 Mi, 2025</option>
<option value=\"2025-03-27\">Mar 27 Ju, 2025</option>
<option value=\"2025-03-28\">Mar 28 Vi, 2025</option>
<option value=\"2025-03-29\">Mar 29 Sá, 2025</option>
<option value=\"2025-03-30\">Mar 30 Do, 2025</option>
<option value=\"2025-03-31\">Mar 31 Lu, 2025</option>
<option value=\"2025-04-01\">Abr 01 Ma, 2025</option>
<option value=\"2025-04-02\">Abr 02 Mi, 2025</option>
<option value=\"2025-04-03\">Abr 03 Ju, 2025</option>
<option value=\"2025-04-04\">Abr 04 Vi, 2025</option>
<option value=\"2025-04-05\">Abr 05 Sá, 2025</option>
<option value=\"2025-04-06\">Abr 06 Do, 2025</option>
<option value=\"2025-04-07\">Abr 07 Lu, 2025</option>
<option value=\"2025-04-08\">Abr 08 Ma, 2025</option>
<option value=\"2025-04-09\">Abr 09 Mi, 2025</option>
<option value=\"2025-04-10\">Abr 10 Ju, 2025</option>
<option value=\"2025-04-11\">Abr 11 Vi, 2025</option>
<option value=\"2025-04-12\">Abr 12 Sá, 2025</option>
<option value=\"2025-04-13\">Abr 13 Do, 2025</option>
<option value=\"2025-04-14\">Abr 14 Lu, 2025</option>
<option value=\"2025-04-15\">Abr 15 Ma, 2025</option>
<option value=\"2025-04-16\">Abr 16 Mi, 2025</option>
<option value=\"2025-04-17\">Abr 17 Ju, 2025</option>
<option value=\"2025-04-18\">Abr 18 Vi, 2025</option>
<option value=\"2025-04-19\">Abr 19 Sá, 2025</option>
<option value=\"2025-04-20\">Abr 20 Do, 2025</option>
<option value=\"2025-04-21\">Abr 21 Lu, 2025</option>
<option value=\"2025-04-22\">Abr 22 Ma, 2025</option>
<option value=\"2025-04-23\">Abr 23 Mi, 2025</option>
<option value=\"2025-04-24\">Abr 24 Ju, 2025</option>
<option value=\"2025-04-25\">Abr 25 Vi, 2025</option>
<option value=\"2025-04-26\">Abr 26 Sá, 2025</option>
<option value=\"2025-04-27\">Abr 27 Do, 2025</option>
<option value=\"2025-04-28\">Abr 28 Lu, 2025</option>
<option value=\"2025-04-29\">Abr 29 Ma, 2025</option>
<option value=\"2025-04-30\">Abr 30 Mi, 2025</option>
<option value=\"2025-05-01\">May 01 Ju, 2025</option>
<option value=\"2025-05-02\">May 02 Vi, 2025</option>
<option value=\"2025-05-03\">May 03 Sá, 2025</option>
<option value=\"2025-05-04\">May 04 Do, 2025</option>
<option value=\"2025-05-05\">May 05 Lu, 2025</option>
<option value=\"2025-05-06\">May 06 Ma, 2025</option>
<option value=\"2025-05-07\">May 07 Mi, 2025</option>
<option value=\"2025-05-08\">May 08 Ju, 2025</option>
<option value=\"2025-05-09\">May 09 Vi, 2025</option>
<option value=\"2025-05-10\">May 10 Sá, 2025</option>
<option value=\"2025-05-11\">May 11 Do, 2025</option>
<option value=\"2025-05-12\">May 12 Lu, 2025</option>
<option value=\"2025-05-13\">May 13 Ma, 2025</option>
<option value=\"2025-05-14\">May 14 Mi, 2025</option>
<option value=\"2025-05-15\">May 15 Ju, 2025</option>
<option value=\"2025-05-16\">May 16 Vi, 2025</option>
<option value=\"2025-05-17\">May 17 Sá, 2025</option>
<option value=\"2025-05-18\">May 18 Do, 2025</option>
<option value=\"2025-05-19\">May 19 Lu, 2025</option>
<option value=\"2025-05-20\">May 20 Ma, 2025</option>
<option value=\"2025-05-21\">May 21 Mi, 2025</option>
<option value=\"2025-05-22\">May 22 Ju, 2025</option>
<option value=\"2025-05-23\">May 23 Vi, 2025</option>
<option value=\"2025-05-24\">May 24 Sá, 2025</option>
<option value=\"2025-05-25\">May 25 Do, 2025</option>
<option value=\"2025-05-26\">May 26 Lu, 2025</option>
<option value=\"2025-05-27\">May 27 Ma, 2025</option>
<option value=\"2025-05-28\">May 28 Mi, 2025</option>
<option value=\"2025-05-29\">May 29 Ju, 2025</option>
<option value=\"2025-05-30\">May 30 Vi, 2025</option>
<option value=\"2025-05-31\">May 31 Sá, 2025</option>
<option value=\"2025-06-01\">Jun 01 Do, 2025</option>
<option value=\"2025-06-02\">Jun 02 Lu, 2025</option>
<option value=\"2025-06-03\">Jun 03 Ma, 2025</option>
<option value=\"2025-06-04\">Jun 04 Mi, 2025</option>
<option value=\"2025-06-05\">Jun 05 Ju, 2025</option>
<option value=\"2025-06-06\">Jun 06 Vi, 2025</option>
<option value=\"2025-06-07\">Jun 07 Sá, 2025</option>
<option value=\"2025-06-08\">Jun 08 Do, 2025</option>
<option value=\"2025-06-09\">Jun 09 Lu, 2025</option>
<option value=\"2025-06-10\">Jun 10 Ma, 2025</option>
<option value=\"2025-06-11\">Jun 11 Mi, 2025</option>
<option value=\"2025-06-12\">Jun 12 Ju, 2025</option>
<option value=\"2025-06-13\">Jun 13 Vi, 2025</option>
<option value=\"2025-06-14\">Jun 14 Sá, 2025</option>
<option value=\"2025-06-15\">Jun 15 Do, 2025</option>
<option value=\"2025-06-16\">Jun 16 Lu, 2025</option>
<option value=\"2025-06-17\">Jun 17 Ma, 2025</option>
<option value=\"2025-06-18\">Jun 18 Mi, 2025</option>
<option value=\"2025-06-19\">Jun 19 Ju, 2025</option>
<option value=\"2025-06-20\">Jun 20 Vi, 2025</option>
<option value=\"2025-06-21\">Jun 21 Sá, 2025</option>
<option value=\"2025-06-22\">Jun 22 Do, 2025</option>
<option value=\"2025-06-23\">Jun 23 Lu, 2025</option>
<option value=\"2025-06-24\">Jun 24 Ma, 2025</option>
<option value=\"2025-06-25\">Jun 25 Mi, 2025</option>
<option value=\"2025-06-26\">Jun 26 Ju, 2025</option>
<option value=\"2025-06-27\">Jun 27 Vi, 2025</option>
<option value=\"2025-06-28\">Jun 28 Sá, 2025</option>
<option value=\"2025-06-29\">Jun 29 Do, 2025</option>
<option value=\"2025-06-30\">Jun 30 Lu, 2025</option>
<option value=\"2025-07-01\">Jul 01 Ma, 2025</option>
<option value=\"2025-07-02\">Jul 02 Mi, 2025</option>
<option value=\"2025-07-03\">Jul 03 Ju, 2025</option>
<option value=\"2025-07-04\">Jul 04 Vi, 2025</option>
<option value=\"2025-07-05\">Jul 05 Sá, 2025</option>
<option value=\"2025-07-06\">Jul 06 Do, 2025</option>
<option value=\"2025-07-07\">Jul 07 Lu, 2025</option>
<option value=\"2025-07-08\">Jul 08 Ma, 2025</option>
<option value=\"2025-07-09\">Jul 09 Mi, 2025</option>
<option value=\"2025-07-10\">Jul 10 Ju, 2025</option>
<option value=\"2025-07-11\">Jul 11 Vi, 2025</option>
<option value=\"2025-07-12\">Jul 12 Sá, 2025</option>
<option value=\"2025-07-13\">Jul 13 Do, 2025</option>
<option value=\"2025-07-14\">Jul 14 Lu, 2025</option>
<option value=\"2025-07-15\">Jul 15 Ma, 2025</option>
<option value=\"2025-07-16\">Jul 16 Mi, 2025</option>
<option value=\"2025-07-17\">Jul 17 Ju, 2025</option>
<option value=\"2025-07-18\">Jul 18 Vi, 2025</option>
<option value=\"2025-07-19\">Jul 19 Sá, 2025</option>
<option value=\"2025-07-20\">Jul 20 Do, 2025</option>
<option value=\"2025-07-21\">Jul 21 Lu, 2025</option>
<option value=\"2025-07-22\">Jul 22 Ma, 2025</option>
<option value=\"2025-07-23\">Jul 23 Mi, 2025</option>
<option value=\"2025-07-24\">Jul 24 Ju, 2025</option>
<option value=\"2025-07-25\">Jul 25 Vi, 2025</option>
<option value=\"2025-07-26\">Jul 26 Sá, 2025</option>
<option value=\"2025-07-27\">Jul 27 Do, 2025</option>
<option value=\"2025-07-28\">Jul 28 Lu, 2025</option>
<option value=\"2025-07-29\">Jul 29 Ma, 2025</option>
<option value=\"2025-07-30\">Jul 30 Mi, 2025</option>
<option value=\"2025-07-31\">Jul 31 Ju, 2025</option>
<option value=\"2025-08-01\">Ago 01 Vi, 2025</option>
<option value=\"2025-08-02\">Ago 02 Sá, 2025</option>
<option value=\"2025-08-03\">Ago 03 Do, 2025</option>
<option value=\"2025-08-04\">Ago 04 Lu, 2025</option>
<option value=\"2025-08-05\">Ago 05 Ma, 2025</option>
<option value=\"2025-08-06\">Ago 06 Mi, 2025</option>
<option value=\"2025-08-07\">Ago 07 Ju, 2025</option>
<option value=\"2025-08-08\">Ago 08 Vi, 2025</option>
<option value=\"2025-08-09\">Ago 09 Sá, 2025</option>
<option value=\"2025-08-10\">Ago 10 Do, 2025</option>
<option value=\"2025-08-11\">Ago 11 Lu, 2025</option>
<option value=\"2025-08-12\">Ago 12 Ma, 2025</option>
<option value=\"2025-08-13\">Ago 13 Mi, 2025</option>
<option value=\"2025-08-14\">Ago 14 Ju, 2025</option>
<option value=\"2025-08-15\">Ago 15 Vi, 2025</option>
<option value=\"2025-08-16\">Ago 16 Sá, 2025</option>
<option value=\"2025-08-17\">Ago 17 Do, 2025</option>
<option value=\"2025-08-18\">Ago 18 Lu, 2025</option>
<option value=\"2025-08-19\">Ago 19 Ma, 2025</option>
<option value=\"2025-08-20\">Ago 20 Mi, 2025</option>
<option value=\"2025-08-21\">Ago 21 Ju, 2025</option>
<option value=\"2025-08-22\">Ago 22 Vi, 2025</option>
<option value=\"2025-08-23\">Ago 23 Sá, 2025</option>
<option value=\"2025-08-24\">Ago 24 Do, 2025</option>
<option value=\"2025-08-25\">Ago 25 Lu, 2025</option>
<option value=\"2025-08-26\">Ago 26 Ma, 2025</option>
<option value=\"2025-08-27\">Ago 27 Mi, 2025</option>
<option value=\"2025-08-28\">Ago 28 Ju, 2025</option>
<option value=\"2025-08-29\">Ago 29 Vi, 2025</option>
<option value=\"2025-08-30\">Ago 30 Sá, 2025</option>
<option value=\"2025-08-31\">Ago 31 Do, 2025</option>
<option value=\"2025-09-01\">Sep 01 Lu, 2025</option>
<option value=\"2025-09-02\">Sep 02 Ma, 2025</option>
<option value=\"2025-09-03\">Sep 03 Mi, 2025</option>
<option value=\"2025-09-04\">Sep 04 Ju, 2025</option>
<option value=\"2025-09-05\">Sep 05 Vi, 2025</option>
<option value=\"2025-09-06\">Sep 06 Sá, 2025</option>
<option value=\"2025-09-07\">Sep 07 Do, 2025</option>
<option value=\"2025-09-08\">Sep 08 Lu, 2025</option>
<option value=\"2025-09-09\">Sep 09 Ma, 2025</option>
<option value=\"2025-09-10\">Sep 10 Mi, 2025</option>
<option value=\"2025-09-11\">Sep 11 Ju, 2025</option>
<option value=\"2025-09-12\">Sep 12 Vi, 2025</option>
<option value=\"2025-09-13\">Sep 13 Sá, 2025</option>
<option value=\"2025-09-14\">Sep 14 Do, 2025</option>
<option value=\"2025-09-15\">Sep 15 Lu, 2025</option>
<option value=\"2025-09-16\">Sep 16 Ma, 2025</option>
<option value=\"2025-09-17\">Sep 17 Mi, 2025</option>
<option value=\"2025-09-18\">Sep 18 Ju, 2025</option>
<option value=\"2025-09-19\">Sep 19 Vi, 2025</option>
<option value=\"2025-09-20\">Sep 20 Sá, 2025</option>
<option value=\"2025-09-21\">Sep 21 Do, 2025</option>
<option value=\"2025-09-22\">Sep 22 Lu, 2025</option>
<option value=\"2025-09-23\">Sep 23 Ma, 2025</option>
<option value=\"2025-09-24\">Sep 24 Mi, 2025</option>
<option value=\"2025-09-25\">Sep 25 Ju, 2025</option>
<option value=\"2025-09-26\">Sep 26 Vi, 2025</option>
<option value=\"2025-09-27\">Sep 27 Sá, 2025</option>
<option value=\"2025-09-28\">Sep 28 Do, 2025</option>
<option value=\"2025-09-29\">Sep 29 Lu, 2025</option>
<option value=\"2025-09-30\">Sep 30 Ma, 2025</option>
<option value=\"2025-10-01\">Oct 01 Mi, 2025</option>
<option value=\"2025-10-02\">Oct 02 Ju, 2025</option>
<option value=\"2025-10-03\">Oct 03 Vi, 2025</option>
<option value=\"2025-10-04\">Oct 04 Sá, 2025</option>
<option value=\"2025-10-05\">Oct 05 Do, 2025</option>
<option value=\"2025-10-06\">Oct 06 Lu, 2025</option>
<option value=\"2025-10-07\">Oct 07 Ma, 2025</option>
<option value=\"2025-10-08\">Oct 08 Mi, 2025</option>
<option value=\"2025-10-09\">Oct 09 Ju, 2025</option>
<option value=\"2025-10-10\">Oct 10 Vi, 2025</option>
<option value=\"2025-10-11\">Oct 11 Sá, 2025</option>
<option value=\"2025-10-12\">Oct 12 Do, 2025</option>
<option value=\"2025-10-13\">Oct 13 Lu, 2025</option>
<option value=\"2025-10-14\">Oct 14 Ma, 2025</option>
<option value=\"2025-10-15\">Oct 15 Mi, 2025</option>
<option value=\"2025-10-16\">Oct 16 Ju, 2025</option>
<option value=\"2025-10-17\">Oct 17 Vi, 2025</option>
<option value=\"2025-10-18\">Oct 18 Sá, 2025</option>
<option value=\"2025-10-19\">Oct 19 Do, 2025</option>
<option value=\"2025-10-20\">Oct 20 Lu, 2025</option>
<option value=\"2025-10-21\">Oct 21 Ma, 2025</option>
<option value=\"2025-10-22\">Oct 22 Mi, 2025</option>
<option value=\"2025-10-23\">Oct 23 Ju, 2025</option>
<option value=\"2025-10-24\">Oct 24 Vi, 2025</option>
<option value=\"2025-10-25\">Oct 25 Sá, 2025</option>
<option value=\"2025-10-26\">Oct 26 Do, 2025</option>
<option value=\"2025-10-27\">Oct 27 Lu, 2025</option>
<option value=\"2025-10-28\">Oct 28 Ma, 2025</option>
<option value=\"2025-10-29\">Oct 29 Mi, 2025</option>
<option value=\"2025-10-30\">Oct 30 Ju, 2025</option>
<option value=\"2025-10-31\">Oct 31 Vi, 2025</option>
<option value=\"2025-11-01\">Nov 01 Sá, 2025</option>
<option value=\"2025-11-02\">Nov 02 Do, 2025</option>
<option value=\"2025-11-03\">Nov 03 Lu, 2025</option>
<option value=\"2025-11-04\">Nov 04 Ma, 2025</option>
<option value=\"2025-11-05\">Nov 05 Mi, 2025</option>
<option value=\"2025-11-06\">Nov 06 Ju, 2025</option>
<option value=\"2025-11-07\">Nov 07 Vi, 2025</option>
<option value=\"2025-11-08\">Nov 08 Sá, 2025</option>
<option value=\"2025-11-09\">Nov 09 Do, 2025</option>
<option value=\"2025-11-10\">Nov 10 Lu, 2025</option>
<option value=\"2025-11-11\">Nov 11 Ma, 2025</option>
<option value=\"2025-11-12\">Nov 12 Mi, 2025</option>
<option value=\"2025-11-13\">Nov 13 Ju, 2025</option>
<option value=\"2025-11-14\">Nov 14 Vi, 2025</option>
<option value=\"2025-11-15\">Nov 15 Sá, 2025</option>
<option value=\"2025-11-16\">Nov 16 Do, 2025</option>
<option value=\"2025-11-17\">Nov 17 Lu, 2025</option>
<option value=\"2025-11-18\">Nov 18 Ma, 2025</option>
<option value=\"2025-11-19\">Nov 19 Mi, 2025</option>
<option value=\"2025-11-20\">Nov 20 Ju, 2025</option>
<option value=\"2025-11-21\">Nov 21 Vi, 2025</option>
<option value=\"2025-11-22\">Nov 22 Sá, 2025</option>
<option value=\"2025-11-23\">Nov 23 Do, 2025</option>
<option value=\"2025-11-24\">Nov 24 Lu, 2025</option>
<option value=\"2025-11-25\">Nov 25 Ma, 2025</option>
<option value=\"2025-11-26\">Nov 26 Mi, 2025</option>
<option value=\"2025-11-27\">Nov 27 Ju, 2025</option>
<option value=\"2025-11-28\">Nov 28 Vi, 2025</option>
<option value=\"2025-11-29\">Nov 29 Sá, 2025</option>
<option value=\"2025-11-30\">Nov 30 Do, 2025</option>
<option value=\"2025-12-01\">Dic 01 Lu, 2025</option>
<option value=\"2025-12-02\">Dic 02 Ma, 2025</option>
<option value=\"2025-12-03\">Dic 03 Mi, 2025</option>
<option value=\"2025-12-04\">Dic 04 Ju, 2025</option>
<option value=\"2025-12-05\">Dic 05 Vi, 2025</option>
<option value=\"2025-12-06\">Dic 06 Sá, 2025</option>
<option value=\"2025-12-07\">Dic 07 Do, 2025</option>
<option value=\"2025-12-08\">Dic 08 Lu, 2025</option>
<option value=\"2025-12-09\">Dic 09 Ma, 2025</option>
<option value=\"2025-12-10\">Dic 10 Mi, 2025</option>
<option value=\"2025-12-11\">Dic 11 Ju, 2025</option>
<option value=\"2025-12-12\">Dic 12 Vi, 2025</option>
<option value=\"2025-12-13\">Dic 13 Sá, 2025</option>
<option value=\"2025-12-14\">Dic 14 Do, 2025</option>
<option value=\"2025-12-15\">Dic 15 Lu, 2025</option>
<option value=\"2025-12-16\">Dic 16 Ma, 2025</option>
<option value=\"2025-12-17\">Dic 17 Mi, 2025</option>
<option value=\"2025-12-18\">Dic 18 Ju, 2025</option>
<option value=\"2025-12-19\">Dic 19 Vi, 2025</option>
<option value=\"2025-12-20\">Dic 20 Sá, 2025</option>
<option value=\"2025-12-21\">Dic 21 Do, 2025</option>
<option value=\"2025-12-22\">Dic 22 Lu, 2025</option>
<option value=\"2025-12-23\">Dic 23 Ma, 2025</option>
<option value=\"2025-12-24\">Dic 24 Mi, 2025</option>
<option value=\"2025-12-25\">Dic 25 Ju, 2025</option>
<option value=\"2025-12-26\">Dic 26 Vi, 2025</option>
<option value=\"2025-12-27\">Dic 27 Sá, 2025</option>
<option value=\"2025-12-28\">Dic 28 Do, 2025</option>
<option value=\"2025-12-29\">Dic 29 Lu, 2025</option>
<option value=\"2025-12-30\">Dic 30 Ma, 2025</option>
<option value=\"2025-12-31\">Dic 31 Mi, 2025</option>
<option value=\"2026-01-01\">Ene 01 Ju, 2026</option>
<option value=\"2026-01-02\">Ene 02 Vi, 2026</option>
<option value=\"2026-01-03\">Ene 03 Sá, 2026</option>
<option value=\"2026-01-04\">Ene 04 Do, 2026</option>
<option value=\"2026-01-05\">Ene 05 Lu, 2026</option>
<option value=\"2026-01-06\">Ene 06 Ma, 2026</option>
<option value=\"2026-01-07\">Ene 07 Mi, 2026</option>
<option value=\"2026-01-08\">Ene 08 Ju, 2026</option>
<option value=\"2026-01-09\">Ene 09 Vi, 2026</option>
<option value=\"2026-01-10\">Ene 10 Sá, 2026</option>
<option value=\"2026-01-11\">Ene 11 Do, 2026</option>
<option value=\"2026-01-12\">Ene 12 Lu, 2026</option>
<option value=\"2026-01-13\">Ene 13 Ma, 2026</option>
<option value=\"2026-01-14\">Ene 14 Mi, 2026</option>
<option value=\"2026-01-15\">Ene 15 Ju, 2026</option>
<option value=\"2026-01-16\">Ene 16 Vi, 2026</option>
<option value=\"2026-01-17\">Ene 17 Sá, 2026</option>
<option value=\"2026-01-18\">Ene 18 Do, 2026</option>
<option value=\"2026-01-19\">Ene 19 Lu, 2026</option>
<option value=\"2026-01-20\">Ene 20 Ma, 2026</option>
<option value=\"2026-01-21\">Ene 21 Mi, 2026</option>
<option value=\"2026-01-22\">Ene 22 Ju, 2026</option>
<option value=\"2026-01-23\">Ene 23 Vi, 2026</option>
<option value=\"2026-01-24\">Ene 24 Sá, 2026</option>
<option value=\"2026-01-25\">Ene 25 Do, 2026</option>
<option value=\"2026-01-26\">Ene 26 Lu, 2026</option>
<option value=\"2026-01-27\">Ene 27 Ma, 2026</option>
<option value=\"2026-01-28\">Ene 28 Mi, 2026</option>
<option value=\"2026-01-29\">Ene 29 Ju, 2026</option>
<option value=\"2026-01-30\">Ene 30 Vi, 2026</option>
<option value=\"2026-01-31\">Ene 31 Sá, 2026</option>
<option value=\"2026-02-01\">Feb 01 Do, 2026</option>
<option value=\"2026-02-02\">Feb 02 Lu, 2026</option>
<option value=\"2026-02-03\">Feb 03 Ma, 2026</option>
<option value=\"2026-02-04\">Feb 04 Mi, 2026</option>
<option value=\"2026-02-05\">Feb 05 Ju, 2026</option>
<option value=\"2026-02-06\">Feb 06 Vi, 2026</option>
<option value=\"2026-02-07\">Feb 07 Sá, 2026</option>
<option value=\"2026-02-08\">Feb 08 Do, 2026</option>
<option value=\"2026-02-09\">Feb 09 Lu, 2026</option>
<option value=\"2026-02-10\">Feb 10 Ma, 2026</option>
<option value=\"2026-02-11\">Feb 11 Mi, 2026</option>
<option value=\"2026-02-12\">Feb 12 Ju, 2026</option>
<option value=\"2026-02-13\">Feb 13 Vi, 2026</option>
<option value=\"2026-02-14\">Feb 14 Sá, 2026</option>
<option value=\"2026-02-15\">Feb 15 Do, 2026</option>
<option value=\"2026-02-16\">Feb 16 Lu, 2026</option>
<option value=\"2026-02-17\">Feb 17 Ma, 2026</option>
<option value=\"2026-02-18\">Feb 18 Mi, 2026</option>
<option value=\"2026-02-19\">Feb 19 Ju, 2026</option>
<option value=\"2026-02-20\">Feb 20 Vi, 2026</option>
<option value=\"2026-02-21\">Feb 21 Sá, 2026</option>
<option value=\"2026-02-22\">Feb 22 Do, 2026</option>
<option value=\"2026-02-23\">Feb 23 Lu, 2026</option>
<option value=\"2026-02-24\">Feb 24 Ma, 2026</option>
<option value=\"2026-02-25\">Feb 25 Mi, 2026</option>
<option value=\"2026-02-26\">Feb 26 Ju, 2026</option>
<option value=\"2026-02-27\">Feb 27 Vi, 2026</option>
<option value=\"2026-02-28\">Feb 28 Sá, 2026</option>
<option value=\"2026-03-01\">Mar 01 Do, 2026</option>
<option value=\"2026-03-02\">Mar 02 Lu, 2026</option>
<option value=\"2026-03-03\">Mar 03 Ma, 2026</option>
<option value=\"2026-03-04\">Mar 04 Mi, 2026</option>
<option value=\"2026-03-05\">Mar 05 Ju, 2026</option>
<option value=\"2026-03-06\">Mar 06 Vi, 2026</option>
<option value=\"2026-03-07\">Mar 07 Sá, 2026</option>
<option value=\"2026-03-08\">Mar 08 Do, 2026</option>
<option value=\"2026-03-09\">Mar 09 Lu, 2026</option>
<option value=\"2026-03-10\">Mar 10 Ma, 2026</option>
<option value=\"2026-03-11\">Mar 11 Mi, 2026</option>
<option value=\"2026-03-12\">Mar 12 Ju, 2026</option>
<option value=\"2026-03-13\">Mar 13 Vi, 2026</option>
<option value=\"2026-03-14\">Mar 14 Sá, 2026</option>
<option value=\"2026-03-15\">Mar 15 Do, 2026</option>
<option value=\"2026-03-16\">Mar 16 Lu, 2026</option>
<option value=\"2026-03-17\">Mar 17 Ma, 2026</option>
<option value=\"2026-03-18\">Mar 18 Mi, 2026</option>
<option value=\"2026-03-19\">Mar 19 Ju, 2026</option>
<option value=\"2026-03-20\">Mar 20 Vi, 2026</option>
<option value=\"2026-03-21\">Mar 21 Sá, 2026</option>
<option value=\"2026-03-22\">Mar 22 Do, 2026</option>
<option value=\"2026-03-23\">Mar 23 Lu, 2026</option>
<option value=\"2026-03-24\">Mar 24 Ma, 2026</option>
<option value=\"2026-03-25\">Mar 25 Mi, 2026</option>
<option value=\"2026-03-26\">Mar 26 Ju, 2026</option>
<option value=\"2026-03-27\">Mar 27 Vi, 2026</option>
<option value=\"2026-03-28\">Mar 28 Sá, 2026</option>
<option value=\"2026-03-29\">Mar 29 Do, 2026</option>
<option value=\"2026-03-30\">Mar 30 Lu, 2026</option>
<option value=\"2026-03-31\">Mar 31 Ma, 2026</option>
<option value=\"2026-04-01\">Abr 01 Mi, 2026</option>
<option value=\"2026-04-02\">Abr 02 Ju, 2026</option>
<option value=\"2026-04-03\">Abr 03 Vi, 2026</option>
<option value=\"2026-04-04\">Abr 04 Sá, 2026</option>
<option value=\"2026-04-05\">Abr 05 Do, 2026</option>
<option value=\"2026-04-06\">Abr 06 Lu, 2026</option>
<option value=\"2026-04-07\">Abr 07 Ma, 2026</option>
<option value=\"2026-04-08\">Abr 08 Mi, 2026</option>
<option value=\"2026-04-09\">Abr 09 Ju, 2026</option>
<option value=\"2026-04-10\">Abr 10 Vi, 2026</option>
<option value=\"2026-04-11\">Abr 11 Sá, 2026</option>
<option value=\"2026-04-12\">Abr 12 Do, 2026</option>
<option value=\"2026-04-13\">Abr 13 Lu, 2026</option>
<option value=\"2026-04-14\">Abr 14 Ma, 2026</option>
<option value=\"2026-04-15\">Abr 15 Mi, 2026</option>
<option value=\"2026-04-16\">Abr 16 Ju, 2026</option>
<option value=\"2026-04-17\">Abr 17 Vi, 2026</option>
<option value=\"2026-04-18\">Abr 18 Sá, 2026</option>
<option value=\"2026-04-19\">Abr 19 Do, 2026</option>
<option value=\"2026-04-20\">Abr 20 Lu, 2026</option>
<option value=\"2026-04-21\">Abr 21 Ma, 2026</option>
<option value=\"2026-04-22\">Abr 22 Mi, 2026</option>
<option value=\"2026-04-23\">Abr 23 Ju, 2026</option>
<option value=\"2026-04-24\">Abr 24 Vi, 2026</option>
<option value=\"2026-04-25\">Abr 25 Sá, 2026</option>
<option value=\"2026-04-26\">Abr 26 Do, 2026</option>
<option value=\"2026-04-27\">Abr 27 Lu, 2026</option>
<option value=\"2026-04-28\">Abr 28 Ma, 2026</option>
<option value=\"2026-04-29\">Abr 29 Mi, 2026</option>
<option value=\"2026-04-30\">Abr 30 Ju, 2026</option>
<option value=\"2026-05-01\">May 01 Vi, 2026</option>
<option value=\"2026-05-02\">May 02 Sá, 2026</option>
<option value=\"2026-05-03\">May 03 Do, 2026</option>
<option value=\"2026-05-04\">May 04 Lu, 2026</option>
<option value=\"2026-05-05\">May 05 Ma, 2026</option>
<option value=\"2026-05-06\">May 06 Mi, 2026</option>
<option value=\"2026-05-07\">May 07 Ju, 2026</option>
<option value=\"2026-05-08\">May 08 Vi, 2026</option>
<option value=\"2026-05-09\">May 09 Sá, 2026</option>
<option value=\"2026-05-10\">May 10 Do, 2026</option>
<option value=\"2026-05-11\">May 11 Lu, 2026</option>
<option value=\"2026-05-12\">May 12 Ma, 2026</option>
<option value=\"2026-05-13\">May 13 Mi, 2026</option>
<option value=\"2026-05-14\">May 14 Ju, 2026</option>
<option value=\"2026-05-15\">May 15 Vi, 2026</option>
<option value=\"2026-05-16\">May 16 Sá, 2026</option>
<option value=\"2026-05-17\">May 17 Do, 2026</option>
<option value=\"2026-05-18\">May 18 Lu, 2026</option>
<option value=\"2026-05-19\">May 19 Ma, 2026</option>
<option value=\"2026-05-20\">May 20 Mi, 2026</option>
<option value=\"2026-05-21\">May 21 Ju, 2026</option>
<option value=\"2026-05-22\">May 22 Vi, 2026</option>
<option value=\"2026-05-23\">May 23 Sá, 2026</option>
<option value=\"2026-05-24\">May 24 Do, 2026</option>
<option value=\"2026-05-25\">May 25 Lu, 2026</option>
<option value=\"2026-05-26\">May 26 Ma, 2026</option>
<option value=\"2026-05-27\">May 27 Mi, 2026</option>
<option value=\"2026-05-28\">May 28 Ju, 2026</option>
<option value=\"2026-05-29\">May 29 Vi, 2026</option>
<option value=\"2026-05-30\">May 30 Sá, 2026</option>
<option value=\"2026-05-31\">May 31 Do, 2026</option>
<option value=\"2026-06-01\">Jun 01 Lu, 2026</option>
<option value=\"2026-06-02\">Jun 02 Ma, 2026</option>
<option value=\"2026-06-03\">Jun 03 Mi, 2026</option>
<option value=\"2026-06-04\">Jun 04 Ju, 2026</option>
<option value=\"2026-06-05\">Jun 05 Vi, 2026</option>
<option value=\"2026-06-06\">Jun 06 Sá, 2026</option>
<option value=\"2026-06-07\">Jun 07 Do, 2026</option>
<option value=\"2026-06-08\">Jun 08 Lu, 2026</option>
<option value=\"2026-06-09\">Jun 09 Ma, 2026</option>
<option value=\"2026-06-10\">Jun 10 Mi, 2026</option>
<option value=\"2026-06-11\">Jun 11 Ju, 2026</option>
<option value=\"2026-06-12\">Jun 12 Vi, 2026</option>
<option value=\"2026-06-13\">Jun 13 Sá, 2026</option>
<option value=\"2026-06-14\">Jun 14 Do, 2026</option>
<option value=\"2026-06-15\">Jun 15 Lu, 2026</option>
<option value=\"2026-06-16\">Jun 16 Ma, 2026</option>
<option value=\"2026-06-17\">Jun 17 Mi, 2026</option>
<option value=\"2026-06-18\">Jun 18 Ju, 2026</option>
<option value=\"2026-06-19\">Jun 19 Vi, 2026</option>
<option value=\"2026-06-20\">Jun 20 Sá, 2026</option>
<option value=\"2026-06-21\">Jun 21 Do, 2026</option>
<option value=\"2026-06-22\">Jun 22 Lu, 2026</option>
<option value=\"2026-06-23\">Jun 23 Ma, 2026</option>
<option value=\"2026-06-24\">Jun 24 Mi, 2026</option>
<option value=\"2026-06-25\">Jun 25 Ju, 2026</option>
<option value=\"2026-06-26\">Jun 26 Vi, 2026</option>
<option value=\"2026-06-27\">Jun 27 Sá, 2026</option>
<option value=\"2026-06-28\">Jun 28 Do, 2026</option>
<option value=\"2026-06-29\">Jun 29 Lu, 2026</option>
<option value=\"2026-06-30\">Jun 30 Ma, 2026</option>
<option value=\"2026-07-01\">Jul 01 Mi, 2026</option>
<option value=\"2026-07-02\">Jul 02 Ju, 2026</option>
<option value=\"2026-07-03\">Jul 03 Vi, 2026</option>
<option value=\"2026-07-04\">Jul 04 Sá, 2026</option>
<option value=\"2026-07-05\">Jul 05 Do, 2026</option>
<option value=\"2026-07-06\">Jul 06 Lu, 2026</option>
<option value=\"2026-07-07\">Jul 07 Ma, 2026</option>
<option value=\"2026-07-08\">Jul 08 Mi, 2026</option>
<option value=\"2026-07-09\">Jul 09 Ju, 2026</option>
<option value=\"2026-07-10\">Jul 10 Vi, 2026</option>
<option value=\"2026-07-11\">Jul 11 Sá, 2026</option>
<option value=\"2026-07-12\">Jul 12 Do, 2026</option>
<option value=\"2026-07-13\">Jul 13 Lu, 2026</option>
<option value=\"2026-07-14\">Jul 14 Ma, 2026</option>
<option value=\"2026-07-15\">Jul 15 Mi, 2026</option>
<option value=\"2026-07-16\">Jul 16 Ju, 2026</option>
<option value=\"2026-07-17\">Jul 17 Vi, 2026</option>
<option value=\"2026-07-18\">Jul 18 Sá, 2026</option>
<option value=\"2026-07-19\">Jul 19 Do, 2026</option>
<option value=\"2026-07-20\">Jul 20 Lu, 2026</option>
<option value=\"2026-07-21\">Jul 21 Ma, 2026</option>
<option value=\"2026-07-22\">Jul 22 Mi, 2026</option>
<option value=\"2026-07-23\">Jul 23 Ju, 2026</option>
<option value=\"2026-07-24\">Jul 24 Vi, 2026</option>
<option value=\"2026-07-25\">Jul 25 Sá, 2026</option>
<option value=\"2026-07-26\">Jul 26 Do, 2026</option>
<option value=\"2026-07-27\">Jul 27 Lu, 2026</option>
<option value=\"2026-07-28\">Jul 28 Ma, 2026</option>
<option value=\"2026-07-29\">Jul 29 Mi, 2026</option>
<option value=\"2026-07-30\">Jul 30 Ju, 2026</option>
<option value=\"2026-07-31\">Jul 31 Vi, 2026</option>
<option value=\"2026-08-01\">Ago 01 Sá, 2026</option>
<option value=\"2026-08-02\">Ago 02 Do, 2026</option>
<option value=\"2026-08-03\">Ago 03 Lu, 2026</option>
<option value=\"2026-08-04\">Ago 04 Ma, 2026</option>
<option value=\"2026-08-05\">Ago 05 Mi, 2026</option>
<option value=\"2026-08-06\">Ago 06 Ju, 2026</option>
<option value=\"2026-08-07\">Ago 07 Vi, 2026</option>
<option value=\"2026-08-08\">Ago 08 Sá, 2026</option>
<option value=\"2026-08-09\">Ago 09 Do, 2026</option>
<option value=\"2026-08-10\">Ago 10 Lu, 2026</option>
<option value=\"2026-08-11\">Ago 11 Ma, 2026</option>
<option value=\"2026-08-12\">Ago 12 Mi, 2026</option>
<option value=\"2026-08-13\">Ago 13 Ju, 2026</option>
<option value=\"2026-08-14\">Ago 14 Vi, 2026</option>
<option value=\"2026-08-15\">Ago 15 Sá, 2026</option>
<option value=\"2026-08-16\">Ago 16 Do, 2026</option>
<option value=\"2026-08-17\">Ago 17 Lu, 2026</option>
<option value=\"2026-08-18\">Ago 18 Ma, 2026</option>
<option value=\"2026-08-19\">Ago 19 Mi, 2026</option>
<option value=\"2026-08-20\">Ago 20 Ju, 2026</option>
<option value=\"2026-08-21\">Ago 21 Vi, 2026</option>
<option value=\"2026-08-22\">Ago 22 Sá, 2026</option>
<option value=\"2026-08-23\">Ago 23 Do, 2026</option>
<option value=\"2026-08-24\">Ago 24 Lu, 2026</option>
<option value=\"2026-08-25\">Ago 25 Ma, 2026</option>
<option value=\"2026-08-26\">Ago 26 Mi, 2026</option>
<option value=\"2026-08-27\">Ago 27 Ju, 2026</option>
<option value=\"2026-08-28\">Ago 28 Vi, 2026</option>
<option value=\"2026-08-29\">Ago 29 Sá, 2026</option>
<option value=\"2026-08-30\">Ago 30 Do, 2026</option>
<option value=\"2026-08-31\">Ago 31 Lu, 2026</option>
<option value=\"2026-09-01\">Sep 01 Ma, 2026</option>
<option value=\"2026-09-02\">Sep 02 Mi, 2026</option>
<option value=\"2026-09-03\">Sep 03 Ju, 2026</option>
<option value=\"2026-09-04\">Sep 04 Vi, 2026</option>
<option value=\"2026-09-05\">Sep 05 Sá, 2026</option>
<option value=\"2026-09-06\">Sep 06 Do, 2026</option>
<option value=\"2026-09-07\">Sep 07 Lu, 2026</option>
<option value=\"2026-09-08\">Sep 08 Ma, 2026</option>
<option value=\"2026-09-09\">Sep 09 Mi, 2026</option>
<option value=\"2026-09-10\">Sep 10 Ju, 2026</option>
<option value=\"2026-09-11\">Sep 11 Vi, 2026</option>
<option value=\"2026-09-12\">Sep 12 Sá, 2026</option>
<option value=\"2026-09-13\">Sep 13 Do, 2026</option>
<option value=\"2026-09-14\">Sep 14 Lu, 2026</option>
<option value=\"2026-09-15\">Sep 15 Ma, 2026</option>
<option value=\"2026-09-16\">Sep 16 Mi, 2026</option>
<option value=\"2026-09-17\">Sep 17 Ju, 2026</option>
<option value=\"2026-09-18\">Sep 18 Vi, 2026</option>
<option value=\"2026-09-19\">Sep 19 Sá, 2026</option>
<option value=\"2026-09-20\">Sep 20 Do, 2026</option>
<option value=\"2026-09-21\">Sep 21 Lu, 2026</option>
<option value=\"2026-09-22\">Sep 22 Ma, 2026</option>
<option value=\"2026-09-23\">Sep 23 Mi, 2026</option>
<option value=\"2026-09-24\">Sep 24 Ju, 2026</option>
<option value=\"2026-09-25\">Sep 25 Vi, 2026</option>
<option value=\"2026-09-26\">Sep 26 Sá, 2026</option>
<option value=\"2026-09-27\">Sep 27 Do, 2026</option>
<option value=\"2026-09-28\">Sep 28 Lu, 2026</option>
<option value=\"2026-09-29\">Sep 29 Ma, 2026</option>
<option value=\"2026-09-30\">Sep 30 Mi, 2026</option>
<option value=\"2026-10-01\">Oct 01 Ju, 2026</option>
<option value=\"2026-10-02\">Oct 02 Vi, 2026</option>
<option value=\"2026-10-03\">Oct 03 Sá, 2026</option>
<option value=\"2026-10-04\">Oct 04 Do, 2026</option>
<option value=\"2026-10-05\">Oct 05 Lu, 2026</option>
<option value=\"2026-10-06\">Oct 06 Ma, 2026</option>
<option value=\"2026-10-07\">Oct 07 Mi, 2026</option>
<option value=\"2026-10-08\">Oct 08 Ju, 2026</option>
<option value=\"2026-10-09\">Oct 09 Vi, 2026</option>
<option value=\"2026-10-10\">Oct 10 Sá, 2026</option>
<option value=\"2026-10-11\">Oct 11 Do, 2026</option>
<option value=\"2026-10-12\">Oct 12 Lu, 2026</option>
<option value=\"2026-10-13\">Oct 13 Ma, 2026</option>
<option value=\"2026-10-14\">Oct 14 Mi, 2026</option>
<option value=\"2026-10-15\">Oct 15 Ju, 2026</option>
<option value=\"2026-10-16\">Oct 16 Vi, 2026</option>
<option value=\"2026-10-17\">Oct 17 Sá, 2026</option>
<option value=\"2026-10-18\">Oct 18 Do, 2026</option>
<option value=\"2026-10-19\">Oct 19 Lu, 2026</option>
<option value=\"2026-10-20\">Oct 20 Ma, 2026</option>
<option value=\"2026-10-21\">Oct 21 Mi, 2026</option>
<option value=\"2026-10-22\">Oct 22 Ju, 2026</option>
<option value=\"2026-10-23\">Oct 23 Vi, 2026</option>
<option value=\"2026-10-24\">Oct 24 Sá, 2026</option>
<option value=\"2026-10-25\">Oct 25 Do, 2026</option>
<option value=\"2026-10-26\">Oct 26 Lu, 2026</option>
<option value=\"2026-10-27\">Oct 27 Ma, 2026</option>
<option value=\"2026-10-28\">Oct 28 Mi, 2026</option>
<option value=\"2026-10-29\">Oct 29 Ju, 2026</option>
<option value=\"2026-10-30\">Oct 30 Vi, 2026</option>
<option value=\"2026-10-31\">Oct 31 Sá, 2026</option>
<option value=\"2026-11-01\">Nov 01 Do, 2026</option>
<option value=\"2026-11-02\">Nov 02 Lu, 2026</option>
<option value=\"2026-11-03\">Nov 03 Ma, 2026</option>
<option value=\"2026-11-04\">Nov 04 Mi, 2026</option>
<option value=\"2026-11-05\">Nov 05 Ju, 2026</option>
<option value=\"2026-11-06\">Nov 06 Vi, 2026</option>
<option value=\"2026-11-07\">Nov 07 Sá, 2026</option>
<option value=\"2026-11-08\">Nov 08 Do, 2026</option>
<option value=\"2026-11-09\">Nov 09 Lu, 2026</option>
<option value=\"2026-11-10\">Nov 10 Ma, 2026</option>
<option value=\"2026-11-11\">Nov 11 Mi, 2026</option>
<option value=\"2026-11-12\">Nov 12 Ju, 2026</option>
<option value=\"2026-11-13\">Nov 13 Vi, 2026</option>
<option value=\"2026-11-14\">Nov 14 Sá, 2026</option>
<option value=\"2026-11-15\">Nov 15 Do, 2026</option>
<option value=\"2026-11-16\">Nov 16 Lu, 2026</option>
<option value=\"2026-11-17\">Nov 17 Ma, 2026</option>
<option value=\"2026-11-18\">Nov 18 Mi, 2026</option>
<option value=\"2026-11-19\">Nov 19 Ju, 2026</option>
<option value=\"2026-11-20\">Nov 20 Vi, 2026</option>
<option value=\"2026-11-21\">Nov 21 Sá, 2026</option>
<option value=\"2026-11-22\">Nov 22 Do, 2026</option>
<option value=\"2026-11-23\">Nov 23 Lu, 2026</option>
<option value=\"2026-11-24\">Nov 24 Ma, 2026</option>
<option value=\"2026-11-25\">Nov 25 Mi, 2026</option>
<option value=\"2026-11-26\">Nov 26 Ju, 2026</option>
<option value=\"2026-11-27\">Nov 27 Vi, 2026</option>
<option value=\"2026-11-28\">Nov 28 Sá, 2026</option>
<option value=\"2026-11-29\">Nov 29 Do, 2026</option>
<option value=\"2026-11-30\">Nov 30 Lu, 2026</option>
<option value=\"2026-12-01\">Dic 01 Ma, 2026</option>
<option value=\"2026-12-02\">Dic 02 Mi, 2026</option>
<option value=\"2026-12-03\">Dic 03 Ju, 2026</option>
<option value=\"2026-12-04\">Dic 04 Vi, 2026</option>
<option value=\"2026-12-05\">Dic 05 Sá, 2026</option>
<option value=\"2026-12-06\">Dic 06 Do, 2026</option>
<option value=\"2026-12-07\">Dic 07 Lu, 2026</option>
<option value=\"2026-12-08\">Dic 08 Ma, 2026</option>
<option value=\"2026-12-09\">Dic 09 Mi, 2026</option>
<option value=\"2026-12-10\">Dic 10 Ju, 2026</option>
<option value=\"2026-12-11\">Dic 11 Vi, 2026</option>
<option value=\"2026-12-12\">Dic 12 Sá, 2026</option>
<option value=\"2026-12-13\">Dic 13 Do, 2026</option>
<option value=\"2026-12-14\">Dic 14 Lu, 2026</option>
<option value=\"2026-12-15\">Dic 15 Ma, 2026</option>
<option value=\"2026-12-16\">Dic 16 Mi, 2026</option>
<option value=\"2026-12-17\">Dic 17 Ju, 2026</option>
<option value=\"2026-12-18\">Dic 18 Vi, 2026</option>
<option value=\"2026-12-19\">Dic 19 Sá, 2026</option>
<option value=\"2026-12-20\">Dic 20 Do, 2026</option>
<option value=\"2026-12-21\">Dic 21 Lu, 2026</option>
<option value=\"2026-12-22\">Dic 22 Ma, 2026</option>
<option value=\"2026-12-23\">Dic 23 Mi, 2026</option>
<option value=\"2026-12-24\">Dic 24 Ju, 2026</option>
<option value=\"2026-12-25\">Dic 25 Vi, 2026</option>
<option value=\"2026-12-26\">Dic 26 Sá, 2026</option>
<option value=\"2026-12-27\">Dic 27 Do, 2026</option>
<option value=\"2026-12-28\">Dic 28 Lu, 2026</option>
<option value=\"2026-12-29\">Dic 29 Ma, 2026</option>
<option value=\"2026-12-30\">Dic 30 Mi, 2026</option>
<option value=\"2026-12-31\">Dic 31 Ju, 2026</option>
<option value=\"2027-01-01\">Ene 01 Vi, 2027</option>

";

?></contenuto>
</file>
<file>
<nomefile>./dati/selperiodimenu2025.1.php</nomefile>
<contenuto>
<?php 

$y_ini_menu = array();
$m_ini_menu = array();
$d_ini_menu = array();
$n_dates_menu = array();
$d_increment = array();
$y_ini_menu[0] = "2025";
$m_ini_menu[0] = "0";
$d_ini_menu[0] = "01";
$n_dates_menu[0] = "731";
$d_increment[0] = "1";
$d_names = "\" Do\",\" Lu\",\" Ma\",\" Mi\",\" Ju\",\" Vi\",\" Sá\"";
$m_names = "\"Ene\",\"Feb\",\"Mar\",\"Abr\",\"May\",\"Jun\",\"Jul\",\"Ago\",\"Sep\",\"Oct\",\"Nov\",\"Dic\"";

$dates_options_list = "

<option value=\"2025-01-01\">Ene 01 Mi, 2025</option>
<option value=\"2025-01-02\">Ene 02 Ju, 2025</option>
<option value=\"2025-01-03\">Ene 03 Vi, 2025</option>
<option value=\"2025-01-04\">Ene 04 Sá, 2025</option>
<option value=\"2025-01-05\">Ene 05 Do, 2025</option>
<option value=\"2025-01-06\">Ene 06 Lu, 2025</option>
<option value=\"2025-01-07\">Ene 07 Ma, 2025</option>
<option value=\"2025-01-08\">Ene 08 Mi, 2025</option>
<option value=\"2025-01-09\">Ene 09 Ju, 2025</option>
<option value=\"2025-01-10\">Ene 10 Vi, 2025</option>
<option value=\"2025-01-11\">Ene 11 Sá, 2025</option>
<option value=\"2025-01-12\">Ene 12 Do, 2025</option>
<option value=\"2025-01-13\">Ene 13 Lu, 2025</option>
<option value=\"2025-01-14\">Ene 14 Ma, 2025</option>
<option value=\"2025-01-15\">Ene 15 Mi, 2025</option>
<option value=\"2025-01-16\">Ene 16 Ju, 2025</option>
<option value=\"2025-01-17\">Ene 17 Vi, 2025</option>
<option value=\"2025-01-18\">Ene 18 Sá, 2025</option>
<option value=\"2025-01-19\">Ene 19 Do, 2025</option>
<option value=\"2025-01-20\">Ene 20 Lu, 2025</option>
<option value=\"2025-01-21\">Ene 21 Ma, 2025</option>
<option value=\"2025-01-22\">Ene 22 Mi, 2025</option>
<option value=\"2025-01-23\">Ene 23 Ju, 2025</option>
<option value=\"2025-01-24\">Ene 24 Vi, 2025</option>
<option value=\"2025-01-25\">Ene 25 Sá, 2025</option>
<option value=\"2025-01-26\">Ene 26 Do, 2025</option>
<option value=\"2025-01-27\">Ene 27 Lu, 2025</option>
<option value=\"2025-01-28\">Ene 28 Ma, 2025</option>
<option value=\"2025-01-29\">Ene 29 Mi, 2025</option>
<option value=\"2025-01-30\">Ene 30 Ju, 2025</option>
<option value=\"2025-01-31\">Ene 31 Vi, 2025</option>
<option value=\"2025-02-01\">Feb 01 Sá, 2025</option>
<option value=\"2025-02-02\">Feb 02 Do, 2025</option>
<option value=\"2025-02-03\">Feb 03 Lu, 2025</option>
<option value=\"2025-02-04\">Feb 04 Ma, 2025</option>
<option value=\"2025-02-05\">Feb 05 Mi, 2025</option>
<option value=\"2025-02-06\">Feb 06 Ju, 2025</option>
<option value=\"2025-02-07\">Feb 07 Vi, 2025</option>
<option value=\"2025-02-08\">Feb 08 Sá, 2025</option>
<option value=\"2025-02-09\">Feb 09 Do, 2025</option>
<option value=\"2025-02-10\">Feb 10 Lu, 2025</option>
<option value=\"2025-02-11\">Feb 11 Ma, 2025</option>
<option value=\"2025-02-12\">Feb 12 Mi, 2025</option>
<option value=\"2025-02-13\">Feb 13 Ju, 2025</option>
<option value=\"2025-02-14\">Feb 14 Vi, 2025</option>
<option value=\"2025-02-15\">Feb 15 Sá, 2025</option>
<option value=\"2025-02-16\">Feb 16 Do, 2025</option>
<option value=\"2025-02-17\">Feb 17 Lu, 2025</option>
<option value=\"2025-02-18\">Feb 18 Ma, 2025</option>
<option value=\"2025-02-19\">Feb 19 Mi, 2025</option>
<option value=\"2025-02-20\">Feb 20 Ju, 2025</option>
<option value=\"2025-02-21\">Feb 21 Vi, 2025</option>
<option value=\"2025-02-22\">Feb 22 Sá, 2025</option>
<option value=\"2025-02-23\">Feb 23 Do, 2025</option>
<option value=\"2025-02-24\">Feb 24 Lu, 2025</option>
<option value=\"2025-02-25\">Feb 25 Ma, 2025</option>
<option value=\"2025-02-26\">Feb 26 Mi, 2025</option>
<option value=\"2025-02-27\">Feb 27 Ju, 2025</option>
<option value=\"2025-02-28\">Feb 28 Vi, 2025</option>
<option value=\"2025-03-01\">Mar 01 Sá, 2025</option>
<option value=\"2025-03-02\">Mar 02 Do, 2025</option>
<option value=\"2025-03-03\">Mar 03 Lu, 2025</option>
<option value=\"2025-03-04\">Mar 04 Ma, 2025</option>
<option value=\"2025-03-05\">Mar 05 Mi, 2025</option>
<option value=\"2025-03-06\">Mar 06 Ju, 2025</option>
<option value=\"2025-03-07\">Mar 07 Vi, 2025</option>
<option value=\"2025-03-08\">Mar 08 Sá, 2025</option>
<option value=\"2025-03-09\">Mar 09 Do, 2025</option>
<option value=\"2025-03-10\">Mar 10 Lu, 2025</option>
<option value=\"2025-03-11\">Mar 11 Ma, 2025</option>
<option value=\"2025-03-12\">Mar 12 Mi, 2025</option>
<option value=\"2025-03-13\">Mar 13 Ju, 2025</option>
<option value=\"2025-03-14\">Mar 14 Vi, 2025</option>
<option value=\"2025-03-15\">Mar 15 Sá, 2025</option>
<option value=\"2025-03-16\">Mar 16 Do, 2025</option>
<option value=\"2025-03-17\">Mar 17 Lu, 2025</option>
<option value=\"2025-03-18\">Mar 18 Ma, 2025</option>
<option value=\"2025-03-19\">Mar 19 Mi, 2025</option>
<option value=\"2025-03-20\">Mar 20 Ju, 2025</option>
<option value=\"2025-03-21\">Mar 21 Vi, 2025</option>
<option value=\"2025-03-22\">Mar 22 Sá, 2025</option>
<option value=\"2025-03-23\">Mar 23 Do, 2025</option>
<option value=\"2025-03-24\">Mar 24 Lu, 2025</option>
<option value=\"2025-03-25\">Mar 25 Ma, 2025</option>
<option value=\"2025-03-26\">Mar 26 Mi, 2025</option>
<option value=\"2025-03-27\">Mar 27 Ju, 2025</option>
<option value=\"2025-03-28\">Mar 28 Vi, 2025</option>
<option value=\"2025-03-29\">Mar 29 Sá, 2025</option>
<option value=\"2025-03-30\">Mar 30 Do, 2025</option>
<option value=\"2025-03-31\">Mar 31 Lu, 2025</option>
<option value=\"2025-04-01\">Abr 01 Ma, 2025</option>
<option value=\"2025-04-02\">Abr 02 Mi, 2025</option>
<option value=\"2025-04-03\">Abr 03 Ju, 2025</option>
<option value=\"2025-04-04\">Abr 04 Vi, 2025</option>
<option value=\"2025-04-05\">Abr 05 Sá, 2025</option>
<option value=\"2025-04-06\">Abr 06 Do, 2025</option>
<option value=\"2025-04-07\">Abr 07 Lu, 2025</option>
<option value=\"2025-04-08\">Abr 08 Ma, 2025</option>
<option value=\"2025-04-09\">Abr 09 Mi, 2025</option>
<option value=\"2025-04-10\">Abr 10 Ju, 2025</option>
<option value=\"2025-04-11\">Abr 11 Vi, 2025</option>
<option value=\"2025-04-12\">Abr 12 Sá, 2025</option>
<option value=\"2025-04-13\">Abr 13 Do, 2025</option>
<option value=\"2025-04-14\">Abr 14 Lu, 2025</option>
<option value=\"2025-04-15\">Abr 15 Ma, 2025</option>
<option value=\"2025-04-16\">Abr 16 Mi, 2025</option>
<option value=\"2025-04-17\">Abr 17 Ju, 2025</option>
<option value=\"2025-04-18\">Abr 18 Vi, 2025</option>
<option value=\"2025-04-19\">Abr 19 Sá, 2025</option>
<option value=\"2025-04-20\">Abr 20 Do, 2025</option>
<option value=\"2025-04-21\">Abr 21 Lu, 2025</option>
<option value=\"2025-04-22\">Abr 22 Ma, 2025</option>
<option value=\"2025-04-23\">Abr 23 Mi, 2025</option>
<option value=\"2025-04-24\">Abr 24 Ju, 2025</option>
<option value=\"2025-04-25\">Abr 25 Vi, 2025</option>
<option value=\"2025-04-26\">Abr 26 Sá, 2025</option>
<option value=\"2025-04-27\">Abr 27 Do, 2025</option>
<option value=\"2025-04-28\">Abr 28 Lu, 2025</option>
<option value=\"2025-04-29\">Abr 29 Ma, 2025</option>
<option value=\"2025-04-30\">Abr 30 Mi, 2025</option>
<option value=\"2025-05-01\">May 01 Ju, 2025</option>
<option value=\"2025-05-02\">May 02 Vi, 2025</option>
<option value=\"2025-05-03\">May 03 Sá, 2025</option>
<option value=\"2025-05-04\">May 04 Do, 2025</option>
<option value=\"2025-05-05\">May 05 Lu, 2025</option>
<option value=\"2025-05-06\">May 06 Ma, 2025</option>
<option value=\"2025-05-07\">May 07 Mi, 2025</option>
<option value=\"2025-05-08\">May 08 Ju, 2025</option>
<option value=\"2025-05-09\">May 09 Vi, 2025</option>
<option value=\"2025-05-10\">May 10 Sá, 2025</option>
<option value=\"2025-05-11\">May 11 Do, 2025</option>
<option value=\"2025-05-12\">May 12 Lu, 2025</option>
<option value=\"2025-05-13\">May 13 Ma, 2025</option>
<option value=\"2025-05-14\">May 14 Mi, 2025</option>
<option value=\"2025-05-15\">May 15 Ju, 2025</option>
<option value=\"2025-05-16\">May 16 Vi, 2025</option>
<option value=\"2025-05-17\">May 17 Sá, 2025</option>
<option value=\"2025-05-18\">May 18 Do, 2025</option>
<option value=\"2025-05-19\">May 19 Lu, 2025</option>
<option value=\"2025-05-20\">May 20 Ma, 2025</option>
<option value=\"2025-05-21\">May 21 Mi, 2025</option>
<option value=\"2025-05-22\">May 22 Ju, 2025</option>
<option value=\"2025-05-23\">May 23 Vi, 2025</option>
<option value=\"2025-05-24\">May 24 Sá, 2025</option>
<option value=\"2025-05-25\">May 25 Do, 2025</option>
<option value=\"2025-05-26\">May 26 Lu, 2025</option>
<option value=\"2025-05-27\">May 27 Ma, 2025</option>
<option value=\"2025-05-28\">May 28 Mi, 2025</option>
<option value=\"2025-05-29\">May 29 Ju, 2025</option>
<option value=\"2025-05-30\">May 30 Vi, 2025</option>
<option value=\"2025-05-31\">May 31 Sá, 2025</option>
<option value=\"2025-06-01\">Jun 01 Do, 2025</option>
<option value=\"2025-06-02\">Jun 02 Lu, 2025</option>
<option value=\"2025-06-03\">Jun 03 Ma, 2025</option>
<option value=\"2025-06-04\">Jun 04 Mi, 2025</option>
<option value=\"2025-06-05\">Jun 05 Ju, 2025</option>
<option value=\"2025-06-06\">Jun 06 Vi, 2025</option>
<option value=\"2025-06-07\">Jun 07 Sá, 2025</option>
<option value=\"2025-06-08\">Jun 08 Do, 2025</option>
<option value=\"2025-06-09\">Jun 09 Lu, 2025</option>
<option value=\"2025-06-10\">Jun 10 Ma, 2025</option>
<option value=\"2025-06-11\">Jun 11 Mi, 2025</option>
<option value=\"2025-06-12\">Jun 12 Ju, 2025</option>
<option value=\"2025-06-13\">Jun 13 Vi, 2025</option>
<option value=\"2025-06-14\">Jun 14 Sá, 2025</option>
<option value=\"2025-06-15\">Jun 15 Do, 2025</option>
<option value=\"2025-06-16\">Jun 16 Lu, 2025</option>
<option value=\"2025-06-17\">Jun 17 Ma, 2025</option>
<option value=\"2025-06-18\">Jun 18 Mi, 2025</option>
<option value=\"2025-06-19\">Jun 19 Ju, 2025</option>
<option value=\"2025-06-20\">Jun 20 Vi, 2025</option>
<option value=\"2025-06-21\">Jun 21 Sá, 2025</option>
<option value=\"2025-06-22\">Jun 22 Do, 2025</option>
<option value=\"2025-06-23\">Jun 23 Lu, 2025</option>
<option value=\"2025-06-24\">Jun 24 Ma, 2025</option>
<option value=\"2025-06-25\">Jun 25 Mi, 2025</option>
<option value=\"2025-06-26\">Jun 26 Ju, 2025</option>
<option value=\"2025-06-27\">Jun 27 Vi, 2025</option>
<option value=\"2025-06-28\">Jun 28 Sá, 2025</option>
<option value=\"2025-06-29\">Jun 29 Do, 2025</option>
<option value=\"2025-06-30\">Jun 30 Lu, 2025</option>
<option value=\"2025-07-01\">Jul 01 Ma, 2025</option>
<option value=\"2025-07-02\">Jul 02 Mi, 2025</option>
<option value=\"2025-07-03\">Jul 03 Ju, 2025</option>
<option value=\"2025-07-04\">Jul 04 Vi, 2025</option>
<option value=\"2025-07-05\">Jul 05 Sá, 2025</option>
<option value=\"2025-07-06\">Jul 06 Do, 2025</option>
<option value=\"2025-07-07\">Jul 07 Lu, 2025</option>
<option value=\"2025-07-08\">Jul 08 Ma, 2025</option>
<option value=\"2025-07-09\">Jul 09 Mi, 2025</option>
<option value=\"2025-07-10\">Jul 10 Ju, 2025</option>
<option value=\"2025-07-11\">Jul 11 Vi, 2025</option>
<option value=\"2025-07-12\">Jul 12 Sá, 2025</option>
<option value=\"2025-07-13\">Jul 13 Do, 2025</option>
<option value=\"2025-07-14\">Jul 14 Lu, 2025</option>
<option value=\"2025-07-15\">Jul 15 Ma, 2025</option>
<option value=\"2025-07-16\">Jul 16 Mi, 2025</option>
<option value=\"2025-07-17\">Jul 17 Ju, 2025</option>
<option value=\"2025-07-18\">Jul 18 Vi, 2025</option>
<option value=\"2025-07-19\">Jul 19 Sá, 2025</option>
<option value=\"2025-07-20\">Jul 20 Do, 2025</option>
<option value=\"2025-07-21\">Jul 21 Lu, 2025</option>
<option value=\"2025-07-22\">Jul 22 Ma, 2025</option>
<option value=\"2025-07-23\">Jul 23 Mi, 2025</option>
<option value=\"2025-07-24\">Jul 24 Ju, 2025</option>
<option value=\"2025-07-25\">Jul 25 Vi, 2025</option>
<option value=\"2025-07-26\">Jul 26 Sá, 2025</option>
<option value=\"2025-07-27\">Jul 27 Do, 2025</option>
<option value=\"2025-07-28\">Jul 28 Lu, 2025</option>
<option value=\"2025-07-29\">Jul 29 Ma, 2025</option>
<option value=\"2025-07-30\">Jul 30 Mi, 2025</option>
<option value=\"2025-07-31\">Jul 31 Ju, 2025</option>
<option value=\"2025-08-01\">Ago 01 Vi, 2025</option>
<option value=\"2025-08-02\">Ago 02 Sá, 2025</option>
<option value=\"2025-08-03\">Ago 03 Do, 2025</option>
<option value=\"2025-08-04\">Ago 04 Lu, 2025</option>
<option value=\"2025-08-05\">Ago 05 Ma, 2025</option>
<option value=\"2025-08-06\">Ago 06 Mi, 2025</option>
<option value=\"2025-08-07\">Ago 07 Ju, 2025</option>
<option value=\"2025-08-08\">Ago 08 Vi, 2025</option>
<option value=\"2025-08-09\">Ago 09 Sá, 2025</option>
<option value=\"2025-08-10\">Ago 10 Do, 2025</option>
<option value=\"2025-08-11\">Ago 11 Lu, 2025</option>
<option value=\"2025-08-12\">Ago 12 Ma, 2025</option>
<option value=\"2025-08-13\">Ago 13 Mi, 2025</option>
<option value=\"2025-08-14\">Ago 14 Ju, 2025</option>
<option value=\"2025-08-15\">Ago 15 Vi, 2025</option>
<option value=\"2025-08-16\">Ago 16 Sá, 2025</option>
<option value=\"2025-08-17\">Ago 17 Do, 2025</option>
<option value=\"2025-08-18\">Ago 18 Lu, 2025</option>
<option value=\"2025-08-19\">Ago 19 Ma, 2025</option>
<option value=\"2025-08-20\">Ago 20 Mi, 2025</option>
<option value=\"2025-08-21\">Ago 21 Ju, 2025</option>
<option value=\"2025-08-22\">Ago 22 Vi, 2025</option>
<option value=\"2025-08-23\">Ago 23 Sá, 2025</option>
<option value=\"2025-08-24\">Ago 24 Do, 2025</option>
<option value=\"2025-08-25\">Ago 25 Lu, 2025</option>
<option value=\"2025-08-26\">Ago 26 Ma, 2025</option>
<option value=\"2025-08-27\">Ago 27 Mi, 2025</option>
<option value=\"2025-08-28\">Ago 28 Ju, 2025</option>
<option value=\"2025-08-29\">Ago 29 Vi, 2025</option>
<option value=\"2025-08-30\">Ago 30 Sá, 2025</option>
<option value=\"2025-08-31\">Ago 31 Do, 2025</option>
<option value=\"2025-09-01\">Sep 01 Lu, 2025</option>
<option value=\"2025-09-02\">Sep 02 Ma, 2025</option>
<option value=\"2025-09-03\">Sep 03 Mi, 2025</option>
<option value=\"2025-09-04\">Sep 04 Ju, 2025</option>
<option value=\"2025-09-05\">Sep 05 Vi, 2025</option>
<option value=\"2025-09-06\">Sep 06 Sá, 2025</option>
<option value=\"2025-09-07\">Sep 07 Do, 2025</option>
<option value=\"2025-09-08\">Sep 08 Lu, 2025</option>
<option value=\"2025-09-09\">Sep 09 Ma, 2025</option>
<option value=\"2025-09-10\">Sep 10 Mi, 2025</option>
<option value=\"2025-09-11\">Sep 11 Ju, 2025</option>
<option value=\"2025-09-12\">Sep 12 Vi, 2025</option>
<option value=\"2025-09-13\">Sep 13 Sá, 2025</option>
<option value=\"2025-09-14\">Sep 14 Do, 2025</option>
<option value=\"2025-09-15\">Sep 15 Lu, 2025</option>
<option value=\"2025-09-16\">Sep 16 Ma, 2025</option>
<option value=\"2025-09-17\">Sep 17 Mi, 2025</option>
<option value=\"2025-09-18\">Sep 18 Ju, 2025</option>
<option value=\"2025-09-19\">Sep 19 Vi, 2025</option>
<option value=\"2025-09-20\">Sep 20 Sá, 2025</option>
<option value=\"2025-09-21\">Sep 21 Do, 2025</option>
<option value=\"2025-09-22\">Sep 22 Lu, 2025</option>
<option value=\"2025-09-23\">Sep 23 Ma, 2025</option>
<option value=\"2025-09-24\">Sep 24 Mi, 2025</option>
<option value=\"2025-09-25\">Sep 25 Ju, 2025</option>
<option value=\"2025-09-26\">Sep 26 Vi, 2025</option>
<option value=\"2025-09-27\">Sep 27 Sá, 2025</option>
<option value=\"2025-09-28\">Sep 28 Do, 2025</option>
<option value=\"2025-09-29\">Sep 29 Lu, 2025</option>
<option value=\"2025-09-30\">Sep 30 Ma, 2025</option>
<option value=\"2025-10-01\">Oct 01 Mi, 2025</option>
<option value=\"2025-10-02\">Oct 02 Ju, 2025</option>
<option value=\"2025-10-03\">Oct 03 Vi, 2025</option>
<option value=\"2025-10-04\">Oct 04 Sá, 2025</option>
<option value=\"2025-10-05\">Oct 05 Do, 2025</option>
<option value=\"2025-10-06\">Oct 06 Lu, 2025</option>
<option value=\"2025-10-07\">Oct 07 Ma, 2025</option>
<option value=\"2025-10-08\">Oct 08 Mi, 2025</option>
<option value=\"2025-10-09\">Oct 09 Ju, 2025</option>
<option value=\"2025-10-10\">Oct 10 Vi, 2025</option>
<option value=\"2025-10-11\">Oct 11 Sá, 2025</option>
<option value=\"2025-10-12\">Oct 12 Do, 2025</option>
<option value=\"2025-10-13\">Oct 13 Lu, 2025</option>
<option value=\"2025-10-14\">Oct 14 Ma, 2025</option>
<option value=\"2025-10-15\">Oct 15 Mi, 2025</option>
<option value=\"2025-10-16\">Oct 16 Ju, 2025</option>
<option value=\"2025-10-17\">Oct 17 Vi, 2025</option>
<option value=\"2025-10-18\">Oct 18 Sá, 2025</option>
<option value=\"2025-10-19\">Oct 19 Do, 2025</option>
<option value=\"2025-10-20\">Oct 20 Lu, 2025</option>
<option value=\"2025-10-21\">Oct 21 Ma, 2025</option>
<option value=\"2025-10-22\">Oct 22 Mi, 2025</option>
<option value=\"2025-10-23\">Oct 23 Ju, 2025</option>
<option value=\"2025-10-24\">Oct 24 Vi, 2025</option>
<option value=\"2025-10-25\">Oct 25 Sá, 2025</option>
<option value=\"2025-10-26\">Oct 26 Do, 2025</option>
<option value=\"2025-10-27\">Oct 27 Lu, 2025</option>
<option value=\"2025-10-28\">Oct 28 Ma, 2025</option>
<option value=\"2025-10-29\">Oct 29 Mi, 2025</option>
<option value=\"2025-10-30\">Oct 30 Ju, 2025</option>
<option value=\"2025-10-31\">Oct 31 Vi, 2025</option>
<option value=\"2025-11-01\">Nov 01 Sá, 2025</option>
<option value=\"2025-11-02\">Nov 02 Do, 2025</option>
<option value=\"2025-11-03\">Nov 03 Lu, 2025</option>
<option value=\"2025-11-04\">Nov 04 Ma, 2025</option>
<option value=\"2025-11-05\">Nov 05 Mi, 2025</option>
<option value=\"2025-11-06\">Nov 06 Ju, 2025</option>
<option value=\"2025-11-07\">Nov 07 Vi, 2025</option>
<option value=\"2025-11-08\">Nov 08 Sá, 2025</option>
<option value=\"2025-11-09\">Nov 09 Do, 2025</option>
<option value=\"2025-11-10\">Nov 10 Lu, 2025</option>
<option value=\"2025-11-11\">Nov 11 Ma, 2025</option>
<option value=\"2025-11-12\">Nov 12 Mi, 2025</option>
<option value=\"2025-11-13\">Nov 13 Ju, 2025</option>
<option value=\"2025-11-14\">Nov 14 Vi, 2025</option>
<option value=\"2025-11-15\">Nov 15 Sá, 2025</option>
<option value=\"2025-11-16\">Nov 16 Do, 2025</option>
<option value=\"2025-11-17\">Nov 17 Lu, 2025</option>
<option value=\"2025-11-18\">Nov 18 Ma, 2025</option>
<option value=\"2025-11-19\">Nov 19 Mi, 2025</option>
<option value=\"2025-11-20\">Nov 20 Ju, 2025</option>
<option value=\"2025-11-21\">Nov 21 Vi, 2025</option>
<option value=\"2025-11-22\">Nov 22 Sá, 2025</option>
<option value=\"2025-11-23\">Nov 23 Do, 2025</option>
<option value=\"2025-11-24\">Nov 24 Lu, 2025</option>
<option value=\"2025-11-25\">Nov 25 Ma, 2025</option>
<option value=\"2025-11-26\">Nov 26 Mi, 2025</option>
<option value=\"2025-11-27\">Nov 27 Ju, 2025</option>
<option value=\"2025-11-28\">Nov 28 Vi, 2025</option>
<option value=\"2025-11-29\">Nov 29 Sá, 2025</option>
<option value=\"2025-11-30\">Nov 30 Do, 2025</option>
<option value=\"2025-12-01\">Dic 01 Lu, 2025</option>
<option value=\"2025-12-02\">Dic 02 Ma, 2025</option>
<option value=\"2025-12-03\">Dic 03 Mi, 2025</option>
<option value=\"2025-12-04\">Dic 04 Ju, 2025</option>
<option value=\"2025-12-05\">Dic 05 Vi, 2025</option>
<option value=\"2025-12-06\">Dic 06 Sá, 2025</option>
<option value=\"2025-12-07\">Dic 07 Do, 2025</option>
<option value=\"2025-12-08\">Dic 08 Lu, 2025</option>
<option value=\"2025-12-09\">Dic 09 Ma, 2025</option>
<option value=\"2025-12-10\">Dic 10 Mi, 2025</option>
<option value=\"2025-12-11\">Dic 11 Ju, 2025</option>
<option value=\"2025-12-12\">Dic 12 Vi, 2025</option>
<option value=\"2025-12-13\">Dic 13 Sá, 2025</option>
<option value=\"2025-12-14\">Dic 14 Do, 2025</option>
<option value=\"2025-12-15\">Dic 15 Lu, 2025</option>
<option value=\"2025-12-16\">Dic 16 Ma, 2025</option>
<option value=\"2025-12-17\">Dic 17 Mi, 2025</option>
<option value=\"2025-12-18\">Dic 18 Ju, 2025</option>
<option value=\"2025-12-19\">Dic 19 Vi, 2025</option>
<option value=\"2025-12-20\">Dic 20 Sá, 2025</option>
<option value=\"2025-12-21\">Dic 21 Do, 2025</option>
<option value=\"2025-12-22\">Dic 22 Lu, 2025</option>
<option value=\"2025-12-23\">Dic 23 Ma, 2025</option>
<option value=\"2025-12-24\">Dic 24 Mi, 2025</option>
<option value=\"2025-12-25\">Dic 25 Ju, 2025</option>
<option value=\"2025-12-26\">Dic 26 Vi, 2025</option>
<option value=\"2025-12-27\">Dic 27 Sá, 2025</option>
<option value=\"2025-12-28\">Dic 28 Do, 2025</option>
<option value=\"2025-12-29\">Dic 29 Lu, 2025</option>
<option value=\"2025-12-30\">Dic 30 Ma, 2025</option>
<option value=\"2025-12-31\">Dic 31 Mi, 2025</option>
<option value=\"2026-01-01\">Ene 01 Ju, 2026</option>
<option value=\"2026-01-02\">Ene 02 Vi, 2026</option>
<option value=\"2026-01-03\">Ene 03 Sá, 2026</option>
<option value=\"2026-01-04\">Ene 04 Do, 2026</option>
<option value=\"2026-01-05\">Ene 05 Lu, 2026</option>
<option value=\"2026-01-06\">Ene 06 Ma, 2026</option>
<option value=\"2026-01-07\">Ene 07 Mi, 2026</option>
<option value=\"2026-01-08\">Ene 08 Ju, 2026</option>
<option value=\"2026-01-09\">Ene 09 Vi, 2026</option>
<option value=\"2026-01-10\">Ene 10 Sá, 2026</option>
<option value=\"2026-01-11\">Ene 11 Do, 2026</option>
<option value=\"2026-01-12\">Ene 12 Lu, 2026</option>
<option value=\"2026-01-13\">Ene 13 Ma, 2026</option>
<option value=\"2026-01-14\">Ene 14 Mi, 2026</option>
<option value=\"2026-01-15\">Ene 15 Ju, 2026</option>
<option value=\"2026-01-16\">Ene 16 Vi, 2026</option>
<option value=\"2026-01-17\">Ene 17 Sá, 2026</option>
<option value=\"2026-01-18\">Ene 18 Do, 2026</option>
<option value=\"2026-01-19\">Ene 19 Lu, 2026</option>
<option value=\"2026-01-20\">Ene 20 Ma, 2026</option>
<option value=\"2026-01-21\">Ene 21 Mi, 2026</option>
<option value=\"2026-01-22\">Ene 22 Ju, 2026</option>
<option value=\"2026-01-23\">Ene 23 Vi, 2026</option>
<option value=\"2026-01-24\">Ene 24 Sá, 2026</option>
<option value=\"2026-01-25\">Ene 25 Do, 2026</option>
<option value=\"2026-01-26\">Ene 26 Lu, 2026</option>
<option value=\"2026-01-27\">Ene 27 Ma, 2026</option>
<option value=\"2026-01-28\">Ene 28 Mi, 2026</option>
<option value=\"2026-01-29\">Ene 29 Ju, 2026</option>
<option value=\"2026-01-30\">Ene 30 Vi, 2026</option>
<option value=\"2026-01-31\">Ene 31 Sá, 2026</option>
<option value=\"2026-02-01\">Feb 01 Do, 2026</option>
<option value=\"2026-02-02\">Feb 02 Lu, 2026</option>
<option value=\"2026-02-03\">Feb 03 Ma, 2026</option>
<option value=\"2026-02-04\">Feb 04 Mi, 2026</option>
<option value=\"2026-02-05\">Feb 05 Ju, 2026</option>
<option value=\"2026-02-06\">Feb 06 Vi, 2026</option>
<option value=\"2026-02-07\">Feb 07 Sá, 2026</option>
<option value=\"2026-02-08\">Feb 08 Do, 2026</option>
<option value=\"2026-02-09\">Feb 09 Lu, 2026</option>
<option value=\"2026-02-10\">Feb 10 Ma, 2026</option>
<option value=\"2026-02-11\">Feb 11 Mi, 2026</option>
<option value=\"2026-02-12\">Feb 12 Ju, 2026</option>
<option value=\"2026-02-13\">Feb 13 Vi, 2026</option>
<option value=\"2026-02-14\">Feb 14 Sá, 2026</option>
<option value=\"2026-02-15\">Feb 15 Do, 2026</option>
<option value=\"2026-02-16\">Feb 16 Lu, 2026</option>
<option value=\"2026-02-17\">Feb 17 Ma, 2026</option>
<option value=\"2026-02-18\">Feb 18 Mi, 2026</option>
<option value=\"2026-02-19\">Feb 19 Ju, 2026</option>
<option value=\"2026-02-20\">Feb 20 Vi, 2026</option>
<option value=\"2026-02-21\">Feb 21 Sá, 2026</option>
<option value=\"2026-02-22\">Feb 22 Do, 2026</option>
<option value=\"2026-02-23\">Feb 23 Lu, 2026</option>
<option value=\"2026-02-24\">Feb 24 Ma, 2026</option>
<option value=\"2026-02-25\">Feb 25 Mi, 2026</option>
<option value=\"2026-02-26\">Feb 26 Ju, 2026</option>
<option value=\"2026-02-27\">Feb 27 Vi, 2026</option>
<option value=\"2026-02-28\">Feb 28 Sá, 2026</option>
<option value=\"2026-03-01\">Mar 01 Do, 2026</option>
<option value=\"2026-03-02\">Mar 02 Lu, 2026</option>
<option value=\"2026-03-03\">Mar 03 Ma, 2026</option>
<option value=\"2026-03-04\">Mar 04 Mi, 2026</option>
<option value=\"2026-03-05\">Mar 05 Ju, 2026</option>
<option value=\"2026-03-06\">Mar 06 Vi, 2026</option>
<option value=\"2026-03-07\">Mar 07 Sá, 2026</option>
<option value=\"2026-03-08\">Mar 08 Do, 2026</option>
<option value=\"2026-03-09\">Mar 09 Lu, 2026</option>
<option value=\"2026-03-10\">Mar 10 Ma, 2026</option>
<option value=\"2026-03-11\">Mar 11 Mi, 2026</option>
<option value=\"2026-03-12\">Mar 12 Ju, 2026</option>
<option value=\"2026-03-13\">Mar 13 Vi, 2026</option>
<option value=\"2026-03-14\">Mar 14 Sá, 2026</option>
<option value=\"2026-03-15\">Mar 15 Do, 2026</option>
<option value=\"2026-03-16\">Mar 16 Lu, 2026</option>
<option value=\"2026-03-17\">Mar 17 Ma, 2026</option>
<option value=\"2026-03-18\">Mar 18 Mi, 2026</option>
<option value=\"2026-03-19\">Mar 19 Ju, 2026</option>
<option value=\"2026-03-20\">Mar 20 Vi, 2026</option>
<option value=\"2026-03-21\">Mar 21 Sá, 2026</option>
<option value=\"2026-03-22\">Mar 22 Do, 2026</option>
<option value=\"2026-03-23\">Mar 23 Lu, 2026</option>
<option value=\"2026-03-24\">Mar 24 Ma, 2026</option>
<option value=\"2026-03-25\">Mar 25 Mi, 2026</option>
<option value=\"2026-03-26\">Mar 26 Ju, 2026</option>
<option value=\"2026-03-27\">Mar 27 Vi, 2026</option>
<option value=\"2026-03-28\">Mar 28 Sá, 2026</option>
<option value=\"2026-03-29\">Mar 29 Do, 2026</option>
<option value=\"2026-03-30\">Mar 30 Lu, 2026</option>
<option value=\"2026-03-31\">Mar 31 Ma, 2026</option>
<option value=\"2026-04-01\">Abr 01 Mi, 2026</option>
<option value=\"2026-04-02\">Abr 02 Ju, 2026</option>
<option value=\"2026-04-03\">Abr 03 Vi, 2026</option>
<option value=\"2026-04-04\">Abr 04 Sá, 2026</option>
<option value=\"2026-04-05\">Abr 05 Do, 2026</option>
<option value=\"2026-04-06\">Abr 06 Lu, 2026</option>
<option value=\"2026-04-07\">Abr 07 Ma, 2026</option>
<option value=\"2026-04-08\">Abr 08 Mi, 2026</option>
<option value=\"2026-04-09\">Abr 09 Ju, 2026</option>
<option value=\"2026-04-10\">Abr 10 Vi, 2026</option>
<option value=\"2026-04-11\">Abr 11 Sá, 2026</option>
<option value=\"2026-04-12\">Abr 12 Do, 2026</option>
<option value=\"2026-04-13\">Abr 13 Lu, 2026</option>
<option value=\"2026-04-14\">Abr 14 Ma, 2026</option>
<option value=\"2026-04-15\">Abr 15 Mi, 2026</option>
<option value=\"2026-04-16\">Abr 16 Ju, 2026</option>
<option value=\"2026-04-17\">Abr 17 Vi, 2026</option>
<option value=\"2026-04-18\">Abr 18 Sá, 2026</option>
<option value=\"2026-04-19\">Abr 19 Do, 2026</option>
<option value=\"2026-04-20\">Abr 20 Lu, 2026</option>
<option value=\"2026-04-21\">Abr 21 Ma, 2026</option>
<option value=\"2026-04-22\">Abr 22 Mi, 2026</option>
<option value=\"2026-04-23\">Abr 23 Ju, 2026</option>
<option value=\"2026-04-24\">Abr 24 Vi, 2026</option>
<option value=\"2026-04-25\">Abr 25 Sá, 2026</option>
<option value=\"2026-04-26\">Abr 26 Do, 2026</option>
<option value=\"2026-04-27\">Abr 27 Lu, 2026</option>
<option value=\"2026-04-28\">Abr 28 Ma, 2026</option>
<option value=\"2026-04-29\">Abr 29 Mi, 2026</option>
<option value=\"2026-04-30\">Abr 30 Ju, 2026</option>
<option value=\"2026-05-01\">May 01 Vi, 2026</option>
<option value=\"2026-05-02\">May 02 Sá, 2026</option>
<option value=\"2026-05-03\">May 03 Do, 2026</option>
<option value=\"2026-05-04\">May 04 Lu, 2026</option>
<option value=\"2026-05-05\">May 05 Ma, 2026</option>
<option value=\"2026-05-06\">May 06 Mi, 2026</option>
<option value=\"2026-05-07\">May 07 Ju, 2026</option>
<option value=\"2026-05-08\">May 08 Vi, 2026</option>
<option value=\"2026-05-09\">May 09 Sá, 2026</option>
<option value=\"2026-05-10\">May 10 Do, 2026</option>
<option value=\"2026-05-11\">May 11 Lu, 2026</option>
<option value=\"2026-05-12\">May 12 Ma, 2026</option>
<option value=\"2026-05-13\">May 13 Mi, 2026</option>
<option value=\"2026-05-14\">May 14 Ju, 2026</option>
<option value=\"2026-05-15\">May 15 Vi, 2026</option>
<option value=\"2026-05-16\">May 16 Sá, 2026</option>
<option value=\"2026-05-17\">May 17 Do, 2026</option>
<option value=\"2026-05-18\">May 18 Lu, 2026</option>
<option value=\"2026-05-19\">May 19 Ma, 2026</option>
<option value=\"2026-05-20\">May 20 Mi, 2026</option>
<option value=\"2026-05-21\">May 21 Ju, 2026</option>
<option value=\"2026-05-22\">May 22 Vi, 2026</option>
<option value=\"2026-05-23\">May 23 Sá, 2026</option>
<option value=\"2026-05-24\">May 24 Do, 2026</option>
<option value=\"2026-05-25\">May 25 Lu, 2026</option>
<option value=\"2026-05-26\">May 26 Ma, 2026</option>
<option value=\"2026-05-27\">May 27 Mi, 2026</option>
<option value=\"2026-05-28\">May 28 Ju, 2026</option>
<option value=\"2026-05-29\">May 29 Vi, 2026</option>
<option value=\"2026-05-30\">May 30 Sá, 2026</option>
<option value=\"2026-05-31\">May 31 Do, 2026</option>
<option value=\"2026-06-01\">Jun 01 Lu, 2026</option>
<option value=\"2026-06-02\">Jun 02 Ma, 2026</option>
<option value=\"2026-06-03\">Jun 03 Mi, 2026</option>
<option value=\"2026-06-04\">Jun 04 Ju, 2026</option>
<option value=\"2026-06-05\">Jun 05 Vi, 2026</option>
<option value=\"2026-06-06\">Jun 06 Sá, 2026</option>
<option value=\"2026-06-07\">Jun 07 Do, 2026</option>
<option value=\"2026-06-08\">Jun 08 Lu, 2026</option>
<option value=\"2026-06-09\">Jun 09 Ma, 2026</option>
<option value=\"2026-06-10\">Jun 10 Mi, 2026</option>
<option value=\"2026-06-11\">Jun 11 Ju, 2026</option>
<option value=\"2026-06-12\">Jun 12 Vi, 2026</option>
<option value=\"2026-06-13\">Jun 13 Sá, 2026</option>
<option value=\"2026-06-14\">Jun 14 Do, 2026</option>
<option value=\"2026-06-15\">Jun 15 Lu, 2026</option>
<option value=\"2026-06-16\">Jun 16 Ma, 2026</option>
<option value=\"2026-06-17\">Jun 17 Mi, 2026</option>
<option value=\"2026-06-18\">Jun 18 Ju, 2026</option>
<option value=\"2026-06-19\">Jun 19 Vi, 2026</option>
<option value=\"2026-06-20\">Jun 20 Sá, 2026</option>
<option value=\"2026-06-21\">Jun 21 Do, 2026</option>
<option value=\"2026-06-22\">Jun 22 Lu, 2026</option>
<option value=\"2026-06-23\">Jun 23 Ma, 2026</option>
<option value=\"2026-06-24\">Jun 24 Mi, 2026</option>
<option value=\"2026-06-25\">Jun 25 Ju, 2026</option>
<option value=\"2026-06-26\">Jun 26 Vi, 2026</option>
<option value=\"2026-06-27\">Jun 27 Sá, 2026</option>
<option value=\"2026-06-28\">Jun 28 Do, 2026</option>
<option value=\"2026-06-29\">Jun 29 Lu, 2026</option>
<option value=\"2026-06-30\">Jun 30 Ma, 2026</option>
<option value=\"2026-07-01\">Jul 01 Mi, 2026</option>
<option value=\"2026-07-02\">Jul 02 Ju, 2026</option>
<option value=\"2026-07-03\">Jul 03 Vi, 2026</option>
<option value=\"2026-07-04\">Jul 04 Sá, 2026</option>
<option value=\"2026-07-05\">Jul 05 Do, 2026</option>
<option value=\"2026-07-06\">Jul 06 Lu, 2026</option>
<option value=\"2026-07-07\">Jul 07 Ma, 2026</option>
<option value=\"2026-07-08\">Jul 08 Mi, 2026</option>
<option value=\"2026-07-09\">Jul 09 Ju, 2026</option>
<option value=\"2026-07-10\">Jul 10 Vi, 2026</option>
<option value=\"2026-07-11\">Jul 11 Sá, 2026</option>
<option value=\"2026-07-12\">Jul 12 Do, 2026</option>
<option value=\"2026-07-13\">Jul 13 Lu, 2026</option>
<option value=\"2026-07-14\">Jul 14 Ma, 2026</option>
<option value=\"2026-07-15\">Jul 15 Mi, 2026</option>
<option value=\"2026-07-16\">Jul 16 Ju, 2026</option>
<option value=\"2026-07-17\">Jul 17 Vi, 2026</option>
<option value=\"2026-07-18\">Jul 18 Sá, 2026</option>
<option value=\"2026-07-19\">Jul 19 Do, 2026</option>
<option value=\"2026-07-20\">Jul 20 Lu, 2026</option>
<option value=\"2026-07-21\">Jul 21 Ma, 2026</option>
<option value=\"2026-07-22\">Jul 22 Mi, 2026</option>
<option value=\"2026-07-23\">Jul 23 Ju, 2026</option>
<option value=\"2026-07-24\">Jul 24 Vi, 2026</option>
<option value=\"2026-07-25\">Jul 25 Sá, 2026</option>
<option value=\"2026-07-26\">Jul 26 Do, 2026</option>
<option value=\"2026-07-27\">Jul 27 Lu, 2026</option>
<option value=\"2026-07-28\">Jul 28 Ma, 2026</option>
<option value=\"2026-07-29\">Jul 29 Mi, 2026</option>
<option value=\"2026-07-30\">Jul 30 Ju, 2026</option>
<option value=\"2026-07-31\">Jul 31 Vi, 2026</option>
<option value=\"2026-08-01\">Ago 01 Sá, 2026</option>
<option value=\"2026-08-02\">Ago 02 Do, 2026</option>
<option value=\"2026-08-03\">Ago 03 Lu, 2026</option>
<option value=\"2026-08-04\">Ago 04 Ma, 2026</option>
<option value=\"2026-08-05\">Ago 05 Mi, 2026</option>
<option value=\"2026-08-06\">Ago 06 Ju, 2026</option>
<option value=\"2026-08-07\">Ago 07 Vi, 2026</option>
<option value=\"2026-08-08\">Ago 08 Sá, 2026</option>
<option value=\"2026-08-09\">Ago 09 Do, 2026</option>
<option value=\"2026-08-10\">Ago 10 Lu, 2026</option>
<option value=\"2026-08-11\">Ago 11 Ma, 2026</option>
<option value=\"2026-08-12\">Ago 12 Mi, 2026</option>
<option value=\"2026-08-13\">Ago 13 Ju, 2026</option>
<option value=\"2026-08-14\">Ago 14 Vi, 2026</option>
<option value=\"2026-08-15\">Ago 15 Sá, 2026</option>
<option value=\"2026-08-16\">Ago 16 Do, 2026</option>
<option value=\"2026-08-17\">Ago 17 Lu, 2026</option>
<option value=\"2026-08-18\">Ago 18 Ma, 2026</option>
<option value=\"2026-08-19\">Ago 19 Mi, 2026</option>
<option value=\"2026-08-20\">Ago 20 Ju, 2026</option>
<option value=\"2026-08-21\">Ago 21 Vi, 2026</option>
<option value=\"2026-08-22\">Ago 22 Sá, 2026</option>
<option value=\"2026-08-23\">Ago 23 Do, 2026</option>
<option value=\"2026-08-24\">Ago 24 Lu, 2026</option>
<option value=\"2026-08-25\">Ago 25 Ma, 2026</option>
<option value=\"2026-08-26\">Ago 26 Mi, 2026</option>
<option value=\"2026-08-27\">Ago 27 Ju, 2026</option>
<option value=\"2026-08-28\">Ago 28 Vi, 2026</option>
<option value=\"2026-08-29\">Ago 29 Sá, 2026</option>
<option value=\"2026-08-30\">Ago 30 Do, 2026</option>
<option value=\"2026-08-31\">Ago 31 Lu, 2026</option>
<option value=\"2026-09-01\">Sep 01 Ma, 2026</option>
<option value=\"2026-09-02\">Sep 02 Mi, 2026</option>
<option value=\"2026-09-03\">Sep 03 Ju, 2026</option>
<option value=\"2026-09-04\">Sep 04 Vi, 2026</option>
<option value=\"2026-09-05\">Sep 05 Sá, 2026</option>
<option value=\"2026-09-06\">Sep 06 Do, 2026</option>
<option value=\"2026-09-07\">Sep 07 Lu, 2026</option>
<option value=\"2026-09-08\">Sep 08 Ma, 2026</option>
<option value=\"2026-09-09\">Sep 09 Mi, 2026</option>
<option value=\"2026-09-10\">Sep 10 Ju, 2026</option>
<option value=\"2026-09-11\">Sep 11 Vi, 2026</option>
<option value=\"2026-09-12\">Sep 12 Sá, 2026</option>
<option value=\"2026-09-13\">Sep 13 Do, 2026</option>
<option value=\"2026-09-14\">Sep 14 Lu, 2026</option>
<option value=\"2026-09-15\">Sep 15 Ma, 2026</option>
<option value=\"2026-09-16\">Sep 16 Mi, 2026</option>
<option value=\"2026-09-17\">Sep 17 Ju, 2026</option>
<option value=\"2026-09-18\">Sep 18 Vi, 2026</option>
<option value=\"2026-09-19\">Sep 19 Sá, 2026</option>
<option value=\"2026-09-20\">Sep 20 Do, 2026</option>
<option value=\"2026-09-21\">Sep 21 Lu, 2026</option>
<option value=\"2026-09-22\">Sep 22 Ma, 2026</option>
<option value=\"2026-09-23\">Sep 23 Mi, 2026</option>
<option value=\"2026-09-24\">Sep 24 Ju, 2026</option>
<option value=\"2026-09-25\">Sep 25 Vi, 2026</option>
<option value=\"2026-09-26\">Sep 26 Sá, 2026</option>
<option value=\"2026-09-27\">Sep 27 Do, 2026</option>
<option value=\"2026-09-28\">Sep 28 Lu, 2026</option>
<option value=\"2026-09-29\">Sep 29 Ma, 2026</option>
<option value=\"2026-09-30\">Sep 30 Mi, 2026</option>
<option value=\"2026-10-01\">Oct 01 Ju, 2026</option>
<option value=\"2026-10-02\">Oct 02 Vi, 2026</option>
<option value=\"2026-10-03\">Oct 03 Sá, 2026</option>
<option value=\"2026-10-04\">Oct 04 Do, 2026</option>
<option value=\"2026-10-05\">Oct 05 Lu, 2026</option>
<option value=\"2026-10-06\">Oct 06 Ma, 2026</option>
<option value=\"2026-10-07\">Oct 07 Mi, 2026</option>
<option value=\"2026-10-08\">Oct 08 Ju, 2026</option>
<option value=\"2026-10-09\">Oct 09 Vi, 2026</option>
<option value=\"2026-10-10\">Oct 10 Sá, 2026</option>
<option value=\"2026-10-11\">Oct 11 Do, 2026</option>
<option value=\"2026-10-12\">Oct 12 Lu, 2026</option>
<option value=\"2026-10-13\">Oct 13 Ma, 2026</option>
<option value=\"2026-10-14\">Oct 14 Mi, 2026</option>
<option value=\"2026-10-15\">Oct 15 Ju, 2026</option>
<option value=\"2026-10-16\">Oct 16 Vi, 2026</option>
<option value=\"2026-10-17\">Oct 17 Sá, 2026</option>
<option value=\"2026-10-18\">Oct 18 Do, 2026</option>
<option value=\"2026-10-19\">Oct 19 Lu, 2026</option>
<option value=\"2026-10-20\">Oct 20 Ma, 2026</option>
<option value=\"2026-10-21\">Oct 21 Mi, 2026</option>
<option value=\"2026-10-22\">Oct 22 Ju, 2026</option>
<option value=\"2026-10-23\">Oct 23 Vi, 2026</option>
<option value=\"2026-10-24\">Oct 24 Sá, 2026</option>
<option value=\"2026-10-25\">Oct 25 Do, 2026</option>
<option value=\"2026-10-26\">Oct 26 Lu, 2026</option>
<option value=\"2026-10-27\">Oct 27 Ma, 2026</option>
<option value=\"2026-10-28\">Oct 28 Mi, 2026</option>
<option value=\"2026-10-29\">Oct 29 Ju, 2026</option>
<option value=\"2026-10-30\">Oct 30 Vi, 2026</option>
<option value=\"2026-10-31\">Oct 31 Sá, 2026</option>
<option value=\"2026-11-01\">Nov 01 Do, 2026</option>
<option value=\"2026-11-02\">Nov 02 Lu, 2026</option>
<option value=\"2026-11-03\">Nov 03 Ma, 2026</option>
<option value=\"2026-11-04\">Nov 04 Mi, 2026</option>
<option value=\"2026-11-05\">Nov 05 Ju, 2026</option>
<option value=\"2026-11-06\">Nov 06 Vi, 2026</option>
<option value=\"2026-11-07\">Nov 07 Sá, 2026</option>
<option value=\"2026-11-08\">Nov 08 Do, 2026</option>
<option value=\"2026-11-09\">Nov 09 Lu, 2026</option>
<option value=\"2026-11-10\">Nov 10 Ma, 2026</option>
<option value=\"2026-11-11\">Nov 11 Mi, 2026</option>
<option value=\"2026-11-12\">Nov 12 Ju, 2026</option>
<option value=\"2026-11-13\">Nov 13 Vi, 2026</option>
<option value=\"2026-11-14\">Nov 14 Sá, 2026</option>
<option value=\"2026-11-15\">Nov 15 Do, 2026</option>
<option value=\"2026-11-16\">Nov 16 Lu, 2026</option>
<option value=\"2026-11-17\">Nov 17 Ma, 2026</option>
<option value=\"2026-11-18\">Nov 18 Mi, 2026</option>
<option value=\"2026-11-19\">Nov 19 Ju, 2026</option>
<option value=\"2026-11-20\">Nov 20 Vi, 2026</option>
<option value=\"2026-11-21\">Nov 21 Sá, 2026</option>
<option value=\"2026-11-22\">Nov 22 Do, 2026</option>
<option value=\"2026-11-23\">Nov 23 Lu, 2026</option>
<option value=\"2026-11-24\">Nov 24 Ma, 2026</option>
<option value=\"2026-11-25\">Nov 25 Mi, 2026</option>
<option value=\"2026-11-26\">Nov 26 Ju, 2026</option>
<option value=\"2026-11-27\">Nov 27 Vi, 2026</option>
<option value=\"2026-11-28\">Nov 28 Sá, 2026</option>
<option value=\"2026-11-29\">Nov 29 Do, 2026</option>
<option value=\"2026-11-30\">Nov 30 Lu, 2026</option>
<option value=\"2026-12-01\">Dic 01 Ma, 2026</option>
<option value=\"2026-12-02\">Dic 02 Mi, 2026</option>
<option value=\"2026-12-03\">Dic 03 Ju, 2026</option>
<option value=\"2026-12-04\">Dic 04 Vi, 2026</option>
<option value=\"2026-12-05\">Dic 05 Sá, 2026</option>
<option value=\"2026-12-06\">Dic 06 Do, 2026</option>
<option value=\"2026-12-07\">Dic 07 Lu, 2026</option>
<option value=\"2026-12-08\">Dic 08 Ma, 2026</option>
<option value=\"2026-12-09\">Dic 09 Mi, 2026</option>
<option value=\"2026-12-10\">Dic 10 Ju, 2026</option>
<option value=\"2026-12-11\">Dic 11 Vi, 2026</option>
<option value=\"2026-12-12\">Dic 12 Sá, 2026</option>
<option value=\"2026-12-13\">Dic 13 Do, 2026</option>
<option value=\"2026-12-14\">Dic 14 Lu, 2026</option>
<option value=\"2026-12-15\">Dic 15 Ma, 2026</option>
<option value=\"2026-12-16\">Dic 16 Mi, 2026</option>
<option value=\"2026-12-17\">Dic 17 Ju, 2026</option>
<option value=\"2026-12-18\">Dic 18 Vi, 2026</option>
<option value=\"2026-12-19\">Dic 19 Sá, 2026</option>
<option value=\"2026-12-20\">Dic 20 Do, 2026</option>
<option value=\"2026-12-21\">Dic 21 Lu, 2026</option>
<option value=\"2026-12-22\">Dic 22 Ma, 2026</option>
<option value=\"2026-12-23\">Dic 23 Mi, 2026</option>
<option value=\"2026-12-24\">Dic 24 Ju, 2026</option>
<option value=\"2026-12-25\">Dic 25 Vi, 2026</option>
<option value=\"2026-12-26\">Dic 26 Sá, 2026</option>
<option value=\"2026-12-27\">Dic 27 Do, 2026</option>
<option value=\"2026-12-28\">Dic 28 Lu, 2026</option>
<option value=\"2026-12-29\">Dic 29 Ma, 2026</option>
<option value=\"2026-12-30\">Dic 30 Mi, 2026</option>
<option value=\"2026-12-31\">Dic 31 Ju, 2026</option>
<option value=\"2027-01-01\">Ene 01 Vi, 2027</option>

";

?></contenuto>
</file>
<database>
<tabella>
<nometabella>anni</nometabella>
<colonnetabella>
<nomecolonna>idanni</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>tipo_periodi</nomecolonna>
<tipocolonna>252</tipocolonna>
</colonnetabella>
<righetabella>
<riga><cmp>2025</cmp><cmp>g</cmp></riga>
</righetabella>
</tabella>
<tabella>
<nometabella>appartamenti</nometabella>
<colonnetabella>
<nomecolonna>idappartamenti</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>numpiano</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>maxoccupanti</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>numcasa</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>app_vicini</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>priorita</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>priorita2</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>letto</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>commento</nomecolonna>
<tipocolonna>252</tipocolonna>
</colonnetabella>
<righetabella>
<riga><cmp>15</cmp><cmp>0</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>16</cmp><cmp>0</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>18</cmp><cmp>0</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>20</cmp><cmp>0</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>21</cmp><cmp>0</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>22</cmp><cmp>0</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>23</cmp><cmp>0</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>24</cmp><cmp>0</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>25</cmp><cmp>0</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>26</cmp><cmp>0</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>27</cmp><cmp>0</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>28</cmp><cmp>0</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>29</cmp><cmp>0</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>30</cmp><cmp>0</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>31</cmp><cmp>0</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>32</cmp><cmp>0</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>33</cmp><cmp>0</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>34</cmp><cmp>0</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>35</cmp><cmp>0</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>36</cmp><cmp>0</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>37</cmp><cmp>0</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>38</cmp><cmp>0</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>39</cmp><cmp>0</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>40</cmp><cmp>0</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>41</cmp><cmp>0</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>42</cmp><cmp>0</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>43</cmp><cmp>0</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>44</cmp><cmp>0</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>45</cmp><cmp>0</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>46</cmp><cmp>0</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>201</cmp><cmp>2</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>202</cmp><cmp>2</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>203</cmp><cmp>2</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>204</cmp><cmp>2</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>205</cmp><cmp>2</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>206</cmp><cmp>2</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>207</cmp><cmp>2</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>208</cmp><cmp>2</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>209</cmp><cmp>2</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>210</cmp><cmp>2</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>211</cmp><cmp>2</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
</righetabella>
</tabella>
<tabella>
<nometabella>clienti</nometabella>
<colonnetabella>
<nomecolonna>idclienti</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>cognome</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>nome</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>soprannome</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>sesso</nomecolonna>
<tipocolonna>254</tipocolonna>
<nomecolonna>titolo</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>lingua</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>datanascita</nomecolonna>
<tipocolonna>10</tipocolonna>
<nomecolonna>cittanascita</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>regionenascita</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>nazionenascita</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>documento</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>scadenzadoc</nomecolonna>
<tipocolonna>10</tipocolonna>
<nomecolonna>tipodoc</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>cittadoc</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>regionedoc</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>nazionedoc</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>nazionalita</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>nazione</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>regione</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>citta</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>via</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>numcivico</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>cap</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>telefono</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>telefono2</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>telefono3</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>fax</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>email</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>email2</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>email3</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>cod_fiscale</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>partita_iva</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>commento</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>max_num_ordine</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>idclienti_compagni</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>doc_inviati</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>datainserimento</nomecolonna>
<tipocolonna>12</tipocolonna>
<nomecolonna>hostinserimento</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>utente_inserimento</nomecolonna>
<tipocolonna>3</tipocolonna>
</colonnetabella>
<righetabella>
</righetabella>
</tabella>
<tabella>
<nometabella>relclienti</nometabella>
<colonnetabella>
<nomecolonna>idclienti</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>numero</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>tipo</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>testo1</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>testo2</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>testo3</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>testo4</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>testo5</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>testo6</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>testo7</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>testo8</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>datainserimento</nomecolonna>
<tipocolonna>12</tipocolonna>
<nomecolonna>hostinserimento</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>utente_inserimento</nomecolonna>
<tipocolonna>3</tipocolonna>
</colonnetabella>
<righetabella>
</righetabella>
</tabella>
<tabella>
<nometabella>personalizza</nometabella>
<colonnetabella>
<nomecolonna>idpersonalizza</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>idutente</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>valpersonalizza</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>valpersonalizza_num</nomecolonna>
<tipocolonna>3</tipocolonna>
</colonnetabella>
<righetabella>
<riga><cmp>col_tab_tutte_prenota</cmp><cmp>1</cmp><cmp>nu#@&cg#@&in#@&fi#@&tc#@&ca#@&pa#@&ap#@&pe#@&co</cmp><cmp></cmp></riga>
<riga><cmp>rig_tab_tutte_prenota</cmp><cmp>1</cmp><cmp>to#@&ta#@&ca#@&pc</cmp><cmp></cmp></riga>
<riga><cmp>modo_invio_email</cmp><cmp>1</cmp><cmp>locale</cmp><cmp></cmp></riga>
<riga><cmp>maschera_email</cmp><cmp>1</cmp><cmp>NO</cmp><cmp></cmp></riga>
<riga><cmp>dati_struttura</cmp><cmp>1</cmp><cmp>#@&#@&#@&#@&#@&#@&#@&#@&#@&#@&#@&#@&</cmp><cmp></cmp></riga>
<riga><cmp>valuta</cmp><cmp>1</cmp><cmp>Euros</cmp><cmp></cmp></riga>
<riga><cmp>arrotond_predef</cmp><cmp>1</cmp><cmp>1</cmp><cmp></cmp></riga>
<riga><cmp>arrotond_tasse</cmp><cmp>1</cmp><cmp>0.01</cmp><cmp></cmp></riga>
<riga><cmp>stile_soldi</cmp><cmp>1</cmp><cmp>europa</cmp><cmp></cmp></riga>
<riga><cmp>costi_agg_in_tab_prenota</cmp><cmp>1</cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>aggiunta_tronca_nomi_tab1</cmp><cmp>1</cmp><cmp></cmp><cmp>-2</cmp></riga>
<riga><cmp>linee_ripeti_date_tab_mesi</cmp><cmp>1</cmp><cmp></cmp><cmp>25</cmp></riga>
<riga><cmp>mostra_giorni_tab_mesi</cmp><cmp>1</cmp><cmp>SI</cmp><cmp></cmp></riga>
<riga><cmp>colori_tab_mesi</cmp><cmp>1</cmp><cmp>#70C6D4,#FFD800,#FF9900,#FF3115</cmp><cmp></cmp></riga>
<riga><cmp>num_linee_tab2_prenota</cmp><cmp>1</cmp><cmp></cmp><cmp>30</cmp></riga>
<riga><cmp>nomi_contratti</cmp><cmp>1</cmp><cmp>1#?&Ejemplo#@&2#?&Factura#@&3#?&Factura - rtf#@&4#?&Recibo último pago#@&5#?&Recibo - rtf#@&6#?&Email disponibilidad#@&7#?&Email confirmación#@&8#?&Email bienvenida#@&9#?&Informe limpieza#@&10#?&Exportar datos clientes#@&11#?&Exportar reservas</cmp><cmp></cmp></riga>
<riga><cmp>num_righe_tab_tutte_prenota</cmp><cmp>1</cmp><cmp></cmp><cmp>200</cmp></riga>
<riga><cmp>selezione_tab_tutte_prenota</cmp><cmp>1</cmp><cmp>tutte</cmp><cmp></cmp></riga>
<riga><cmp>num_righe_tab_tutti_clienti</cmp><cmp>1</cmp><cmp></cmp><cmp>200</cmp></riga>
<riga><cmp>num_righe_tab_casse</cmp><cmp>1</cmp><cmp></cmp><cmp>50</cmp></riga>
<riga><cmp>tot_giornalero_tab_casse</cmp><cmp>1</cmp><cmp>gior,mens,tab</cmp><cmp></cmp></riga>
<riga><cmp>num_righe_tab_messaggi</cmp><cmp>1</cmp><cmp></cmp><cmp>80</cmp></riga>
<riga><cmp>num_righe_tab_doc_salvati</cmp><cmp>1</cmp><cmp></cmp><cmp>100</cmp></riga>
<riga><cmp>num_righe_tab_storia_soldi</cmp><cmp>1</cmp><cmp></cmp><cmp>200</cmp></riga>
<riga><cmp>stile_data</cmp><cmp>1</cmp><cmp>europa</cmp><cmp></cmp></riga>
<riga><cmp>stile_nomi</cmp><cmp>1</cmp><cmp>ma1or</cmp><cmp></cmp></riga>
<riga><cmp>num_categorie_persone</cmp><cmp>1</cmp><cmp></cmp><cmp>1</cmp></riga>
<riga><cmp>minuti_durata_sessione</cmp><cmp>1</cmp><cmp></cmp><cmp>90</cmp></riga>
<riga><cmp>usa_cookies</cmp><cmp>1</cmp><cmp></cmp><cmp>0</cmp></riga>
<riga><cmp>minuti_durata_insprenota</cmp><cmp>1</cmp><cmp></cmp><cmp>10</cmp></riga>
<riga><cmp>ore_anticipa_periodo_corrente</cmp><cmp>1</cmp><cmp></cmp><cmp>0</cmp></riga>
<riga><cmp>tutti_fissi</cmp><cmp>1</cmp><cmp>10</cmp><cmp></cmp></riga>
<riga><cmp>auto_crea_anno</cmp><cmp>1</cmp><cmp>SI</cmp><cmp></cmp></riga>
<riga><cmp>metodi_pagamento</cmp><cmp>1</cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>origini_prenota</cmp><cmp>1</cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>attiva_checkin</cmp><cmp>1</cmp><cmp>NO</cmp><cmp></cmp></riga>
<riga><cmp>mostra_quadro_disp</cmp><cmp>1</cmp><cmp>reg2</cmp><cmp></cmp></riga>
<riga><cmp>ultime_sel_ins_prezzi</cmp><cmp>1</cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>subordinazione</cmp><cmp>1</cmp><cmp>NO</cmp><cmp></cmp></riga>
<riga><cmp>percorso_cartella_modello</cmp><cmp>1</cmp><cmp>./dati</cmp><cmp></cmp></riga>
<riga><cmp>gest_cvc</cmp><cmp>1</cmp><cmp>NO</cmp><cmp></cmp></riga>
<riga><cmp>ordine_inventario</cmp><cmp>1</cmp><cmp>alf</cmp><cmp></cmp></riga>
<riga><cmp>tasti_pos</cmp><cmp>1</cmp><cmp>x2;x10;s;+1;+2;+3;+4;+5;+6;+7;+8;+9;s;-1</cmp><cmp></cmp></riga>
</righetabella>
</tabella>
<tabella>
<nometabella>versioni</nometabella>
<colonnetabella>
<nomecolonna>idversioni</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>num_versione</nomecolonna>
<tipocolonna>4</tipocolonna>
</colonnetabella>
<righetabella>
<riga><cmp>1</cmp><cmp>3.07</cmp></riga>
<riga><cmp>2</cmp><cmp>100</cmp></riga>
</righetabella>
</tabella>
<tabella>
<nometabella>utenti</nometabella>
<colonnetabella>
<nomecolonna>idutenti</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>nome_utente</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>password</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>salt</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>tipo_pass</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>datainserimento</nomecolonna>
<tipocolonna>12</tipocolonna>
<nomecolonna>hostinserimento</nomecolonna>
<tipocolonna>253</tipocolonna>
</colonnetabella>
<righetabella>
<riga><cmp>1</cmp><cmp>admin</cmp><cmp></cmp><cmp></cmp><cmp>n</cmp><cmp></cmp><cmp></cmp></riga>
</righetabella>
</tabella>
<tabella>
<nometabella>gruppi</nometabella>
<colonnetabella>
<nomecolonna>idgruppi</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>nome_gruppo</nomecolonna>
<tipocolonna>252</tipocolonna>
</colonnetabella>
<righetabella>
</righetabella>
</tabella>
<tabella>
<nometabella>privilegi</nometabella>
<colonnetabella>
<nomecolonna>idutente</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>anno</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>regole1_consentite</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>tariffe_consentite</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>costi_agg_consentiti</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>contratti_consentiti</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>casse_consentite</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>cassa_pagamenti</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>priv_ins_prenota</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>priv_mod_prenota</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>priv_mod_pers</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>priv_ins_clienti</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>prefisso_clienti</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>priv_ins_costi</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>priv_vedi_tab</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>priv_ins_tariffe</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>priv_ins_regole</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>priv_messaggi</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>priv_inventario</nomecolonna>
<tipocolonna>253</tipocolonna>
</colonnetabella>
<righetabella>
</righetabella>
</tabella>
<tabella>
<nometabella>sessioni</nometabella>
<colonnetabella>
<nomecolonna>idsessioni</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>idcliente</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>idutente</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>indirizzo_ip</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>tipo_conn</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>user_agent</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>ultimo_accesso</nomecolonna>
<tipocolonna>12</tipocolonna>
</colonnetabella>
<righetabella>
</righetabella>
</tabella>
<tabella>
<nometabella>transazioni</nometabella>
<colonnetabella>
<nomecolonna>idtransazioni</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>idcliente</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>idsessione</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>tipo_transazione</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>anno</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>spostamenti</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione1</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione2</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione3</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione4</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione5</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione6</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione7</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione8</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione9</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione10</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione11</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione12</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione13</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione14</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione15</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione16</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione17</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione18</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione19</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione20</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione21</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione22</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>ultimo_accesso</nomecolonna>
<tipocolonna>12</tipocolonna>
</colonnetabella>
<righetabella>
</righetabella>
</tabella>
<tabella>
<nometabella>transazioniweb</nometabella>
<colonnetabella>
<nomecolonna>idtransazioni</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>idcliente</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>idsessione</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>tipo_transazione</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>anno</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>spostamenti</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione1</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione2</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione3</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione4</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione5</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione6</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione7</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione8</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione9</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione10</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione11</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione12</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione13</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione14</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione15</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione16</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione17</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione18</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione19</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione20</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione21</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_transazione22</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>ultimo_accesso</nomecolonna>
<tipocolonna>12</tipocolonna>
</colonnetabella>
<righetabella>
<riga><cmp>2</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp>100</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
</righetabella>
</tabella>
<tabella>
<nometabella>descrizioni</nometabella>
<colonnetabella>
<nomecolonna>nome</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>tipo</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>lingua</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>numero</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>testo</nomecolonna>
<tipocolonna>252</tipocolonna>
</colonnetabella>
<righetabella>
</righetabella>
</tabella>
<tabella>
<nometabella>nazioni</nometabella>
<colonnetabella>
<nomecolonna>idnazioni</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>nome_nazione</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>codice_nazione</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>codice2_nazione</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>codice3_nazione</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>datainserimento</nomecolonna>
<tipocolonna>12</tipocolonna>
<nomecolonna>hostinserimento</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>utente_inserimento</nomecolonna>
<tipocolonna>3</tipocolonna>
</colonnetabella>
<righetabella>
<riga><cmp>1</cmp><cmp>Austria</cmp><cmp>AT</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>2</cmp><cmp>Bélgica</cmp><cmp>BE</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>3</cmp><cmp>República Checa</cmp><cmp>CZ</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>4</cmp><cmp>Chipre</cmp><cmp>CY</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>5</cmp><cmp>Dinamarca</cmp><cmp>DK</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>6</cmp><cmp>Estonia</cmp><cmp>EE</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>7</cmp><cmp>Finlandia</cmp><cmp>FI</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>8</cmp><cmp>Francia</cmp><cmp>FR</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>9</cmp><cmp>Alemania</cmp><cmp>DE</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>10</cmp><cmp>Grecia</cmp><cmp>GR</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>11</cmp><cmp>Irlanda</cmp><cmp>IE</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>12</cmp><cmp>Letonia</cmp><cmp>LV</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>13</cmp><cmp>Lituania</cmp><cmp>LT</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>14</cmp><cmp>Luxemburgo</cmp><cmp>LU</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>15</cmp><cmp>Malta</cmp><cmp>MT</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>16</cmp><cmp>Países Bajos</cmp><cmp>NL</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>17</cmp><cmp>Polonia</cmp><cmp>PL</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>18</cmp><cmp>Portugal</cmp><cmp>PT</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>19</cmp><cmp>Reino Unido</cmp><cmp>GB</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>20</cmp><cmp>Eslovaquia</cmp><cmp>SK</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>21</cmp><cmp>Eslovenia</cmp><cmp>SI</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>22</cmp><cmp>España</cmp><cmp>ES</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>23</cmp><cmp>Suecia</cmp><cmp>SE</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>24</cmp><cmp>Hungría</cmp><cmp>HU</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>25</cmp><cmp>Albania</cmp><cmp>AL</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>26</cmp><cmp>Andorra</cmp><cmp>AD</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>27</cmp><cmp>Belarús</cmp><cmp>BY</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>28</cmp><cmp>Bosnia Y Herzegovina</cmp><cmp>BA</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>29</cmp><cmp>Bulgaria</cmp><cmp>BG</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>30</cmp><cmp>Croacia</cmp><cmp>HR</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>31</cmp><cmp>Islanda</cmp><cmp>IS</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>32</cmp><cmp>Liechtenstein</cmp><cmp>LI</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>33</cmp><cmp>Macedonia</cmp><cmp>MK</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>34</cmp><cmp>Moldova</cmp><cmp>MD</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>35</cmp><cmp>Mónaco</cmp><cmp>MC</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>36</cmp><cmp>Montenegro</cmp><cmp>ME</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>37</cmp><cmp>Noruega</cmp><cmp>NO</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>38</cmp><cmp>Rumania</cmp><cmp>RO</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>39</cmp><cmp>Rusia</cmp><cmp>RU</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>40</cmp><cmp>San Marino</cmp><cmp>SM</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>41</cmp><cmp>Santa Sede</cmp><cmp>VA</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>42</cmp><cmp>Serbia</cmp><cmp>YU</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>43</cmp><cmp>Suiza</cmp><cmp>CH</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>44</cmp><cmp>Turquía</cmp><cmp>TR</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>45</cmp><cmp>Ucrania</cmp><cmp>UA</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>46</cmp><cmp>Afganistán</cmp><cmp>AF</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>47</cmp><cmp>Arabia Saudita</cmp><cmp>SA</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>48</cmp><cmp>Armenia</cmp><cmp>AM</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>49</cmp><cmp>Azerbaiyán</cmp><cmp>AZ</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>50</cmp><cmp>Bahrein</cmp><cmp>BH</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>51</cmp><cmp>Bangladesh</cmp><cmp>BD</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>52</cmp><cmp>Bhután</cmp><cmp>BT</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>53</cmp><cmp>Brunei</cmp><cmp>BN</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>54</cmp><cmp>Camboya</cmp><cmp>KH</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>55</cmp><cmp>China</cmp><cmp>CN</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>56</cmp><cmp>Corea Del Sur</cmp><cmp>KR</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>57</cmp><cmp>Corea Del Norte</cmp><cmp>KP</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>58</cmp><cmp>Emiratos Arabes Unidos</cmp><cmp>AE</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>59</cmp><cmp>Filipinas</cmp><cmp>PH</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>60</cmp><cmp>Georgia</cmp><cmp>GE</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>61</cmp><cmp>Japón</cmp><cmp>JP</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>62</cmp><cmp>Jordania</cmp><cmp>JO</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>63</cmp><cmp>India</cmp><cmp>IN</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>64</cmp><cmp>Indonesia</cmp><cmp>ID</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>65</cmp><cmp>Irán</cmp><cmp>IR</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>66</cmp><cmp>Iraq</cmp><cmp>IQ</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>67</cmp><cmp>Israel</cmp><cmp>IL</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>68</cmp><cmp>Kazajstán</cmp><cmp>KZ</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>69</cmp><cmp>Kirguistán</cmp><cmp>KG</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>70</cmp><cmp>Kuwait</cmp><cmp>KW</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>71</cmp><cmp>Lao</cmp><cmp>LA</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>72</cmp><cmp>Líbano</cmp><cmp>LB</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>73</cmp><cmp>Malasia</cmp><cmp>MY</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>74</cmp><cmp>Maldivas</cmp><cmp>MV</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>75</cmp><cmp>Mongolia</cmp><cmp>MN</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>76</cmp><cmp>Myanmar</cmp><cmp>MM</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>77</cmp><cmp>Nepal</cmp><cmp>NP</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>78</cmp><cmp>Omán</cmp><cmp>OM</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>79</cmp><cmp>Pakistán</cmp><cmp>PK</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>80</cmp><cmp>Qatar</cmp><cmp>QA</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>81</cmp><cmp>Singapur</cmp><cmp>SG</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>82</cmp><cmp>Siria</cmp><cmp>SY</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>83</cmp><cmp>Sri Lanka</cmp><cmp>LK</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>84</cmp><cmp>Tayikistán</cmp><cmp>TJ</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>85</cmp><cmp>Taiwan</cmp><cmp>TW</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>86</cmp><cmp>Palestina</cmp><cmp>PS</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>87</cmp><cmp>Tailandia</cmp><cmp>TH</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>88</cmp><cmp>Timor-Leste</cmp><cmp>TL</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>89</cmp><cmp>Turkmenistán</cmp><cmp>TM</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>90</cmp><cmp>Uzbekistán</cmp><cmp>UZ</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>91</cmp><cmp>Viet Nam</cmp><cmp>VN</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>92</cmp><cmp>Yemen</cmp><cmp>YE</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>93</cmp><cmp>Argelia</cmp><cmp>DZ</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>94</cmp><cmp>Angola</cmp><cmp>AO</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>95</cmp><cmp>Benin</cmp><cmp>BJ</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>96</cmp><cmp>Botswana</cmp><cmp>BW</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>97</cmp><cmp>Burkina Faso</cmp><cmp>BF</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>98</cmp><cmp>Burundi</cmp><cmp>BI</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>99</cmp><cmp>Camerún</cmp><cmp>CM</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>100</cmp><cmp>Cabo Verde</cmp><cmp>CV</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>101</cmp><cmp>República Centroafricana</cmp><cmp>CF</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>102</cmp><cmp>Chad</cmp><cmp>TD</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>103</cmp><cmp>Comoras</cmp><cmp>KM</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>104</cmp><cmp>Congo</cmp><cmp>CG</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>105</cmp><cmp>Rep. Dem. Del Congo</cmp><cmp>CD</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>106</cmp><cmp>Côte D'Ivoire</cmp><cmp>CI</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>107</cmp><cmp>Egipto</cmp><cmp>EG</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>108</cmp><cmp>Eritrea</cmp><cmp>ER</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>109</cmp><cmp>Etiopía</cmp><cmp>ET</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>110</cmp><cmp>Gabón</cmp><cmp>GA</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>111</cmp><cmp>Gambia</cmp><cmp>GM</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>112</cmp><cmp>Ghana</cmp><cmp>GH</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>113</cmp><cmp>Djibouti</cmp><cmp>DJ</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>114</cmp><cmp>Guinea</cmp><cmp>GN</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>115</cmp><cmp>Guinea-Bissau</cmp><cmp>GW</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>116</cmp><cmp>Guinea Ecuatorial</cmp><cmp>GQ</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>117</cmp><cmp>Kenya</cmp><cmp>KE</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>118</cmp><cmp>Lesotho</cmp><cmp>LS</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>119</cmp><cmp>Liberia</cmp><cmp>LR</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>120</cmp><cmp>Libia</cmp><cmp>LY</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>121</cmp><cmp>Madagascar</cmp><cmp>MG</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>122</cmp><cmp>Malawi</cmp><cmp>MW</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>123</cmp><cmp>Malí</cmp><cmp>ML</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>124</cmp><cmp>Marruecos</cmp><cmp>MA</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>125</cmp><cmp>Mauritania</cmp><cmp>MR</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>126</cmp><cmp>Mauricio</cmp><cmp>MU</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>127</cmp><cmp>Mozambique</cmp><cmp>MZ</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>128</cmp><cmp>Namibia</cmp><cmp>NA</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>129</cmp><cmp>Níger</cmp><cmp>NE</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>130</cmp><cmp>Nigeria</cmp><cmp>NG</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>131</cmp><cmp>Rwanda</cmp><cmp>RW</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>132</cmp><cmp>Santo Tomé Y Príncipe</cmp><cmp>ST</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>133</cmp><cmp>Senegal</cmp><cmp>SN</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>134</cmp><cmp>Seychelles</cmp><cmp>SC</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>135</cmp><cmp>Sierra Leona</cmp><cmp>SL</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>136</cmp><cmp>Somalia</cmp><cmp>SO</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>137</cmp><cmp>Sudáfrica</cmp><cmp>ZA</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>138</cmp><cmp>Sudán</cmp><cmp>SD</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>139</cmp><cmp>Swazilandia</cmp><cmp>SZ</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>140</cmp><cmp>Tanzanía</cmp><cmp>TZ</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>141</cmp><cmp>Togo</cmp><cmp>TG</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>142</cmp><cmp>Túnez</cmp><cmp>TN</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>143</cmp><cmp>Uganda</cmp><cmp>UG</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>144</cmp><cmp>Zambia</cmp><cmp>ZM</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>145</cmp><cmp>Zimbabwe</cmp><cmp>ZW</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>146</cmp><cmp>Antigua Y Barbuda</cmp><cmp>AG</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>147</cmp><cmp>Argentina</cmp><cmp>AR</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>148</cmp><cmp>Bahamas</cmp><cmp>BS</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>149</cmp><cmp>Barbados</cmp><cmp>BB</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>150</cmp><cmp>Belice</cmp><cmp>BZ</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>151</cmp><cmp>Bolivia</cmp><cmp>BO</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>152</cmp><cmp>Brasil</cmp><cmp>BR</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>153</cmp><cmp>Canadá</cmp><cmp>CA</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>154</cmp><cmp>Chile</cmp><cmp>CL</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>155</cmp><cmp>Colombia</cmp><cmp>CO</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>156</cmp><cmp>Costa Rica</cmp><cmp>CR</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>157</cmp><cmp>Cuba</cmp><cmp>CU</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>158</cmp><cmp>Dominica</cmp><cmp>DM</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>159</cmp><cmp>República Dominicana</cmp><cmp>DO</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>160</cmp><cmp>Ecuador</cmp><cmp>EC</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>161</cmp><cmp>El Salvador</cmp><cmp>SV</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>162</cmp><cmp>Jamaica</cmp><cmp>JM</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>163</cmp><cmp>Granada</cmp><cmp>GD</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>164</cmp><cmp>Guatemala</cmp><cmp>GT</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>165</cmp><cmp>Guyana</cmp><cmp>GY</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>166</cmp><cmp>Haití</cmp><cmp>HT</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>167</cmp><cmp>Honduras</cmp><cmp>HN</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>168</cmp><cmp>México</cmp><cmp>MX</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>169</cmp><cmp>Nicaragua</cmp><cmp>NI</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>170</cmp><cmp>Panamá</cmp><cmp>PA</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>171</cmp><cmp>Paraguay</cmp><cmp>PY</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>172</cmp><cmp>Perú</cmp><cmp>PE</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>173</cmp><cmp>Saint Kitts Y Nevis</cmp><cmp>KN</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>174</cmp><cmp>Santa Lucía</cmp><cmp>LC</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>175</cmp><cmp>San Vicente Y Granadinas</cmp><cmp>VC</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>176</cmp><cmp>Estados Unidos De América</cmp><cmp>US</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>177</cmp><cmp>Suriname</cmp><cmp>SR</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>178</cmp><cmp>Trinidad Y Tabago</cmp><cmp>TT</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>179</cmp><cmp>Uruguay</cmp><cmp>UY</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>180</cmp><cmp>Venezuela</cmp><cmp>VE</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>181</cmp><cmp>Australia</cmp><cmp>AU</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>182</cmp><cmp>Fiji</cmp><cmp>FJ</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>183</cmp><cmp>Kiribati</cmp><cmp>KI</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>184</cmp><cmp>Islas Marshall</cmp><cmp>MH</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>185</cmp><cmp>Micronesia</cmp><cmp>FM</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>186</cmp><cmp>Nauru</cmp><cmp>NR</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>187</cmp><cmp>Nueva Zelandia</cmp><cmp>NZ</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>188</cmp><cmp>Palau</cmp><cmp>PW</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>189</cmp><cmp>Papua Nueva Guinea</cmp><cmp>PG</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>190</cmp><cmp>Islas Salomón</cmp><cmp>SB</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>191</cmp><cmp>Samoa</cmp><cmp>WS</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>192</cmp><cmp>Tonga</cmp><cmp>TO</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>193</cmp><cmp>Tuvalu</cmp><cmp>TV</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>194</cmp><cmp>Vanuatu</cmp><cmp>VU</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>195</cmp><cmp>Italia</cmp><cmp>IT</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>196</cmp><cmp>Kosovo</cmp><cmp>XK</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>197</cmp><cmp>Sudán Del Sur</cmp><cmp>SS</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
</righetabella>
</tabella>
<tabella>
<nometabella>regioni</nometabella>
<colonnetabella>
<nomecolonna>idregioni</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>nome_regione</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>codice_regione</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>codice2_regione</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>codice3_regione</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>datainserimento</nomecolonna>
<tipocolonna>12</tipocolonna>
<nomecolonna>hostinserimento</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>utente_inserimento</nomecolonna>
<tipocolonna>3</tipocolonna>
</colonnetabella>
<righetabella>
</righetabella>
</tabella>
<tabella>
<nometabella>citta</nometabella>
<colonnetabella>
<nomecolonna>idcitta</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>nome_citta</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>codice_citta</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>codice2_citta</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>codice3_citta</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>datainserimento</nomecolonna>
<tipocolonna>12</tipocolonna>
<nomecolonna>hostinserimento</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>utente_inserimento</nomecolonna>
<tipocolonna>3</tipocolonna>
</colonnetabella>
<righetabella>
</righetabella>
</tabella>
<tabella>
<nometabella>documentiid</nometabella>
<colonnetabella>
<nomecolonna>iddocumentiid</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>nome_documentoid</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>codice_documentoid</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>codice2_documentoid</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>codice3_documentoid</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>datainserimento</nomecolonna>
<tipocolonna>12</tipocolonna>
<nomecolonna>hostinserimento</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>utente_inserimento</nomecolonna>
<tipocolonna>3</tipocolonna>
</colonnetabella>
<righetabella>
</righetabella>
</tabella>
<tabella>
<nometabella>parentele</nometabella>
<colonnetabella>
<nomecolonna>idparentele</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>nome_parentela</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>codice_parentela</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>codice2_parentela</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>codice3_parentela</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>datainserimento</nomecolonna>
<tipocolonna>12</tipocolonna>
<nomecolonna>hostinserimento</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>utente_inserimento</nomecolonna>
<tipocolonna>3</tipocolonna>
</colonnetabella>
<righetabella>
</righetabella>
</tabella>
<tabella>
<nometabella>relutenti</nometabella>
<colonnetabella>
<nomecolonna>idutente</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>idnazione</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>idregione</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>idcitta</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>iddocumentoid</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>idparentela</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>idsup</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>predef</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>datainserimento</nomecolonna>
<tipocolonna>12</tipocolonna>
<nomecolonna>hostinserimento</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>utente_inserimento</nomecolonna>
<tipocolonna>3</tipocolonna>
</colonnetabella>
<righetabella>
<riga><cmp>1</cmp><cmp>1</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>2</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>3</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>5</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>6</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>7</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>8</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>9</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>10</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>11</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>12</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>13</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>14</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>15</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>16</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>17</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>18</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>19</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>20</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>21</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>22</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>23</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>24</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>25</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>26</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>27</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>28</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>29</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>30</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>31</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>32</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>33</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>34</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>35</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>36</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>37</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>38</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>39</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>40</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>41</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>42</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>43</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>44</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>45</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>46</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>47</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>48</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>49</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>50</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>51</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>52</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>53</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>54</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>55</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>56</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>57</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>58</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>59</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>60</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>61</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>62</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>63</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>64</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>65</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>66</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>67</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>68</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>69</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>70</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>71</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>72</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>73</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>74</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>75</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>76</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>77</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>78</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>79</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>80</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>81</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>82</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>83</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>84</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>85</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>86</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>87</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>88</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>89</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>90</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>91</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>92</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>93</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>94</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>95</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>96</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>97</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>98</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>99</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>100</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>101</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>102</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>103</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>104</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>105</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>106</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>107</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>108</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>109</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>110</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>111</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>112</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>113</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>114</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>115</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>116</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>117</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>118</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>119</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>120</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>121</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>122</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>123</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>124</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>125</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>126</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>127</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>128</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>129</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>130</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>131</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>132</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>133</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>134</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>135</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>136</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>137</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>138</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>139</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>140</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>141</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>142</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>143</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>144</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>145</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>146</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>147</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>148</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>149</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>150</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>151</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>152</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>153</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>154</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>155</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>156</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>157</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>158</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>159</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>160</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>161</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>162</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>163</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>164</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>165</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>166</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>167</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>168</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>169</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>170</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>171</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>172</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>173</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>174</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>175</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>176</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>177</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>178</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>179</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>180</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>181</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>182</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>183</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>184</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>185</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>186</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>187</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>188</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>189</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>190</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>191</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>192</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>193</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>194</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>195</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>196</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>1</cmp><cmp>197</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
</righetabella>
</tabella>
<tabella>
<nometabella>relgruppi</nometabella>
<colonnetabella>
<nomecolonna>idutente</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>idgruppo</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>datainserimento</nomecolonna>
<tipocolonna>12</tipocolonna>
<nomecolonna>hostinserimento</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>utente_inserimento</nomecolonna>
<tipocolonna>3</tipocolonna>
</colonnetabella>
<righetabella>
</righetabella>
</tabella>
<tabella>
<nometabella>beniinventario</nometabella>
<colonnetabella>
<nomecolonna>idbeniinventario</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>nome_bene</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>codice_bene</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>descrizione_bene</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>datainserimento</nomecolonna>
<tipocolonna>12</tipocolonna>
<nomecolonna>hostinserimento</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>utente_inserimento</nomecolonna>
<tipocolonna>3</tipocolonna>
</colonnetabella>
<righetabella>
</righetabella>
</tabella>
<tabella>
<nometabella>magazzini</nometabella>
<colonnetabella>
<nomecolonna>idmagazzini</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>nome_magazzino</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>codice_magazzino</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>descrizione_magazzino</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>numpiano</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>numcasa</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>datainserimento</nomecolonna>
<tipocolonna>12</tipocolonna>
<nomecolonna>hostinserimento</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>utente_inserimento</nomecolonna>
<tipocolonna>3</tipocolonna>
</colonnetabella>
<righetabella>
</righetabella>
</tabella>
<tabella>
<nometabella>relinventario</nometabella>
<colonnetabella>
<nomecolonna>idbeneinventario</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>idappartamento</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>idmagazzino</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>quantita</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>quantita_min_predef</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>richiesto_checkin</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>datainserimento</nomecolonna>
<tipocolonna>12</tipocolonna>
<nomecolonna>hostinserimento</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>utente_inserimento</nomecolonna>
<tipocolonna>3</tipocolonna>
</colonnetabella>
<righetabella>
</righetabella>
</tabella>
<tabella>
<nometabella>casse</nometabella>
<colonnetabella>
<nomecolonna>idcasse</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>nome_cassa</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>stato</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>codice_cassa</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>descrizione_cassa</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>datainserimento</nomecolonna>
<tipocolonna>12</tipocolonna>
<nomecolonna>hostinserimento</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>utente_inserimento</nomecolonna>
<tipocolonna>3</tipocolonna>
</colonnetabella>
<righetabella>
<riga><cmp>1</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp>2025-10-26 08:35:20</cmp><cmp>localhost</cmp><cmp>1</cmp></riga>
</righetabella>
</tabella>
<tabella>
<nometabella>contratti</nometabella>
<colonnetabella>
<nomecolonna>numero</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>tipo</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>testo</nomecolonna>
<tipocolonna>252</tipocolonna>
</colonnetabella>
<righetabella>
<riga><cmp>2322</cmp><cmp>vett9</cmp><cmp>situacion_limpieza;unidad_limpieza</cmp></riga>
<riga><cmp>2323</cmp><cmp>vett9</cmp><cmp>personas_limpieza;unidad_limpieza</cmp></riga>
<riga><cmp>2324</cmp><cmp>vett9</cmp><cmp>personas_salida_limpieza;unidad_limpieza</cmp></riga>
<riga><cmp>2325</cmp><cmp>vett9</cmp><cmp>numero_personas_limpieza;unidad_limpieza</cmp></riga>
<riga><cmp>2326</cmp><cmp>vett9</cmp><cmp>numero_personas_salida_limpieza;unidad_limpieza</cmp></riga>
<riga><cmp>2327</cmp><cmp>vett9</cmp><cmp>numero_personas_llegada_limpieza;unidad_limpieza</cmp></riga>
<riga><cmp>2328</cmp><cmp>vett9</cmp><cmp>horario_llegada_limpieza;unidad_limpieza</cmp></riga>
<riga><cmp>2329</cmp><cmp>vett9</cmp><cmp>costes_agnadidos_limpieza;num_ca_limpieza</cmp></riga>
<riga><cmp>2330</cmp><cmp>vett9</cmp><cmp>pos_ca_limpieza;nome_costo_agg</cmp></riga>
<riga><cmp>2332</cmp><cmp>vett9</cmp><cmp>linea_unidad_ca_limpieza;unidad_limpieza</cmp></riga>
<riga><cmp>2333</cmp><cmp>vett9</cmp><cmp>array_fechas_limpieza;dia_limpieza</cmp></riga>
<riga><cmp>2334</cmp><cmp>vett9</cmp><cmp>total_ca_limpieza;num_ca_limpieza</cmp></riga>
<riga><cmp>2340</cmp><cmp>vett8</cmp><cmp>arr_enlaces_eb;numero_cliente</cmp></riga>
<riga><cmp>2341</cmp><cmp>vett8</cmp><cmp>arr_enlaces_en_eb;numero_cliente</cmp></riga>
<riga><cmp>2336</cmp><cmp>vett7</cmp><cmp>arr_enlaces_ec;numero_cliente</cmp></riga>
<riga><cmp>2337</cmp><cmp>vett7</cmp><cmp>arr_enlaces_en_ec;numero_cliente</cmp></riga>
<riga><cmp>2338</cmp><cmp>vett7</cmp><cmp>arr_datos_acceso_ec;numero_cliente</cmp></riga>
<riga><cmp>2339</cmp><cmp>vett7</cmp><cmp>arr_datos_acceso_en_ec;numero_cliente</cmp></riga>
<riga><cmp>1</cmp><cmp>vett2</cmp><cmp>iva_porc_vect_fact;num_iva_fact</cmp></riga>
<riga><cmp>2</cmp><cmp>vett2</cmp><cmp>iva_porc_exist_fact;var_tmp_fact</cmp></riga>
<riga><cmp>2335</cmp><cmp>vett10</cmp><cmp>cliente_visto_csv;numero_cliente</cmp></riga>
<riga><cmp>84</cmp><cmp>var9</cmp><cmp>fecha_informe_limpieza</cmp></riga>
<riga><cmp>85</cmp><cmp>var9</cmp><cmp>llegada_limpieza</cmp></riga>
<riga><cmp>86</cmp><cmp>var9</cmp><cmp>salida_limpieza</cmp></riga>
<riga><cmp>87</cmp><cmp>var9</cmp><cmp>unidad_limpieza</cmp></riga>
<riga><cmp>88</cmp><cmp>var9</cmp><cmp>clase_linea_limpieza</cmp></riga>
<riga><cmp>89</cmp><cmp>var9</cmp><cmp>f_fecha_informe_limpieza</cmp></riga>
<riga><cmp>90</cmp><cmp>var9</cmp><cmp>tot_personas_limpieza</cmp></riga>
<riga><cmp>91</cmp><cmp>var9</cmp><cmp>tot_personas_llegada_limpieza</cmp></riga>
<riga><cmp>92</cmp><cmp>var9</cmp><cmp>tot_personas_salida_limpieza</cmp></riga>
<riga><cmp>93</cmp><cmp>var9</cmp><cmp>num_ca_limpieza</cmp></riga>
<riga><cmp>94</cmp><cmp>var9</cmp><cmp>numero_repeticion_limpieza</cmp></riga>
<riga><cmp>95</cmp><cmp>var9</cmp><cmp>var_tmp_limpieza</cmp></riga>
<riga><cmp>96</cmp><cmp>var9</cmp><cmp>cabezera_tabla_ca_limpieza</cmp></riga>
<riga><cmp>97</cmp><cmp>var9</cmp><cmp>linea_tabla_ca_limpieza</cmp></riga>
<riga><cmp>98</cmp><cmp>var9</cmp><cmp>dia_limpieza</cmp></riga>
<riga><cmp>99</cmp><cmp>var9</cmp><cmp>linea_cabezera_tabla_limpieza</cmp></riga>
<riga><cmp>100</cmp><cmp>var9</cmp><cmp>numero_repeticion_unidad_limpieza</cmp></riga>
<riga><cmp>101</cmp><cmp>var9</cmp><cmp>repeticion_linea_cabezera_limpieza</cmp></riga>
<riga><cmp>102</cmp><cmp>var9</cmp><cmp>numero_repeticion_cabezera_limpieza</cmp></riga>
<riga><cmp>104</cmp><cmp>var8</cmp><cmp>apellido_eb</cmp></riga>
<riga><cmp>105</cmp><cmp>var8</cmp><cmp>apel_no_esp_eb</cmp></riga>
<riga><cmp>20</cmp><cmp>var7</cmp><cmp>apellido_ec</cmp></riga>
<riga><cmp>21</cmp><cmp>var7</cmp><cmp>apel_no_esp_ec</cmp></riga>
<riga><cmp>19</cmp><cmp>var6</cmp><cmp>apellido_eml_disp</cmp></riga>
<riga><cmp>12</cmp><cmp>var4</cmp><cmp>linea_ciudad_recibo</cmp></riga>
<riga><cmp>13</cmp><cmp>var4</cmp><cmp>linea_nacion_recibo</cmp></riga>
<riga><cmp>14</cmp><cmp>var4</cmp><cmp>cod_fisc_estruc_recibo</cmp></riga>
<riga><cmp>15</cmp><cmp>var4</cmp><cmp>nombre_recibo</cmp></riga>
<riga><cmp>16</cmp><cmp>var4</cmp><cmp>apellido_recibo</cmp></riga>
<riga><cmp>17</cmp><cmp>var4</cmp><cmp>telefono_estruc_recibo</cmp></riga>
<riga><cmp>18</cmp><cmp>var4</cmp><cmp>numero_calle_recibo</cmp></riga>
<riga><cmp>57</cmp><cmp>var4</cmp><cmp>mostrar_metodo_recibo</cmp></riga>
<riga><cmp>103</cmp><cmp>var4</cmp><cmp>logo_recibo</cmp></riga>
<riga><cmp>22</cmp><cmp>var2</cmp><cmp>linea_ciudad_fact</cmp></riga>
<riga><cmp>23</cmp><cmp>var2</cmp><cmp>linea_nacion_fact</cmp></riga>
<riga><cmp>24</cmp><cmp>var2</cmp><cmp>cod_fisc_estruc_fact</cmp></riga>
<riga><cmp>25</cmp><cmp>var2</cmp><cmp>nombre_fact</cmp></riga>
<riga><cmp>26</cmp><cmp>var2</cmp><cmp>apellido_fact</cmp></riga>
<riga><cmp>27</cmp><cmp>var2</cmp><cmp>telefono_estruc_fact</cmp></riga>
<riga><cmp>28</cmp><cmp>var2</cmp><cmp>var_tmp_fact</cmp></riga>
<riga><cmp>29</cmp><cmp>var2</cmp><cmp>tarifa_no_iva_fact</cmp></riga>
<riga><cmp>30</cmp><cmp>var2</cmp><cmp>ultima_reserva_fact</cmp></riga>
<riga><cmp>31</cmp><cmp>var2</cmp><cmp>nombre_coste_agn_fact</cmp></riga>
<riga><cmp>32</cmp><cmp>var2</cmp><cmp>tot_no_iva_fact</cmp></riga>
<riga><cmp>33</cmp><cmp>var2</cmp><cmp>coste_tot_fact</cmp></riga>
<riga><cmp>34</cmp><cmp>var2</cmp><cmp>coste_tot_fact_p</cmp></riga>
<riga><cmp>35</cmp><cmp>var2</cmp><cmp>iva_fact_p</cmp></riga>
<riga><cmp>36</cmp><cmp>var2</cmp><cmp>tot_no_iva_fact_p</cmp></riga>
<riga><cmp>37</cmp><cmp>var2</cmp><cmp>coste_agn_no_iva_fact_p</cmp></riga>
<riga><cmp>38</cmp><cmp>var2</cmp><cmp>descuento_no_iva_fact_p</cmp></riga>
<riga><cmp>39</cmp><cmp>var2</cmp><cmp>tarifa_no_iva_fact_p</cmp></riga>
<riga><cmp>40</cmp><cmp>var2</cmp><cmp>numero_calle_fact</cmp></riga>
<riga><cmp>41</cmp><cmp>var2</cmp><cmp>codigo_fiscal_fact</cmp></riga>
<riga><cmp>42</cmp><cmp>var2</cmp><cmp>num_identificacion_fiscal_fact</cmp></riga>
<riga><cmp>43</cmp><cmp>var2</cmp><cmp>calle_fact</cmp></riga>
<riga><cmp>44</cmp><cmp>var2</cmp><cmp>num_iva_fact</cmp></riga>
<riga><cmp>45</cmp><cmp>var2</cmp><cmp>ens_tarifa_fact</cmp></riga>
<riga><cmp>46</cmp><cmp>var2</cmp><cmp>ens_descuento_fact</cmp></riga>
<riga><cmp>47</cmp><cmp>var2</cmp><cmp>ens_coste_agn_fact</cmp></riga>
<riga><cmp>48</cmp><cmp>var2</cmp><cmp>num_ripeticion_fact</cmp></riga>
<riga><cmp>49</cmp><cmp>var2</cmp><cmp>tot_parc_no_iva_fact</cmp></riga>
<riga><cmp>50</cmp><cmp>var2</cmp><cmp>tot_parc_iva_fact</cmp></riga>
<riga><cmp>51</cmp><cmp>var2</cmp><cmp>tot_parc_no_iva_fact_p</cmp></riga>
<riga><cmp>52</cmp><cmp>var2</cmp><cmp>tot_parc_iva_fact_p</cmp></riga>
<riga><cmp>53</cmp><cmp>var2</cmp><cmp>max_num_iva_fact</cmp></riga>
<riga><cmp>54</cmp><cmp>var2</cmp><cmp>frase_personas_fact</cmp></riga>
<riga><cmp>55</cmp><cmp>var2</cmp><cmp>une_descuento_a_tarifa</cmp></riga>
<riga><cmp>56</cmp><cmp>var2</cmp><cmp>logo_fact</cmp></riga>
<riga><cmp>58</cmp><cmp>var2</cmp><cmp>nombre_coste_tasa_fact</cmp></riga>
<riga><cmp>59</cmp><cmp>var2</cmp><cmp>ens_coste_tasa_fact</cmp></riga>
<riga><cmp>60</cmp><cmp>var2</cmp><cmp>iva_fact</cmp></riga>
<riga><cmp>61</cmp><cmp>var2</cmp><cmp>tot_costes_tasa_fact</cmp></riga>
<riga><cmp>62</cmp><cmp>var2</cmp><cmp>ens_coste_como_tasas_fact</cmp></riga>
<riga><cmp>63</cmp><cmp>var2</cmp><cmp>ens_subtotal_fact</cmp></riga>
<riga><cmp>119</cmp><cmp>var2</cmp><cmp>redondea_sobre_totales_fact</cmp></riga>
<riga><cmp>120</cmp><cmp>var2</cmp><cmp>coste_tot_parc_fact</cmp></riga>
<riga><cmp>121</cmp><cmp>var2</cmp><cmp>porc_tasas_tar_fact</cmp></riga>
<riga><cmp>106</cmp><cmp>var11</cmp><cmp>apellido_rcsv</cmp></riga>
<riga><cmp>107</cmp><cmp>var11</cmp><cmp>nombre_rcsv</cmp></riga>
<riga><cmp>108</cmp><cmp>var11</cmp><cmp>unidad_rcsv</cmp></riga>
<riga><cmp>109</cmp><cmp>var11</cmp><cmp>nombre_tarifa_rcsv</cmp></riga>
<riga><cmp>110</cmp><cmp>var11</cmp><cmp>email_rcsv</cmp></riga>
<riga><cmp>111</cmp><cmp>var11</cmp><cmp>telefono_rcsv</cmp></riga>
<riga><cmp>112</cmp><cmp>var11</cmp><cmp>precio_tarifa_rcsv</cmp></riga>
<riga><cmp>113</cmp><cmp>var11</cmp><cmp>precio_total_rcsv</cmp></riga>
<riga><cmp>114</cmp><cmp>var11</cmp><cmp>pagado_rcsv</cmp></riga>
<riga><cmp>115</cmp><cmp>var11</cmp><cmp>total_personas_rcsv</cmp></riga>
<riga><cmp>116</cmp><cmp>var11</cmp><cmp>comentario_rcsv</cmp></riga>
<riga><cmp>117</cmp><cmp>var11</cmp><cmp>llegada_rcsv</cmp></riga>
<riga><cmp>118</cmp><cmp>var11</cmp><cmp>salida_rcsv</cmp></riga>
<riga><cmp>64</cmp><cmp>var10</cmp><cmp>apellido_csv</cmp></riga>
<riga><cmp>65</cmp><cmp>var10</cmp><cmp>nombre_csv</cmp></riga>
<riga><cmp>66</cmp><cmp>var10</cmp><cmp>apodo_csv</cmp></riga>
<riga><cmp>67</cmp><cmp>var10</cmp><cmp>titulo_csv</cmp></riga>
<riga><cmp>68</cmp><cmp>var10</cmp><cmp>email_csv</cmp></riga>
<riga><cmp>69</cmp><cmp>var10</cmp><cmp>telefono_csv</cmp></riga>
<riga><cmp>70</cmp><cmp>var10</cmp><cmp>fax_csv</cmp></riga>
<riga><cmp>71</cmp><cmp>var10</cmp><cmp>nacion_csv</cmp></riga>
<riga><cmp>72</cmp><cmp>var10</cmp><cmp>region_csv</cmp></riga>
<riga><cmp>73</cmp><cmp>var10</cmp><cmp>ciudad_csv</cmp></riga>
<riga><cmp>74</cmp><cmp>var10</cmp><cmp>direccion_csv</cmp></riga>
<riga><cmp>75</cmp><cmp>var10</cmp><cmp>codigo_postal_csv</cmp></riga>
<riga><cmp>76</cmp><cmp>var10</cmp><cmp>nacionalidad_csv</cmp></riga>
<riga><cmp>77</cmp><cmp>var10</cmp><cmp>fecha_nacimiento_csv</cmp></riga>
<riga><cmp>78</cmp><cmp>var10</cmp><cmp>certificado_indentificacion_fiscal_csv</cmp></riga>
<riga><cmp>79</cmp><cmp>var10</cmp><cmp>tmp_csv</cmp></riga>
<riga><cmp>80</cmp><cmp>var10</cmp><cmp>email2_csv</cmp></riga>
<riga><cmp>81</cmp><cmp>var10</cmp><cmp>email_certificado_csv</cmp></riga>
<riga><cmp>82</cmp><cmp>var10</cmp><cmp>telefono2_csv</cmp></riga>
<riga><cmp>83</cmp><cmp>var10</cmp><cmp>telefono3_csv</cmp></riga>
<riga><cmp>1</cmp><cmp>var</cmp><cmp>Mr</cmp></riga>
<riga><cmp>2</cmp><cmp>var</cmp><cmp>il</cmp></riga>
<riga><cmp>3</cmp><cmp>var</cmp><cmp>Il_</cmp></riga>
<riga><cmp>4</cmp><cmp>var</cmp><cmp>al</cmp></riga>
<riga><cmp>5</cmp><cmp>var</cmp><cmp>e</cmp></riga>
<riga><cmp>6</cmp><cmp>var</cmp><cmp>o</cmp></riga>
<riga><cmp>7</cmp><cmp>var</cmp><cmp>el</cmp></riga>
<riga><cmp>8</cmp><cmp>var</cmp><cmp>El_</cmp></riga>
<riga><cmp>9</cmp><cmp>var</cmp><cmp>al3</cmp></riga>
<riga><cmp>10</cmp><cmp>var</cmp><cmp>a</cmp></riga>
<riga><cmp>11</cmp><cmp>var</cmp><cmp>o3</cmp></riga>
<riga><cmp>6</cmp><cmp>opzeml</cmp><cmp>;;</cmp></riga>
<riga><cmp>7</cmp><cmp>opzeml</cmp><cmp>;SI;</cmp></riga>
<riga><cmp>8</cmp><cmp>opzeml</cmp><cmp>;SI;</cmp></riga>
<riga><cmp>6</cmp><cmp>oggetto</cmp><cmp>mln_es:Disponibilidad>mln_en:Availability</cmp></riga>
<riga><cmp>7</cmp><cmp>oggetto</cmp><cmp>mln_es:Confirmación reserva>mln_en:Reservation confirmation</cmp></riga>
<riga><cmp>8</cmp><cmp>oggetto</cmp><cmp>mln_es:Se acerca tu reserva>mln_en:Your reservation is approaching</cmp></riga>
<riga><cmp>3</cmp><cmp>nomefile</cmp><cmp>Factura</cmp></riga>
<riga><cmp>6</cmp><cmp>mln_es</cmp><cmp>Estimad[o] Señor[a] [apellido_eml_disp],
le confirmo la disponibilidad de un apartamento[c num_personas_tot!=""] para [num_personas_tot] personas[/c] para el período desde el [fecha_inicial] hasta el [fecha_final]. El precio para dicho período es de [coste_tot_p] [nombre_divisa] (incluyendo costes asociados).

En el caso de que desee reservar le ruego me envie su confirmación respondiendo a este correo electrónico.

Estaré a su disposición para cualquier otra información que necesite.

Saludos,
[nombre_contacto_estructura]

[nombre_estructura]
[sitio_web_estructura]


[texto_citado_email_pedido]
</cmp></riga>
<riga><cmp>7</cmp><cmp>mln_es</cmp><cmp>Estimad[o] Señor[a] [apellido_ec],
le confirmo que he reservado a su nombre un apartamento[c num_personas_tot!=""] para [num_personas_tot] personas[/c] para el período desde el [fecha_inicial] hasta el [fecha_final]. El precio para dicho período es de [coste_tot_p] [nombre_divisa] (incluyendo costes asociados). Para completar la reserva es necesario pagar por adelantado [fianza_p] [nombre_divisa], puede efectuar este pago siguiendo [c arr_enlaces_ec(numero_cliente)=""]este enlace[/c][c arr_enlaces_ec(numero_cliente)!=""]estos enlaces[/c]:

[arr_enlaces_ec(numero_cliente)][url_base_paginas_web]mdl_confirma_reserva.php?cn=[apel_no_esp_ec]&cp=[codigo_reserva]

Si [c arr_enlaces_ec(numero_cliente)=""]el enlace no funcionara[/c][c arr_enlaces_ec(numero_cliente)!=""]los enlaces no funcionaran[/c] correctamente puede intentar utilizar este otro:

[url_base_paginas_web]mdl_confirma_reserva.php

e insertar después:

[arr_datos_acceso_ec(numero_cliente)]Apellido: [apellido]
Código reserva: [codigo_reserva]

Estaré a su disposición para cualquier otra información que necesite.

Saludos,
[nombre_contacto_estructura]

[nombre_estructura]
[sitio_web_estructura]
</cmp></riga>
<riga><cmp>8</cmp><cmp>mln_es</cmp><cmp>Estimad[o] Señor[a] [apellido_eb],
[c archivo_adjunto1!=""]he adjuntado a este correo electrónico un archivo con nuestros contactos y un mapa para ayudarles a encontrarnos, avíseme si tiene problemas para leerlo.

[/c]Si desea ahorrar tiempo a su llegada, puede completar los datos necesarios para registrarse desde aquí:

[arr_enlaces_eb(numero_cliente)][url_base_paginas_web]mdl_confirma_reserva.php?cn=[apel_no_esp_eb]&cp=[codigo_reserva]&fe=1

[c horario_entrada_estimativo=""]¿Conoce su hora estimada de llegada? ¡Gracias! [/c]Estaré a su disposición para cualquier otra información que necesite.

Cordiales saludos,
[nombre_contacto_estructura]

[nombre_estructura]
[sitio_web_estructura]
</cmp></riga>
<riga><cmp>6</cmp><cmp>mln_en</cmp><cmp>Dear Mr[Mr] [apellido_eml_disp],
I confirm you the availability of an apartment[c people_num_tot!=""] for [people_num_tot] people[/c] in the period from [starting_date] to [ending_date]. The price for this period is [price_tot_p] [currency_name] (including cleaning and utilities).

If you are interested in reserving the apartment you can contact me by replaying to this email.

Please let me know if you have any question.

Best regards,
[structure_contact_name]

[structure_name]
[structure_website]


[enquiry_email_quoted_text]
</cmp></riga>
<riga><cmp>7</cmp><cmp>mln_en</cmp><cmp>Dear Mr[Mr] [apellido_ec],
I confirm you that I have reserved you an apartment[c people_num_tot!=""] for [people_num_tot] people[/c] in the period from [starting_date] to [ending_date]. The price for this period is [price_tot_p] [currency_name] (including cleaning and utilities). In order to complete the reservation you must send a down-payment of [deposit_p] [currency_name], you can pay it following [c arr_enlaces_ec(numero_cliente)=""]this link[/c][c arr_enlaces_ec(numero_cliente)!=""]these links[/c]:

[arr_enlaces_en_ec(numero_cliente)][url_base_paginas_web]confirm_reservation_tpl.php?cn=[apel_no_esp_ec]&cp=[codigo_reserva]

If the above [c arr_enlaces_ec(numero_cliente)=""]link does not[/c][c arr_enlaces_ec(numero_cliente)!=""]links do not[/c] work properly for you, try this other one:

[url_base_paginas_web]confirm_reservation_tpl.php

and then insert:

[arr_datos_acceso_en_ec(numero_cliente)]Surname: [apellido]
Reservation code: [codigo_reserva]

Please let me know if you have any other question.

Best regards,
[structure_contact_name]

[structure_name]
[structure_website]
</cmp></riga>
<riga><cmp>8</cmp><cmp>mln_en</cmp><cmp>Dear Mr[Mr] [apellido_eb],
[c archivo_adjunto1!=""]I’ve attached to this e-mail a file with our contacts and a map to help you find us, please let me know if you have problems reading it.

[/c]If you want to save time at your arrival you can fill in the data required for check-in from here:

[arr_enlaces_en_eb(numero_cliente)][base_url_for_webpages]confirm_reservation_tpl.php?cn=[apel_no_esp_eb]&cp=[reservation_code]&fe=1

[c estimated_checkin_time=""]Do you know your estimated time of arrival? Thanks! [/c]Please let me know if you have any other question.

Best regards,
[structure_contact_name]

[structure_name]
[structure_website]
</cmp></riga>
<riga><cmp>3</cmp><cmp>impor_vc</cmp><cmp>2</cmp></riga>
<riga><cmp>5</cmp><cmp>impor_vc</cmp><cmp>4</cmp></riga>
<riga><cmp>9</cmp><cmp>headhtm</cmp><cmp><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" >
<title>Informe limpieza</title>
<style type="text/css">
table.clrep { border-collapse: collapse; }
table.clrep td { border: 2px solid black; padding: 2px; text-align: center; }
.headrow { background-color: #cccccc; }
tr.bgclr { background-color: #eeeeee; }
</style>
</head>
<body style="background-color: #ffffff;">
</cmp></riga>
<riga><cmp>9</cmp><cmp>foothtm</cmp><cmp></body>
</html>
</cmp></riga>
<riga><cmp>2</cmp><cmp>dir</cmp><cmp>~</cmp></riga>
<riga><cmp>3</cmp><cmp>dir</cmp><cmp>~</cmp></riga>
<riga><cmp>10</cmp><cmp>datdownl</cmp><cmp>csv></cmp></riga>
<riga><cmp>11</cmp><cmp>datdownl</cmp><cmp>csv></cmp></riga>
<riga><cmp>10</cmp><cmp>contrtxt</cmp><cmp>Apellido,Nombre,Apodo,Título,Sexo,Email,2do Email, Email Certificado,Teléfono,2do Teléfono,3er Teléfono,Fax,Idioma,Nación de Residencia,Región de Residencia,Ciudad de Residencia,Dirección,Código Postal,Nacionalidad,Fecha de Nacimiento,CIF
[r][apellido_csv],[nombre_csv],[apodo_csv],[titulo_csv],[sexo],[email_csv],[email2_csv],[email_certificado_csv],[telefono_csv],[telefono2_csv],[telefono3_csv],[fax_csv],[codice_lingua],[nacion_csv],[region_csv],[ciudad_csv],[direccion_csv],[codigo_postal_csv],[nacionalidad_csv],[fecha_nacimiento_csv],[certificado_indentificacion_fiscal_csv]
[/r]</cmp></riga>
<riga><cmp>11</cmp><cmp>contrtxt</cmp><cmp>Llegada,Salida,Apellido,Nombre,Email,Telefono,Total Personas,Unidad Ocupada,Nombre Tarifa,Precio Tarifa,Precio Total,Pagado,Comentario
[r][llegada_rcsv],[salida_rcsv],[apellido_rcsv],[nombre_rcsv],[email_rcsv],[telefono_rcsv],[total_personas_rcsv],[unidad_rcsv],[nombre_tarifa_rcsv],[precio_tarifa_rcsv],[precio_total_rcsv],[pagado_rcsv],[comentario_rcsv]
[/r]</cmp></riga>
<riga><cmp>3</cmp><cmp>contrrtf</cmp><cmp>{\rtf1\ansi\deff1\adeflang1025[r][r3][/r3] [/r]
{\fonttbl{\f0\froman\fprq2\fcharset0 Times New Roman;}{\f1\froman\fprq2\fcharset0 Times New Roman;}{\f2\fswiss\fprq2\fcharset0 Arial;}{\f3\fswiss\fprq2\fcharset0 Arial;}{\f4\fswiss\fprq2\fcharset0 Bitstream Vera Sans;}{\f5\fswiss\fprq2\fcharset0 Tahoma;}{\f6\froman\fprq2\fcharset0 Garamond;}{\f7\froman\fprq2\fcharset0 Times New Roman;}{\f8\fnil\fprq2\fcharset0 Bitstream Vera Sans;}}
{\colortbl;\red0\green0\blue0;\red230\green230\blue230;\red255\green255\blue255;\red204\green204\blue204;\red128\green128\blue128;}
{\stylesheet{\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\snext1 Normal;}
{\s2\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af8\afs28\lang255\ltrch\dbch\af8\langfe255\hich\f2\fs28\lang1040\loch\f2\fs28\lang1040\sbasedon1\snext3 Heading;}
{\s3\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af3\langfe255\hich\f1\fs24\lang1033\loch\f1\fs24\lang1033\sbasedon1\snext3 Body Text;}
{\s4{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1033\loch\f1\fs24\lang1033\sbasedon3\snext4 List;}
{\s5\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext5 caption;}
{\s6{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext6 Index;}
{\s7\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 Heading;}
{\s8\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext8 caption;}
{\s9{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext9 Index;}
{\s10\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 WW-Heading;}
{\s11\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext11 WW-caption;}
{\s12{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext12 WW-Index;}
{\s13\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 WW-Heading1;}
{\s14\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext14 WW-caption1;}
{\s15{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext15 WW-Index1;}
{\s16\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 WW-Heading11;}
{\s17\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext17 WW-caption11;}
{\s18{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext18 WW-Index11;}
{\s19\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 WW-Heading111;}
{\s20\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext20 WW-caption111;}
{\s21{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext21 WW-Index111;}
{\s22\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 WW-Heading1111;}
{\s23\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext23 WW-caption1111;}
{\s24{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext24 WW-Index1111;}
{\s25\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 WW-Heading11111;}
{\s26\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext26 WW-caption11111;}
{\s27{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext27 WW-Index11111;}
{\s28\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 WW-Heading111111;}
{\s29\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext29 WW-caption111111;}
{\s30{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext30 WW-Index111111;}
{\s31\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 WW-Heading1111111;}
{\s32\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext32 WW-caption1111111;}
{\s33{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext33 WW-Index1111111;}
{\s34\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af4\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f4\fs28\lang1040\loch\f4\fs28\lang1040\sbasedon1\snext3 WW-Heading11111111;}
{\s35\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext35 WW-caption11111111;}
{\s36{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af3\langfe255\hich\f1\fs24\lang1033\loch\f1\fs24\lang1033\sbasedon1\snext36 WW-Index11111111;}
{\s37\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs20\lang255\ai\ltrch\dbch\af3\langfe255\hich\f1\fs20\lang1033\i\loch\f1\fs20\lang1033\i\sbasedon1\snext37 Dicitura;}
{\s38{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af5\afs16\lang255\ltrch\dbch\af3\langfe255\hich\f5\fs16\lang1033\loch\f5\fs16\lang1033\sbasedon1\snext38 WW-Testo fumetto;}
{\s39{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1033\loch\f1\fs24\lang1033\sbasedon3\snext39 Frame contents;}
{\s40{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1033\loch\f1\fs24\lang1033\sbasedon3\snext40 Table Contents;}
{\s41\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ab\ltrch\dbch\langfe255\hich\f1\fs24\lang1033\i\b\loch\f1\fs24\lang1033\i\b\sbasedon40\snext41 Table Heading;}
{\s42{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext42 WW-Table Contents;}
{\s43\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon42\snext43 WW-Table Heading;}
{\s44{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext44 WW-Table Contents1;}
{\s45\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon44\snext45 WW-Table Heading1;}
{\s46{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext46 WW-Table Contents12;}
{\s47\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon46\snext47 WW-Table Heading12;}
{\s48{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext48 WW-Table Contents123;}
{\s49\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon48\snext49 WW-Table Heading123;}
{\s50{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext50 WW-Table Contents1234;}
{\s51\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon50\snext51 WW-Table Heading1234;}
{\s52{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext52 WW-Table Contents12345;}
{\s53\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon52\snext53 WW-Table Heading12345;}
{\s54{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext54 WW-Table Contents123456;}
{\s55\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon54\snext55 WW-Table Heading123456;}
{\s56{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext56 WW-Table Contents1234567;}
{\s57\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon56\snext57 WW-Table Heading1234567;}
{\s58{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext58 WW-Table Contents12345678;}
{\s59\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon58\snext59 WW-Table Heading12345678;}
{\s60{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext60 Table Contents;}
{\s61\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon60\snext61 Table Heading;}
{\*\cs63\cf0\rtlch\af1\afs24\lang255\ltrch\dbch\af3\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 WW-Car. predefinito paragrafo;}
}
{\info{\creatim\yr2007\mo9\dy28\hr15\min45}{\revtim\yr1601\mo1\dy1\hr0\min0}{\printim\yr1601\mo1\dy1\hr0\min0}{\comment StarWriter}{\vern3000}}\deftab708
{\*\pgdsctbl
{\pgdsc0\pgdscuse195\pgwsxn11905\pghsxn16837\marglsxn1134\margrsxn1134\margtsxn885\margbsxn1012\pgdscnxt0 Standard;}}
{\*\pgdscno0}\paperh16837\paperw11905\margl1134\margr1134\margt885\margb1012\sectd\sbknone\pgwsxn11905\pghsxn16837\marglsxn1134\margrsxn1134\margtsxn885\margbsxn1012\ftnbj\ftnstart1\ftnrstcont\ftnnar\aenddoc\aftnrstcont\aftnstart1\aftnnrlc
\pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af6\afs28\lang255\ab\ltrch\dbch\af1\langfe255\hich\f6\fs28\lang1040\b\loch\f6\fs28\lang1040\b {\rtlch \ltrch\loch\f6\fs28\lang1040\i0\b [tipo_estructura] [nombre_estructura]}
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af6\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f6\fs24\lang1040\loch\f6\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 [razon_social_estructura]}
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f6\fs24\lang1040\loch\f6\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 [direccion_estructura] - [ciudad_estructura]}
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 [codigo_postal_estructura] [nacion_estructura]}
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 C.I.F. [certificado_identificacion_fiscal_estructura] [cod_fisc_estruc_fact]}
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af6\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f6\fs24\lang1040\loch\f6\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 [telefono_estruc_fact]}
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\li5370\ri0\lin5370\rin0\fi0\ql\rtlch\af6\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f6\fs24\lang1040\loch\f6\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 Cliente [nombre_fact] [apellido_fact] }
[c calle_fact!=""]\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 \tab \tab \tab \tab \tab \tab \tab \tab [calle_fact][numero_calle_fact]}
[/c][c linea_ciudad_fact!=""]\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 \tab \tab \tab \tab \tab \tab \tab \tab [linea_ciudad_fact]}
[/c][c linea_nacion_fact!=""]\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 \tab \tab \tab \tab \tab \tab \tab \tab [linea_nacion_fact]}
[/c][c codigo_fiscal_fact!=""]\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 \tab \tab \tab \tab \tab \tab \tab \tab C.I.F. [codigo_fiscal_fact]}
[/c][c num_identificacion_fiscal_fact!=""]\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 \tab \tab \tab \tab \tab \tab \tab \tab D.N.I. / N.I.F. [num_identificacion_fiscal_fact]}
[/c]\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\brdrb\brdrs\brdrw20\brdrcf1\brsp20{\*\brdrb\brdlncol1\brdlnin0\brdlnout20\brdlndist0}\brsp20\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\par \pard\plain \ltrpar\s1\tx3540{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 \tab }
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af6\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f6\fs24\lang1040\loch\f6\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 Factura n. [numero_progresivo_documento] del [hoy]}
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\par \trowd\trql\trleft276\trrh-119\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrb\brdrs\brdrw1\brdrcf1\cellx7792\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalb\cellx9637
[r4 array="iva_porc_vect_fact"]
\pard\intbl\pard\plain \intbl\ltrpar\s1\cf0\cbpat3\ql\rtlch\afs12\lang255\ltrch\dbch\langfe255\hich\fs12\lang1040\loch\fs12\lang1040 
\cell\pard\plain \intbl\ltrpar\s1\cf0\ql\rtlch\afs24\lang255\ltrch\dbch\langfe255\hich\fs24\lang1040\loch\fs24\lang1040 
[r]
[c ens_tarifa_fact="1"]\cell\row\pard \trowd\trql\trleft276\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\cellx7792\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalb\cellx9637
\pard\intbl\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 Estancia desde el [fecha_inicial] al [fecha_final][frase_personas_fact]}
\cell\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\qr\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 [nombre_divisa] [tarifa_no_iva_fact_p]}
[/c][c ens_descuento_fact="1"]\cell\row\pard \trowd\trql\trleft276\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\cellx7792\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalb\cellx9637
\pard\intbl\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 Descuento}
\cell\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\qr\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 [nombre_divisa] [descuento_no_iva_fact_p]}
[/c]
[r3][c ens_coste_agn_fact="1"]\cell\row\pard \trowd\trql\trleft276\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\cellx7792\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalb\cellx9637
\pard\intbl\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 Extra: \'93[nombre_coste_agna]\'94}
\cell\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\qr\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 [nombre_divisa] [coste_agn_no_iva_fact_p]}
[/c][c ens_coste_como_tasas_fact="1"]\cell\row\pard \trowd\trql\trleft276\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\cellx7792\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalb\cellx9637
\pard\intbl\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 Tasa: \'93[nombre_coste_agna]\'94}
\cell\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\qr\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 [nombre_divisa] [tasas_coste_agna_p]}
[/c][/r3][/r]
[c ens_subtotal_fact="1"]\cell\row\pard \trowd\trql\trleft276\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\cellx7792\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalb\cellx9637
\pard\intbl\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 Imponible al [iva_porc_vect_fact(num_iva_fact)]%}
\cell\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\qr\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 [nombre_divisa] [tot_parc_no_iva_fact_p]}
\cell\row\pard \trowd\trql\trleft276\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\cellx7792\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalb\cellx9637
\pard\intbl\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 Iva al [iva_porc_vect_fact(num_iva_fact)]%}
\cell\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\qr\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 [nombre_divisa] [tot_parc_iva_fact_p]}
[/c]\cell\row\pard \trowd\trql\trleft276\trrh-119\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat3\cellx7792\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat3\clvertalb\cellx9637
[/r4]
\pard\intbl\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs12\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs12\lang1040\loch\f1\fs12\lang1040 
\cell\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\qr\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\cell\row\pard \trowd\trql\trleft276\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\cellx7792\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalb\cellx9637
\pard\intbl\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 Total Imponible}
\cell\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\qr\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 [nombre_divisa] [tot_no_iva_fact_p]}
\cell\row\pard \trowd\trql\trleft276\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\cellx7792\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalb\cellx9637
\pard\intbl\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 Total Impuestos[c num_iva_fact="1"] al [iva_porc_vect_fact(num_iva_fact)]%[/c]}
\cell\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\qr\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 [nombre_divisa] [iva_fact_p]}
[r][r3][c ens_coste_tasa_fact="1"]
\cell\row\pard \trowd\trql\trleft276\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\cellx7792\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalb\cellx9637
\pard\intbl\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 [nombre_coste_agna]}
\cell\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\qr\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 [nombre_divisa] [coste_agn_no_iva_fact_p]}
[/c][/r3][/r]
\cell\row\pard \trowd\trql\trleft276\trrh-119\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat3\cellx7792\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat3\clvertalb\cellx9637
\pard\intbl\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs12\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs12\lang1040\loch\f1\fs12\lang1040 
\cell\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\qr\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\cell\row\pard \trowd\trql\trleft276\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clcbpat4\cellx7792\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clcbpat4\clvertalb\cellx9637
\pard\intbl\pard\plain \intbl\ltrpar\s1\cf0\ql\rtlch\afs24\lang255\ltrch\dbch\langfe255\hich\fs24\lang1040\loch\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 Total Factura}
\cell\pard\plain \intbl\ltrpar\s1\cf0\qr\rtlch\afs24\lang255\ab\ltrch\dbch\langfe255\hich\fs24\lang1040\b\loch\fs24\lang1040\b {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b [nombre_divisa] [coste_tot_fact_p]}
\cell\row\pard \pard\plain \ltrpar\s1\cf0\ql\rtlch\afs24\lang255\ltrch\dbch\langfe255\hich\fs24\lang1040\loch\fs24\lang1040 
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\brdrb\brdrs\brdrw20\brdrcf1\brsp20{\*\brdrb\brdlncol1\brdlnin0\brdlnout20\brdlndist0}\brsp20\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\par }</cmp></riga>
<riga><cmp>5</cmp><cmp>contrrtf</cmp><cmp>{\rtf1\ansi\deff1\adeflang1025
{\fonttbl{\f0\froman\fprq2\fcharset0 Times New Roman;}{\f1\froman\fprq2\fcharset0 Times New Roman;}{\f2\fswiss\fprq2\fcharset0 Arial;}{\f3\fswiss\fprq2\fcharset0 Arial;}{\f4\fswiss\fprq2\fcharset0 Bitstream Vera Sans;}{\f5\fswiss\fprq2\fcharset0 Tahoma;}{\f6\froman\fprq2\fcharset0 Garamond;}{\f7\froman\fprq2\fcharset0 Times New Roman;}{\f8\fnil\fprq2\fcharset0 Bitstream Vera Sans;}}
{\colortbl;\red0\green0\blue0;\red230\green230\blue230;\red255\green255\blue255;\red204\green204\blue204;\red128\green128\blue128;}
{\stylesheet{\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\snext1 Normal;}
{\s2\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af8\afs28\lang255\ltrch\dbch\af8\langfe255\hich\f2\fs28\lang1040\loch\f2\fs28\lang1040\sbasedon1\snext3 Heading;}
{\s3\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af3\langfe255\hich\f1\fs24\lang1033\loch\f1\fs24\lang1033\sbasedon1\snext3 Body Text;}
{\s4{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1033\loch\f1\fs24\lang1033\sbasedon3\snext4 List;}
{\s5\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext5 caption;}
{\s6{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext6 Index;}
{\s7\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 Heading;}
{\s8\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext8 caption;}
{\s9{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext9 Index;}
{\s10\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 WW-Heading;}
{\s11\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext11 WW-caption;}
{\s12{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext12 WW-Index;}
{\s13\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 WW-Heading1;}
{\s14\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext14 WW-caption1;}
{\s15{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext15 WW-Index1;}
{\s16\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 WW-Heading11;}
{\s17\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext17 WW-caption11;}
{\s18{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext18 WW-Index11;}
{\s19\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 WW-Heading111;}
{\s20\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext20 WW-caption111;}
{\s21{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext21 WW-Index111;}
{\s22\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 WW-Heading1111;}
{\s23\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext23 WW-caption1111;}
{\s24{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext24 WW-Index1111;}
{\s25\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 WW-Heading11111;}
{\s26\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext26 WW-caption11111;}
{\s27{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext27 WW-Index11111;}
{\s28\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 WW-Heading111111;}
{\s29\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext29 WW-caption111111;}
{\s30{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext30 WW-Index111111;}
{\s31\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 WW-Heading1111111;}
{\s32\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext32 WW-caption1111111;}
{\s33{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext33 WW-Index1111111;}
{\s34\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af4\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f4\fs28\lang1040\loch\f4\fs28\lang1040\sbasedon1\snext3 WW-Heading11111111;}
{\s35\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext35 WW-caption11111111;}
{\s36{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af3\langfe255\hich\f1\fs24\lang1033\loch\f1\fs24\lang1033\sbasedon1\snext36 WW-Index11111111;}
{\s37\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs20\lang255\ai\ltrch\dbch\af3\langfe255\hich\f1\fs20\lang1033\i\loch\f1\fs20\lang1033\i\sbasedon1\snext37 Dicitura;}
{\s38{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af5\afs16\lang255\ltrch\dbch\af3\langfe255\hich\f5\fs16\lang1033\loch\f5\fs16\lang1033\sbasedon1\snext38 WW-Testo fumetto;}
{\s39{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1033\loch\f1\fs24\lang1033\sbasedon3\snext39 Frame contents;}
{\s40{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1033\loch\f1\fs24\lang1033\sbasedon3\snext40 Table Contents;}
{\s41\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ab\ltrch\dbch\langfe255\hich\f1\fs24\lang1033\i\b\loch\f1\fs24\lang1033\i\b\sbasedon40\snext41 Table Heading;}
{\s42{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext42 WW-Table Contents;}
{\s43\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon42\snext43 WW-Table Heading;}
{\s44{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext44 WW-Table Contents1;}
{\s45\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon44\snext45 WW-Table Heading1;}
{\s46{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext46 WW-Table Contents12;}
{\s47\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon46\snext47 WW-Table Heading12;}
{\s48{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext48 WW-Table Contents123;}
{\s49\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon48\snext49 WW-Table Heading123;}
{\s50{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext50 WW-Table Contents1234;}
{\s51\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon50\snext51 WW-Table Heading1234;}
{\s52{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext52 WW-Table Contents12345;}
{\s53\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon52\snext53 WW-Table Heading12345;}
{\s54{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext54 WW-Table Contents123456;}
{\s55\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon54\snext55 WW-Table Heading123456;}
{\s56{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext56 WW-Table Contents1234567;}
{\s57\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon56\snext57 WW-Table Heading1234567;}
{\s58{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext58 WW-Table Contents12345678;}
{\s59\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon58\snext59 WW-Table Heading12345678;}
{\s60{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext60 Table Contents;}
{\s61\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon60\snext61 Table Heading;}
{\*\cs63\cf0\rtlch\af1\afs24\lang255\ltrch\dbch\af3\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 WW-Car. predefinito paragrafo;}
}
{\info{\creatim\yr2007\mo9\dy28\hr15\min45}{\revtim\yr1601\mo1\dy1\hr0\min0}{\printim\yr1601\mo1\dy1\hr0\min0}{\comment StarWriter}{\vern3000}}\deftab708
{\*\pgdsctbl
{\pgdsc0\pgdscuse195\pgwsxn11905\pghsxn16837\marglsxn1134\margrsxn1134\margtsxn885\margbsxn1012\pgdscnxt0 Standard;}}
{\*\pgdscno0}\paperh16837\paperw11905\margl1134\margr1134\margt885\margb1012\sectd\sbknone\pgwsxn11905\pghsxn16837\marglsxn1134\margrsxn1134\margtsxn885\margbsxn1012\ftnbj\ftnstart1\ftnrstcont\ftnnar\aenddoc\aftnrstcont\aftnstart1\aftnnrlc
[r][c numero_ripetizione_prenotazioni!="1"]\par \page [/c]\pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af6\afs28\lang255\ab\ltrch\dbch\af1\langfe255\hich\f6\fs28\lang1040\b\loch\f6\fs28\lang1040\b {\rtlch \ltrch\loch\f6\fs28\lang1040\i0\b [tipo_estructura] [nombre_estructura]}
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af6\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f6\fs24\lang1040\loch\f6\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 [razon_social_estructura]}
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f6\fs24\lang1040\loch\f6\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 [direccion_estructura] - [ciudad_estructura]}
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 [codigo_postal_estructura] [nacion_estructura]}
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 C.I.F. [certificado_identificacion_fiscal_estructura] [cod_fisc_estruc_recibo]}
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af6\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f6\fs24\lang1040\loch\f6\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 [telefono_estruc_recibo]}
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\li5370\ri0\lin5370\rin0\fi0\ql\rtlch\af6\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f6\fs24\lang1040\loch\f6\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 [c apellido_recibo!=""]Cliente  [nombre_recibo] [apellido_recibo][/c] }
[c via!=""]\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 \tab \tab \tab \tab \tab \tab \tab \tab [via][numero_calle_recibo]}
[/c][c linea_ciudad_recibo!=""]\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 \tab \tab \tab \tab \tab \tab \tab \tab [linea_ciudad_recibo]}
[/c][c linea_nacion_recibo!=""]\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 \tab \tab \tab \tab \tab \tab \tab \tab [linea_nacion_recibo]}
[/c][c certificado_identificacion_fiscal!=""]\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 \tab \tab \tab \tab \tab \tab \tab \tab C.I.F. [certificado_identificacion_fiscal]}
[/c][c num_identificacion_fiscal!=""]\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 \tab \tab \tab \tab \tab \tab \tab \tab N.I.F. / D.N.I. [num_identificacion_fiscal]}
[/c]\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\brdrb\brdrs\brdrw20\brdrcf1\brsp20{\*\brdrb\brdlncol1\brdlnin0\brdlnout20\brdlndist0}\brsp20\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\par \pard\plain \ltrpar\s1\tx3540{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 \tab }
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af6\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f6\fs24\lang1040\loch\f6\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 Recibo[c numero_progresivo_documento!=""] n. [numero_progresivo_documento][/c] del [hoy]}
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\par \trowd\trql\trleft276\trrh-119\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrb\brdrs\brdrw1\brdrcf1\cellx7792\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalb\cellx9637
\pard\intbl\pard\plain \intbl\ltrpar\s1\cf0\cbpat3\ql\rtlch\afs12\lang255\ltrch\dbch\langfe255\hich\fs12\lang1040\loch\fs12\lang1040 
\cell\pard\plain \intbl\ltrpar\s1\cf0\ql\rtlch\afs24\lang255\ltrch\dbch\langfe255\hich\fs24\lang1040\loch\fs24\lang1040 
\cell\row\pard \trowd\trql\trleft276\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\cellx7792\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalb\cellx9637
\pard\intbl\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 [c fecha_inicial!=""]Reserva desde [fecha_inicial] hasta [fecha_final][/c][c num_personas_tot!=""] para [num_personas_tot] personas[/c][r5][c fecha_inicial="" & ultimo_pago="1"][metodo_pago][/c][/r5]}
\cell\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\qr\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 [r5][c mostrar_metodo_recibo="1" & ultimo_pago="1"][nombre_divisa] [valor_pago_p][/c][/r5]}
\cell\row\pard \trowd\trql\trleft276\trrh-119\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat3\cellx7792\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat3\clvertalb\cellx9637
\pard\intbl\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs12\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs12\lang1040\loch\f1\fs12\lang1040 
\cell\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\qr\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\cell\row\pard \trowd\trql\trleft276\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clcbpat4\cellx7792\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clcbpat4\clvertalb\cellx9637
\pard\intbl\pard\plain \intbl\ltrpar\s1\cf0\ql\rtlch\afs24\lang255\ltrch\dbch\langfe255\hich\fs24\lang1040\loch\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 Total Pago}
\cell\pard\plain \intbl\ltrpar\s1\cf0\qr\rtlch\afs24\lang255\ab\ltrch\dbch\langfe255\hich\fs24\lang1040\b\loch\fs24\lang1040\b {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b [nombre_divisa] [r5][c ultimo_pago="1"][valor_pago_p][/c][/r5]}
\cell\row\pard \pard\plain \ltrpar\s1\cf0\ql\rtlch\afs24\lang255\ltrch\dbch\langfe255\hich\fs24\lang1040\loch\fs24\lang1040 
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\brdrb\brdrs\brdrw20\brdrcf1\brsp20{\*\brdrb\brdlncol1\brdlnin0\brdlnout20\brdlndist0}\brsp20\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
[/r]\par }</cmp></riga>
<riga><cmp>1</cmp><cmp>contrhtm</cmp><cmp><B><U><FONT FACE="Times" SIZE=4><P ALIGN="CENTER">EJEMPLO DE CONTRATO PARA HOTELDRUID</P>
</U></B></FONT><FONT FACE="Times"><P ALIGN="JUSTIFY"></P>
<P ALIGN="JUSTIFY">&nbsp;</P><P ALIGN="JUSTIFY">
[El_] señor[a] [nombre] [apellido] nacid[o3] el [fecha_nacimiento] residente en [ciudad] [calle2] n 
[numero_calle] tel [telefono] alqilará un apartamento en hoteldruid
con su familia de [num_personas_tot] personas desde [fecha_inicial] hasta [fecha_final].
El precio será de [coste_tot_p]. Ha dejado una fianza de [fianza_p].
</P>
<P ALIGN="JUSTIFY">
Nign sitio, [hoy].
</P>
<P ALIGN="JUSTIFY"></P><P ALIGN="JUSTIFY">
El cliente&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
El proprietario</P>
<P ALIGN="JUSTIFY"></P>
<P ALIGN="JUSTIFY"> 
__________&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;____________</P>
<P ALIGN="JUSTIFY"></P>
</FONT></cmp></riga>
<riga><cmp>2</cmp><cmp>contrhtm</cmp><cmp><div style="page-break-after: always;"><br>
<div class="cuadro_factura" style="width: 780px; margin-left: 10px; margin-right: 10px; border: solid 1px black; padding: 30px; font-size: 12px;">
[r][r3][/r3] [/r]

<div class="datos_estructura">
[logo_fact]
<div class="nombre_estructura" style="font-size: large;">[tipo_estructura] [nombre_estructura]</div>
[razon_social_estructura]<br>
[direccion_estructura] - [ciudad_estructura]<br>
[codigo_postal_estructura] [nacion_estructura]<br>
C.I.F. [certificado_identificacion_fiscal_estructura] [cod_fisc_estruc_fact]<br>
[telefono_estruc_fact]<br>
</div>

<div class="datos_cliente" style="padding: 18px 0 8px 440px;">
Cliente [nombre_fact] [apellido_fact]<br>
[c calle_fact!=""][calle_fact][numero_calle_fact]<br>
[/c][c linea_ciudad_fact!=""][linea_ciudad_fact]<br>
[/c][c linea_nacion_fact!=""][linea_nacion_fact]<br>
[/c][c codigo_fiscal_fact!=""]C.I.F. [codigo_fiscal_fact]<br>
[/c][c num_identificacion_fiscal_fact!=""]D.N.I. / N.I.F. [num_identificacion_fiscal_fact]<br>
[/c]
</div>

<hr style="width: 100%; border: 1px solid black;">

<div class="numero_factura" style="padding: 24px 0 8px 0">
Factura n. [numero_progresivo_documento] del [hoy]
</div>


[r4 array="iva_porc_vect_fact"]
<table class="lista_factura" border="1" cellpadding="5" style="border: 1px black solid; width: 740px; margin-left: auto; margin-right: 5px; margin-top: 8px; border-collapse: collapse; background-color: #e6e6e6;">
[r]
[c ens_tarifa_fact="1"]<tr><td style="border-color: black;">Estancia desde el [fecha_inicial] al [fecha_final][frase_personas_fact]</td>
<td style="width: 120px; text-align: right; border-color: black;">[nombre_divisa] [tarifa_no_iva_fact_p]</td></tr>
[/c][c ens_descuento_fact="1"]<tr><td style="border-color: black;">Descuento</td>
<td style="width: 120px; text-align: right; border-color: black;">[nombre_divisa] [descuento_no_iva_fact_p]</td></tr>
[/c]
[r3][c ens_coste_agn_fact="1"]<tr><td style="border-color: black;">Extra: "[nombre_coste_agna]"</td>
<td style="width: 120px; text-align: right; border-color: black;">[nombre_divisa] [coste_agn_no_iva_fact_p]</td></tr>
[/c][c ens_coste_como_tasas_fact="1"]<tr><td style="border-color: black;">Tasa: "[nombre_coste_agna]"</td>
<td style="width: 120px; text-align: right; border-color: black;">[nombre_divisa] [tasas_coste_agna_p]</td></tr>
[/c][/r3][/r]
[c iva_porc_vect_fact(num_iva_fact)="-1"]<!--[/c]
[c ens_subtotal_fact="1"]<tr><td style="border-color: black;">Imponible al [iva_porc_vect_fact(num_iva_fact)]%</td>
<td style="width: 120px; text-align: right; border-color: black;">[nombre_divisa] [tot_parc_no_iva_fact_p]</td></tr>
<tr><td style="border-color: black;">Iva al [iva_porc_vect_fact(num_iva_fact)]%</td>
<td style="width: 120px; text-align: right; border-color: black;">[nombre_divisa] [tot_parc_iva_fact_p]</td></tr>
[/c]
[c iva_porc_vect_fact(num_iva_fact)="-1"]-->[/c]
</table>
[/r4]

<table class="imponible_factura" border="1" cellpadding="5" style="border: 1px black solid; width: 740px; margin-left: auto; margin-right: 5px; margin-top: 8px; border-collapse: collapse; background-color: #e6e6e6;">
<tr><td style="border-color: black;">Total Imponible</td>
<td style="width: 120px; text-align: right; border-color: black;">[nombre_divisa] [tot_no_iva_fact_p]</td></tr>
<tr><td style="border-color: black;">Total Impuestos[c num_iva_fact="1"] al [iva_porc_vect_fact(num_iva_fact)]%[/c]</td>
<td style="width: 120px; text-align: right; border-color: black;">[nombre_divisa] [iva_fact_p]</td></tr>
[r][r3][c ens_coste_tasa_fact="1"]
<tr><td style="border-color: black;">[nombre_coste_agna]</td>
<td style="width: 120px; text-align: right; border-color: black;">[nombre_divisa] [coste_agn_no_iva_fact_p]</td></tr>
[/c][/r3][/r]
</table>

<table class="total_factura" border="1" cellpadding="5" style="border: 1px black solid; width: 740px; margin-left: auto; margin-right: 5px; margin-top: 8px; border-collapse: collapse; background-color: #cccccc;">
<tr><td style="border-color: black;">Total Factura</td>
<td style="width: 120px; text-align: right; border-color: black;">[nombre_divisa] [coste_tot_fact_p]</td></tr>
</table>


<br>
<hr style="width: 100%; border: 1px solid black;">
<br>


</div>
</div></cmp></riga>
<riga><cmp>4</cmp><cmp>contrhtm</cmp><cmp><div class="cuadro_factura" style="width: 780px; margin: 10px; border: solid 1px black; padding: 30px; font-size: 12px; page-break-after: always">

<div class="datos_estructura">
[logo_recibo]
<div class="nombre_estructura" style="font-size: large;">[tipo_estructura] [nombre_estructura]</div>
[razon_social_estructura]<br>
[direccion_estructura] - [ciudad_estructura]<br>
[codigo_postal_estructura] [nacion_estructura]<br>
C.I.F. [certificado_identificacion_fiscal_estructura] [cod_fisc_estruc_recibo]<br>
[telefono_estruc_recibo]<br>
</div>

<div class="datos_cliente" style="padding: 18px 0 8px 440px;">
Cliente [nombre_recibo] [apellido_recibo]<br>
[c calle_recibo!=""][calle_recibo][numero_calle_recibo]<br>
[/c][c linea_ciudad_recibo!=""][linea_ciudad_recibo]<br>
[/c][c linea_nacion_recibo!=""][linea_nacion_recibo]<br>
[/c][c codigo_fiscal!=""]C.I.F. [codigo_fiscal]<br>
[/c][c num_identificacion_fiscal!=""]D.N.I. / N.I.F. [num_identificacion_fiscal]<br>
[/c]
</div>

<hr style="width: 100%; border: 1px solid black;">

<div class="numero_factura" style="padding: 24px 0 8px 0">
Recibo[c numero_progresivo_documento!=""] n. [numero_progresivo_documento][/c] del [hoy]
</div>


<table class="lista_factura" border="1" cellpadding="5" style="border: 1px black solid; width: 740px; margin-left: auto; margin-right: 5px; margin-top: 8px; border-collapse: collapse; background-color: #e6e6e6;">
<tr><td style="border-color: black;">[c fecha_inicial!=""]Reserva desde [fecha_inicial] hasta [fecha_final][/c][c num_personas_tot!=""] para [num_personas_tot] personas[/c][r5][c fecha_inicial="" & ultimo_pago="1"][metodo_pago][/c][/r5]</td>
<td style="width: 120px; text-align: right; border-color: black;">[r5][c mostrar_metodo_recibo="1" & ultimo_pago="1"][nombre_divisa] [valor_pago_p][/c][/r5]</td></tr>
</table>

<table class="total_factura" border="1" cellpadding="5" style="border: 1px black solid; width: 740px; margin-left: auto; margin-right: 5px; margin-top: 8px; border-collapse: collapse; background-color: #cccccc;">
<tr><td style="border-color: black;">Total Pago</td>
<td style="width: 120px; text-align: right; border-color: black;">[nombre_divisa] [r5][c ultimo_pago="1"][valor_pago_p][/c][/r5]</td></tr>
</table>


<br>
<hr style="width: 100%; border: 1px solid black;">
<br>


</div></cmp></riga>
<riga><cmp>9</cmp><cmp>contrhtm</cmp><cmp>[r][valor_nulo][r3][valor_nulo][/r3][/r][r4 array="costes_agnadidos_limpieza"][valor_nulo][/r4][r4 array="array_fechas_limpieza"][r][r3][valor_nulo][/r3][/r][/r4]
<h1>Informe limpieza del <em>[f_fecha_informe_limpieza]</em></h1>
<table class="clrep">
<tr class="headrow"><td>Habitación</td><td>Personas</td><td>Situación</td><td><small><small>Personas<br>en salida</small></small></td><td><small><small>Horario de<br>llegada</small></small></td>[cabezera_tabla_ca_limpieza]</tr>
[r6]
<tr[clase_linea_limpieza]><td>[unidad_limpieza]</td><td>[personas_limpieza(unidad_limpieza)]</td><td>[situacion_limpieza(unidad_limpieza)]</td><td>[personas_salida_limpieza(unidad_limpieza)]</td><td>[horario_llegada_limpieza(unidad_limpieza)]</td>[linea_unidad_ca_limpieza(unidad_limpieza)]</tr>
[repeticion_linea_cabezera_limpieza]
[/r6]
<tr class="headrow"><td>Total</td><td>[tot_personas_limpieza]</td><td><small>([tot_personas_salida_limpieza] llegadas)</small></td><td>[tot_personas_llegada_limpieza]</td><td></td>
[r4 array="total_ca_limpieza"]
<td>[total_ca_limpieza(num_ca_limpieza)]</td>
[/r4]</tr>
</table></cmp></riga>
<riga><cmp>12</cmp><cmp>contrhtm</cmp><cmp></cmp></riga>
<riga><cmp>13</cmp><cmp>contrhtm</cmp><cmp></cmp></riga>
<riga><cmp>14</cmp><cmp>contrhtm</cmp><cmp></cmp></riga>
<riga><cmp>6</cmp><cmp>contreml</cmp><cmp>#!mln!#es</cmp></riga>
<riga><cmp>7</cmp><cmp>contreml</cmp><cmp>#!mln!#es</cmp></riga>
<riga><cmp>8</cmp><cmp>contreml</cmp><cmp>#!mln!#es</cmp></riga>
<riga><cmp>5</cmp><cmp>cond9</cmp><cmp>ind#@?#@?set#%?102#%?=#%?txt#%?30#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>6</cmp><cmp>cond9</cmp><cmp>ind#@?#@?date#%?95#%?data_inizio_selezione#%?is#%?2#%?g</cmp></riga>
<riga><cmp>7</cmp><cmp>cond9</cmp><cmp>ind#@?or#$?data_inizio_selezione#%?=#%?txt#%?#$?var_tmp_limpieza#%?>#%?var#%?data_fine_selezione#@?set#%?-1#%?=#%?txt#%?Este documento se debe mirar desde la tabla con las salidas y las reservas corrientes (entrada "reservas" en el menú de arriba --&gt; "salidas y corrientes") o se deben seleccionar por lo menos 2 días.#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>8</cmp><cmp>cond9</cmp><cmp>ind#@?#@?date#%?84#%?data_inizio_selezione#%?is#%?1#%?g</cmp></riga>
<riga><cmp>9</cmp><cmp>cond9</cmp><cmp>rpt#@?#@?set#%?87#%?=#%?var#%?unita_occupata#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>10</cmp><cmp>cond9</cmp><cmp>rpt#@?#@?set#%?85#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>15</cmp><cmp>cond9</cmp><cmp>rpt#@?#@?set#%?86#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>16</cmp><cmp>cond9</cmp><cmp>rpt#@?#$?data_inizio#%?=#%?var#%?fecha_informe_limpieza#@?set#%?85#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>17</cmp><cmp>cond9</cmp><cmp>rpt#@?#$?data_fine#%?=#%?var#%?fecha_informe_limpieza#@?set#%?86#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>18</cmp><cmp>cond9</cmp><cmp>run#@?#@?set#%?87#%?=#%?var#%?nome_unita#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>19</cmp><cmp>cond9</cmp><cmp>rpt#@?and#$?llegada_limpieza#%?=#%?txt#%?1#$?situacion_limpieza(unidad_limpieza)#%?!=#%?txt#%?#@?set#%?a2322#%?=#%?txt#%?SAL+LLE#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>20</cmp><cmp>cond9</cmp><cmp>rpt#@?and#$?salida_limpieza#%?=#%?txt#%?1#$?situacion_limpieza(unidad_limpieza)#%?!=#%?txt#%?#@?set#%?a2322#%?=#%?txt#%?SAL+LLE#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>31</cmp><cmp>cond9</cmp><cmp>rpt#@?and#$?data_inizio#%?<#%?var#%?fecha_informe_limpieza#$?data_fine#%?>#%?var#%?fecha_informe_limpieza#@?set#%?a2322#%?=#%?txt#%?PERMANENCIA#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>33</cmp><cmp>cond9</cmp><cmp>rpt#@?and#$?llegada_limpieza#%?=#%?txt#%?1#$?situacion_limpieza(unidad_limpieza)#%?=#%?txt#%?#@?set#%?a2322#%?=#%?txt#%?LLEGADA#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>34</cmp><cmp>cond9</cmp><cmp>rpt#@?and#$?salida_limpieza#%?=#%?txt#%?1#$?situacion_limpieza(unidad_limpieza)#%?=#%?txt#%?#@?set#%?a2322#%?=#%?txt#%?SALIDA#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>35</cmp><cmp>cond9</cmp><cmp>ind#@?#@?date#%?89#%?fecha_informe_limpieza#%?da#%?0#%?g</cmp></riga>
<riga><cmp>36</cmp><cmp>cond9</cmp><cmp>rpt#@?#@?set#%?95#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>37</cmp><cmp>cond9</cmp><cmp>rpt#@?or#$?data_inizio#%?=#%?var#%?fecha_informe_limpieza#$?data_inizio#%?<#%?var#%?fecha_informe_limpieza#@?set#%?95#%?=#%?var#%?num_persone#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>38</cmp><cmp>cond9</cmp><cmp>rpt#@?or#$?data_fine#%?=#%?var#%?fecha_informe_limpieza#$?data_fine#%?<#%?var#%?fecha_informe_limpieza#@?set#%?95#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>39</cmp><cmp>cond9</cmp><cmp>rpt#@?#$?var_tmp_limpieza#%?!=#%?txt#%?#@?set#%?a2323#%?=#%?var#%?var_tmp_limpieza#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>40</cmp><cmp>cond9</cmp><cmp>rpt#@?and#$?var_tmp_limpieza#%?!=#%?txt#%?#$?n_letti_agg#%?!=#%?txt#%?#@?set#%?a2323#%?.=#%?txt#%?+#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>41</cmp><cmp>cond9</cmp><cmp>rpt#@?and#$?var_tmp_limpieza#%?!=#%?txt#%?#$?n_letti_agg#%?!=#%?txt#%?#@?set#%?a2323#%?.=#%?var#%?n_letti_agg#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>42</cmp><cmp>cond9</cmp><cmp>rpt#@?#$?var_tmp_limpieza#%?!=#%?txt#%?#@?set#%?a2325#%?=#%?var#%?num_persone_tot#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>43</cmp><cmp>cond9</cmp><cmp>rpt#@?#$?data_fine#%?=#%?var#%?fecha_informe_limpieza#@?set#%?a2324#%?=#%?var#%?num_persone#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>44</cmp><cmp>cond9</cmp><cmp>rpt#@?and#$?data_fine#%?=#%?var#%?fecha_informe_limpieza#$?n_letti_agg#%?!=#%?txt#%?#@?set#%?a2324#%?.=#%?txt#%?+#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>45</cmp><cmp>cond9</cmp><cmp>rpt#@?and#$?data_fine#%?=#%?var#%?fecha_informe_limpieza#$?n_letti_agg#%?!=#%?txt#%?#@?set#%?a2324#%?.=#%?var#%?n_letti_agg#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>46</cmp><cmp>cond9</cmp><cmp>run#@?#@?oper#%?90#%?tot_personas_limpieza#%?+#%?var#%?numero_personas_limpieza(unidad_limpieza)#%?</cmp></riga>
<riga><cmp>47</cmp><cmp>cond9</cmp><cmp>rpt#@?#$?data_fine#%?=#%?var#%?fecha_informe_limpieza#@?set#%?a2326#%?=#%?var#%?num_persone_tot#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>48</cmp><cmp>cond9</cmp><cmp>run#@?#@?oper#%?91#%?tot_personas_llegada_limpieza#%?+#%?var#%?numero_personas_salida_limpieza(unidad_limpieza)#%?</cmp></riga>
<riga><cmp>49</cmp><cmp>cond9</cmp><cmp>rpt#@?#$?data_inizio#%?=#%?var#%?fecha_informe_limpieza#@?set#%?a2327#%?=#%?var#%?num_persone_tot#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>50</cmp><cmp>cond9</cmp><cmp>run#@?#@?oper#%?92#%?tot_personas_salida_limpieza#%?+#%?var#%?numero_personas_llegada_limpieza(unidad_limpieza)#%?</cmp></riga>
<riga><cmp>51</cmp><cmp>cond9</cmp><cmp>rpt#@?#$?data_inizio#%?=#%?var#%?fecha_informe_limpieza#@?set#%?a2328#%?=#%?var#%?orario_entrata_stimato#%?var#%?fecha_informe_limpieza#%?txt#%?#%?</cmp></riga>
<riga><cmp>52</cmp><cmp>cond9</cmp><cmp>ind#@?#@?set#%?93#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>53</cmp><cmp>cond9</cmp><cmp>rca#@?#$?numero_repeticion_limpieza#%?!=#%?txt#%?1#@?break#%?cont</cmp></riga>
<riga><cmp>54</cmp><cmp>cond9</cmp><cmp>rca#@?#@?set#%?95#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>55</cmp><cmp>cond9</cmp><cmp>rca#@?#$?giorni_costo_agg#%?{A}#%?txt#%?,#@?set#%?95#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>56</cmp><cmp>cond9</cmp><cmp>rca#@?#$?var_tmp_limpieza#%?=#%?txt#%?0#@?break#%?cont</cmp></riga>
<riga><cmp>57</cmp><cmp>cond9</cmp><cmp>rca#@?#$?pos_ca_limpieza(nome_costo_agg)#%?=#%?txt#%?#@?oper#%?93#%?num_ca_limpieza#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>58</cmp><cmp>cond9</cmp><cmp>rca#@?#$?pos_ca_limpieza(nome_costo_agg)#%?=#%?txt#%?#@?set#%?a2329#%?=#%?var#%?nome_costo_agg#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>59</cmp><cmp>cond9</cmp><cmp>ind#@?#@?set#%?94#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>60</cmp><cmp>cond9</cmp><cmp>inr#@?#@?oper#%?94#%?numero_repeticion_limpieza#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>61</cmp><cmp>cond9</cmp><cmp>rca#@?#$?pos_ca_limpieza(nome_costo_agg)#%?=#%?txt#%?#@?set#%?a2330#%?=#%?var#%?num_ca_limpieza#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>62</cmp><cmp>cond9</cmp><cmp>rca#@?#@?cont</cmp></riga>
<riga><cmp>63</cmp><cmp>cond9</cmp><cmp>run#@?#@?set#%?95#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>64</cmp><cmp>cond9</cmp><cmp>run#@?#$?clase_linea_limpieza#%?!=#%?txt#%?#@?set#%?95#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>65</cmp><cmp>cond9</cmp><cmp>run#@?#$?var_tmp_limpieza#%?!=#%?txt#%?1#@?set#%?88#%?=#%?txt#%? class="bgclr"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>66</cmp><cmp>cond9</cmp><cmp>run#@?#$?var_tmp_limpieza#%?=#%?txt#%?1#@?set#%?88#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>67</cmp><cmp>cond9</cmp><cmp>rar2329#@?#@?set#%?96#%?.=#%?txt#%?<td><small><small>#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>68</cmp><cmp>cond9</cmp><cmp>rar2329#@?#@?set#%?96#%?.=#%?var#%?costes_agnadidos_limpieza(num_ca_limpieza)#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>69</cmp><cmp>cond9</cmp><cmp>rar2329#@?#@?set#%?96#%?.=#%?txt#%?</small></small></td>#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>71</cmp><cmp>cond9</cmp><cmp>rar2329#@?#@?set#%?97#%?.=#%?txt#%?<td><!-- cost#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>72</cmp><cmp>cond9</cmp><cmp>rar2329#@?#@?set#%?97#%?.=#%?var#%?num_ca_limpieza#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>73</cmp><cmp>cond9</cmp><cmp>rar2329#@?#@?set#%?97#%?.=#%?txt#%? --></td>#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>74</cmp><cmp>cond9</cmp><cmp>rca#@?#$?numero_repeticion_limpieza#%?<#%?txt#%?2#@?break#%?cont</cmp></riga>
<riga><cmp>75</cmp><cmp>cond9</cmp><cmp>rca#@?#$?array_fechas_limpieza(dia_limpieza)#%?!=#%?var#%?fecha_informe_limpieza#@?break#%?cont</cmp></riga>
<riga><cmp>76</cmp><cmp>cond9</cmp><cmp>rca#@?#$?pos_ca_limpieza(nome_costo_agg)#%?=#%?txt#%?#@?break#%?cont</cmp></riga>
<riga><cmp>77</cmp><cmp>cond9</cmp><cmp>rca#@?#@?set#%?87#%?=#%?var#%?unita_occupata#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>78</cmp><cmp>cond9</cmp><cmp>rca#@?#$?linea_unidad_ca_limpieza(unidad_limpieza)#%?=#%?txt#%?#@?set#%?a2332#%?=#%?var#%?linea_tabla_ca_limpieza#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>79</cmp><cmp>cond9</cmp><cmp>ind#@?#@?array#%?a2333#%?dat#%?</cmp></riga>
<riga><cmp>80</cmp><cmp>cond9</cmp><cmp>rca#@?#@?set#%?95#%?=#%?txt#%?<!-- cost#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>82</cmp><cmp>cond9</cmp><cmp>rca#@?#@?set#%?95#%?.=#%?var#%?pos_ca_limpieza(nome_costo_agg)#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>83</cmp><cmp>cond9</cmp><cmp>rca#@?#@?set#%?95#%?.=#%?txt#%? -->#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>84</cmp><cmp>cond9</cmp><cmp>rca#@?#@?set#%?a2332#%?=#%?var#%?linea_unidad_ca_limpieza(unidad_limpieza)#%?var#%?var_tmp_limpieza#%?var#%?moltiplica_max_costo_agg#%?</cmp></riga>
<riga><cmp>85</cmp><cmp>cond9</cmp><cmp>rca#@?#@?set#%?93#%?=#%?var#%?pos_ca_limpieza(nome_costo_agg)#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>86</cmp><cmp>cond9</cmp><cmp>rca#@?#@?oper#%?a2334#%?total_ca_limpieza(num_ca_limpieza)#%?+#%?var#%?moltiplica_max_costo_agg#%?</cmp></riga>
<riga><cmp>87</cmp><cmp>cond9</cmp><cmp>rca#@?#@?cont</cmp></riga>
<riga><cmp>88</cmp><cmp>cond9</cmp><cmp>run#@?#$?linea_unidad_ca_limpieza(unidad_limpieza)#%?=#%?txt#%?#@?set#%?a2332#%?=#%?var#%?linea_tabla_ca_limpieza#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>89</cmp><cmp>cond9</cmp><cmp>rpt#@?#$?data_inizio#%?=#%?var#%?fecha_informe_limpieza#@?trunc#%?a2328#%?-3#%?#%?ini</cmp></riga>
<riga><cmp>90</cmp><cmp>cond9</cmp><cmp>rar2329#@?#@?set#%?a2334#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>91</cmp><cmp>cond9</cmp><cmp>ind#@?#@?set#%?99#%?=#%?txt#%?<tr class="headrow"><td>Habitación</td><td>Personas</td><td>Situación</td><td><small><small>Personas<br>en salida</small></small></td><td><small><small>Horario de<br>llegada</small></small></td>#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>92</cmp><cmp>cond9</cmp><cmp>run#@?#@?oper#%?100#%?numero_repeticion_unidad_limpieza#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>93</cmp><cmp>cond9</cmp><cmp>run#@?#@?set#%?101#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>94</cmp><cmp>cond9</cmp><cmp>run#@?#$?numero_repeticion_unidad_limpieza#%?=#%?var#%?numero_repeticion_cabezera_limpieza#@?set#%?101#%?=#%?var#%?linea_cabezera_tabla_limpieza#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>95</cmp><cmp>cond9</cmp><cmp>run#@?#$?numero_repeticion_unidad_limpieza#%?=#%?var#%?numero_repeticion_cabezera_limpieza#@?set#%?101#%?.=#%?var#%?cabezera_tabla_ca_limpieza#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>96</cmp><cmp>cond9</cmp><cmp>run#@?#$?numero_repeticion_unidad_limpieza#%?=#%?var#%?numero_repeticion_cabezera_limpieza#@?set#%?101#%?.=#%?txt#%?</tr>#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>97</cmp><cmp>cond9</cmp><cmp>run#@?#$?numero_repeticion_unidad_limpieza#%?=#%?var#%?numero_repeticion_cabezera_limpieza#@?set#%?100#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>1</cmp><cmp>cond8</cmp><cmp>rpt#@?#@?set#%?104#%?=#%?var#%?cognome#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>2</cmp><cmp>cond8</cmp><cmp>rpt#@?#@?set#%?105#%?=#%?var#%?cognome#%?txt#%? #%?txt#%?#%?</cmp></riga>
<riga><cmp>3</cmp><cmp>cond8</cmp><cmp>rpt#@?#@?trunc#%?105#%?6#%?#%?ini</cmp></riga>
<riga><cmp>4</cmp><cmp>cond8</cmp><cmp>rpt#@?#@?set#%?105#%?=#%?var#%?apel_no_esp_eb#%?txt#%?#%?txt#%?#%?url</cmp></riga>
<riga><cmp>5</cmp><cmp>cond8</cmp><cmp>rpt#@?#$?ultima_prenotazione_per_cliente#%?=#%?txt#%?1#@?break#%?cont</cmp></riga>
<riga><cmp>6</cmp><cmp>cond8</cmp><cmp>rpt#@?#@?set#%?a2340#%?.=#%?var#%?url_base_pagine_web#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>7</cmp><cmp>cond8</cmp><cmp>rpt#@?#@?set#%?a2340#%?.=#%?txt#%?mdl_confirma_reserva.php?cn=#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>8</cmp><cmp>cond8</cmp><cmp>rpt#@?#@?set#%?a2340#%?.=#%?var#%?apel_no_esp_eb#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>9</cmp><cmp>cond8</cmp><cmp>rpt#@?#@?set#%?a2340#%?.=#%?txt#%?&cp=#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>10</cmp><cmp>cond8</cmp><cmp>rpt#@?#@?set#%?a2340#%?.=#%?var#%?codice_prenotazione#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>11</cmp><cmp>cond8</cmp><cmp>rpt#@?#@?set#%?a2340#%?.=#%?txt#%?&fe=1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>12</cmp><cmp>cond8</cmp><cmp>rpt#@?#@?set#%?a2340#%?.=#%?var#%?avanzamento_riga#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>13</cmp><cmp>cond8</cmp><cmp>rpt#@?#@?set#%?a2340#%?.=#%?var#%?avanzamento_riga#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>14</cmp><cmp>cond8</cmp><cmp>rpt#@?#@?set#%?a2341#%?=#%?var#%?arr_enlaces_eb(numero_cliente)#%?txt#%?mdl_confirma_reserva.php?cn=#%?txt#%?confirm_reservation_tpl.php?cn=#%?</cmp></riga>
<riga><cmp>15</cmp><cmp>cond8</cmp><cmp>rpt#@?#@?cont</cmp></riga>
<riga><cmp>16</cmp><cmp>cond8</cmp><cmp>rpt#@?#$?ultima_prenotazione_per_cliente#%?!=#%?txt#%?1#@?set#%?-2#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>1</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?20#%?=#%?var#%?cognome#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>2</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?21#%?=#%?var#%?cognome#%?txt#%? #%?txt#%?#%?</cmp></riga>
<riga><cmp>3</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?trunc#%?21#%?6#%?#%?ini</cmp></riga>
<riga><cmp>4</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?21#%?=#%?var#%?apel_no_esp_ec#%?txt#%?#%?txt#%?#%?url</cmp></riga>
<riga><cmp>5</cmp><cmp>cond7</cmp><cmp>rpt#@?#$?ultima_prenotazione_per_cliente#%?=#%?txt#%?1#@?break#%?cont</cmp></riga>
<riga><cmp>6</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?a2336#%?.=#%?var#%?url_base_pagine_web#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>7</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?a2336#%?.=#%?txt#%?mdl_confirma_reserva.php?cn=#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>8</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?a2336#%?.=#%?var#%?apel_no_esp_ec#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>9</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?a2336#%?.=#%?txt#%?&cp=#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>10</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?a2336#%?.=#%?var#%?codice_prenotazione#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>11</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?a2336#%?.=#%?var#%?avanzamento_riga#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>12</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?a2336#%?.=#%?var#%?avanzamento_riga#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>13</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?a2337#%?=#%?var#%?arr_enlaces_ec(numero_cliente)#%?txt#%?mdl_confirma_reserva.php?cn=#%?txt#%?confirm_reservation_tpl.php?cn=#%?</cmp></riga>
<riga><cmp>14</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?a2338#%?.=#%?txt#%?Apellido: #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>15</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?a2338#%?.=#%?var#%?cognome#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>16</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?a2338#%?.=#%?var#%?avanzamento_riga#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>17</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?a2338#%?.=#%?txt#%?Código reserva: #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>18</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?a2338#%?.=#%?var#%?codice_prenotazione#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>19</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?a2338#%?.=#%?var#%?avanzamento_riga#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>20</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?a2338#%?.=#%?var#%?avanzamento_riga#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>21</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?a2339#%?=#%?var#%?arr_datos_acceso_ec(numero_cliente)#%?txt#%?Apellido:#%?txt#%?Surname:#%?</cmp></riga>
<riga><cmp>22</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?a2339#%?=#%?var#%?arr_datos_acceso_en_ec(numero_cliente)#%?txt#%?Código reserva:#%?txt#%?Reservation code:#%?</cmp></riga>
<riga><cmp>23</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?cont</cmp></riga>
<riga><cmp>24</cmp><cmp>cond7</cmp><cmp>rpt#@?#$?ultima_prenotazione_per_cliente#%?!=#%?txt#%?1#@?set#%?-2#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>1</cmp><cmp>cond6</cmp><cmp>rpt#@?#@?set#%?19#%?=#%?var#%?cognome#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>87</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?codice_fiscale_struttura#%?!=#%?txt#%?#@?set#%?14#%?=#%?txt#%?- N.I.F. #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>88</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?codice_fiscale_struttura#%?!=#%?txt#%?#@?set#%?14#%?.=#%?var#%?codice_fiscale_struttura#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>89</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?17#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>92</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?telefono_struttura#%?!=#%?txt#%?#@?set#%?17#%?=#%?txt#%?Tel. #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>94</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?telefono_struttura#%?!=#%?txt#%?#@?set#%?17#%?.=#%?var#%?telefono_struttura#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>97</cmp><cmp>cond4</cmp><cmp>rpt#@?and#$?telefono_struttura#%?!=#%?txt#%?#$?sito_web_struttura#%?!=#%?txt#%?#@?set#%?17#%?.=#%?txt#%? - #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>98</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?sito_web_struttura#%?!=#%?txt#%?#@?set#%?17#%?.=#%?var#%?sito_web_struttura#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>99</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?15#%?=#%?var#%?nome#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>100</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?16#%?=#%?var#%?cognome#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>101</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?18#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>102</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?numcivico#%?!=#%?txt#%?#@?set#%?18#%?=#%?txt#%?, #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>103</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?numcivico#%?!=#%?txt#%?#@?set#%?18#%?.=#%?var#%?numcivico#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>104</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?12#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>105</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?citta#%?!=#%?txt#%?#@?set#%?12#%?.=#%?var#%?citta#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>107</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?regione#%?!=#%?txt#%?#@?set#%?12#%?.=#%?txt#%? (#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>108</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?regione#%?!=#%?txt#%?#@?set#%?12#%?.=#%?var#%?regione#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>109</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?regione#%?!=#%?txt#%?#@?set#%?12#%?.=#%?txt#%?)#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>110</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?13#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>111</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?cap#%?!=#%?txt#%?#@?set#%?13#%?.=#%?var#%?cap#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>112</cmp><cmp>cond4</cmp><cmp>rpt#@?and#$?cap#%?!=#%?txt#%?#$?nazione#%?!=#%?txt#%?#@?set#%?13#%?.=#%?txt#%? #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>113</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?nazione#%?!=#%?txt#%?#@?set#%?13#%?.=#%?var#%?nazione#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>114</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?57#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>115</cmp><cmp>cond4</cmp><cmp>rpa#@?and#$?data_inizio#%?=#%?txt#%?#$?ultimo_pagamento#%?=#%?txt#%?1#$?metodo_pagamento#%?!=#%?txt#%?#@?set#%?57#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>116</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?logo_struttura#%?!=#%?txt#%?#@?set#%?103#%?=#%?txt#%?<img src="#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>117</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?logo_struttura#%?!=#%?txt#%?#@?set#%?103#%?.=#%?var#%?logo_struttura#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>118</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?logo_struttura#%?!=#%?txt#%?#@?set#%?103#%?.=#%?txt#%?" alt="Logo" style="float: right;">#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>25</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?45#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>26</cmp><cmp>cond2</cmp><cmp>rpt#@?and#$?iva_porc_vect_fact(num_iva_fact)#%?=#%?var#%?percentuale_tasse_tariffa#$?num_ripeticion_fact#%?>#%?txt#%?1#@?set#%?45#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>27</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?46#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>30</cmp><cmp>cond2</cmp><cmp>rpt#@?and#$?ens_tarifa_fact#%?=#%?txt#%?1#$?sconto#%?!=#%?txt#%?0#@?set#%?46#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>31</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?47#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>32</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?62#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>36</cmp><cmp>cond2</cmp><cmp>ind#@?#@?set#%?63#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>38</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?59#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>39</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?nome_costo_agg#%?=#%?var#%?nombre_coste_tasa_fact#@?set#%?59#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>40</cmp><cmp>cond2</cmp><cmp>rpt#@?and#$?iva_porc_vect_fact(num_iva_fact)#%?=#%?var#%?percentuale_tasse_costo_agg#$?valore_costo_agg#%?!=#%?txt#%?0#$?num_ripeticion_fact#%?>#%?txt#%?1#$?ens_coste_tasa_fact#%?!=#%?txt#%?1#@?set#%?47#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>42</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?28#%?=#%?var#%?percentuale_tasse_tariffa#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>43</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?var_tmp_fact#%?=#%?txt#%?#@?set#%?28#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>44</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?121#%?=#%?var#%?var_tmp_fact#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>46</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?iva_porc_exist_fact(var_tmp_fact)#%?=#%?txt#%?1#@?break#%?cont</cmp></riga>
<riga><cmp>48</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?44#%?num_iva_fact#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>52</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?53#%?=#%?var#%?num_iva_fact#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>60</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?a1#%?=#%?var#%?var_tmp_fact#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>61</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?a2#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>65</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?cont</cmp></riga>
<riga><cmp>75</cmp><cmp>cond2</cmp><cmp>rpt#@?or#$?valore_costo_agg#%?=#%?txt#%?0#$?valore_costo_agg#%?=#%?txt#%?#$?ens_coste_tasa_fact#%?=#%?txt#%?1#@?break#%?cont</cmp></riga>
<riga><cmp>76</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?28#%?=#%?var#%?percentuale_tasse_costo_agg#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>81</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?var_tmp_fact#%?=#%?txt#%?#@?set#%?28#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>83</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?iva_porc_exist_fact(var_tmp_fact)#%?=#%?txt#%?1#@?break#%?cont</cmp></riga>
<riga><cmp>84</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?44#%?num_iva_fact#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>86</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?53#%?=#%?var#%?num_iva_fact#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>87</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?a1#%?=#%?var#%?var_tmp_fact#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>88</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?a2#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>89</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?cont</cmp></riga>
<riga><cmp>90</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?37#%?valore_costo_agg_senza_tasse#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>91</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?ens_coste_tasa_fact#%?=#%?txt#%?1#@?oper#%?37#%?valore_costo_agg#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>95</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?31#%?=#%?var#%?nome_costo_agg#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>100</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?32#%?tot_no_iva_fact#%?-#%?var#%?tot_parc_no_iva_fact#%?</cmp></riga>
<riga><cmp>105</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?ens_coste_agn_fact#%?=#%?txt#%?1#@?oper#%?49#%?tot_parc_no_iva_fact#%?+#%?var#%?valore_costo_agg_senza_tasse#%?</cmp></riga>
<riga><cmp>106</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?ens_coste_agn_fact#%?=#%?txt#%?1#@?oper#%?50#%?tot_parc_iva_fact#%?+#%?var#%?tasse_costo_agg#%?</cmp></riga>
<riga><cmp>108</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?ens_coste_agn_fact#%?=#%?txt#%?1#@?oper#%?120#%?coste_tot_parc_fact#%?+#%?var#%?valore_costo_agg#%?</cmp></riga>
<riga><cmp>110</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?ens_coste_tasa_fact#%?=#%?txt#%?1#@?oper#%?61#%?tot_costes_tasa_fact#%?+#%?var#%?valore_costo_agg#%?</cmp></riga>
<riga><cmp>111</cmp><cmp>cond2</cmp><cmp>rpt#@?or#$?redondea_sobre_totales_fact#%?!=#%?txt#%?SI#$?ens_coste_agn_fact#%?!=#%?txt#%?1#@?break#%?cont</cmp></riga>
<riga><cmp>112</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?28#%?var_tmp_fact#%?+#%?txt#%?100#%?</cmp></riga>
<riga><cmp>113</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?49#%?coste_tot_parc_fact#%?*#%?txt#%?100#%?</cmp></riga>
<riga><cmp>114</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?49#%?tot_parc_no_iva_fact#%?/#%?var#%?var_tmp_fact#%?0.01</cmp></riga>
<riga><cmp>115</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?50#%?coste_tot_parc_fact#%?-#%?var#%?tot_parc_no_iva_fact#%?</cmp></riga>
<riga><cmp>116</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?cont</cmp></riga>
<riga><cmp>117</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?32#%?tot_no_iva_fact#%?+#%?var#%?tot_parc_no_iva_fact#%?</cmp></riga>
<riga><cmp>118</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?36#%?tot_no_iva_fact#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>119</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?51#%?tot_parc_no_iva_fact#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>120</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?52#%?tot_parc_iva_fact#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>121</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?60#%?coste_tot_fact#%?-#%?var#%?tot_no_iva_fact#%?</cmp></riga>
<riga><cmp>122</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?60#%?iva_fact#%?-#%?var#%?tot_costes_tasa_fact#%?</cmp></riga>
<riga><cmp>123</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?35#%?iva_fact#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>125</cmp><cmp>cond2</cmp><cmp>rpt#@?or#$?ens_coste_agn_fact#%?!=#%?txt#%?1#$?percentuale_tasse_costo_agg#%?!=#%?txt#%?-1#@?break#%?cont</cmp></riga>
<riga><cmp>126</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?62#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>128</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?47#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>129</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?cont</cmp></riga>
<riga><cmp>130</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?max_num_iva_fact#%?>#%?txt#%?1#@?set#%?63#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>132</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?ultima_reserva_fact#%?=#%?var#%?numero_prenotazione#@?break#%?</cmp></riga>
<riga><cmp>133</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?30#%?=#%?var#%?numero_prenotazione#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>134</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?32#%?tot_no_iva_fact#%?-#%?var#%?tot_parc_no_iva_fact#%?</cmp></riga>
<riga><cmp>135</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?ens_tarifa_fact#%?=#%?txt#%?1#@?oper#%?49#%?tot_parc_no_iva_fact#%?+#%?var#%?costo_tariffa_senza_tasse#%?</cmp></riga>
<riga><cmp>136</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?ens_tarifa_fact#%?=#%?txt#%?1#@?oper#%?50#%?tot_parc_iva_fact#%?+#%?var#%?tasse_tariffa#%?</cmp></riga>
<riga><cmp>137</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?ens_tarifa_fact#%?=#%?txt#%?1#@?oper#%?120#%?coste_tot_parc_fact#%?+#%?var#%?costo_tariffa#%?</cmp></riga>
<riga><cmp>138</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?ens_descuento_fact#%?=#%?txt#%?1#@?oper#%?49#%?tot_parc_no_iva_fact#%?-#%?var#%?sconto_senza_tasse#%?</cmp></riga>
<riga><cmp>139</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?ens_descuento_fact#%?=#%?txt#%?1#@?oper#%?50#%?tot_parc_iva_fact#%?-#%?var#%?tasse_sconto#%?</cmp></riga>
<riga><cmp>140</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?ens_descuento_fact#%?=#%?txt#%?1#@?oper#%?120#%?coste_tot_parc_fact#%?-#%?var#%?sconto#%?</cmp></riga>
<riga><cmp>141</cmp><cmp>cond2</cmp><cmp>rpt#@?or#$?redondea_sobre_totales_fact#%?!=#%?txt#%?SI#$?ens_tarifa_fact#%?!=#%?txt#%?1#@?break#%?cont</cmp></riga>
<riga><cmp>142</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?28#%?porc_tasas_tar_fact#%?+#%?txt#%?100#%?</cmp></riga>
<riga><cmp>143</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?49#%?coste_tot_parc_fact#%?*#%?txt#%?100#%?</cmp></riga>
<riga><cmp>144</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?49#%?tot_parc_no_iva_fact#%?/#%?var#%?var_tmp_fact#%?0.01</cmp></riga>
<riga><cmp>145</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?50#%?coste_tot_parc_fact#%?-#%?var#%?tot_parc_no_iva_fact#%?</cmp></riga>
<riga><cmp>146</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?cont</cmp></riga>
<riga><cmp>147</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?32#%?tot_no_iva_fact#%?+#%?var#%?tot_parc_no_iva_fact#%?</cmp></riga>
<riga><cmp>148</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?39#%?costo_tariffa_senza_tasse#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>149</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?38#%?sconto_senza_tasse#%?*#%?txt#%?-1#%?</cmp></riga>
<riga><cmp>150</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?36#%?tot_no_iva_fact#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>151</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?51#%?tot_parc_no_iva_fact#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>152</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?52#%?tot_parc_iva_fact#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>153</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?60#%?coste_tot_fact#%?-#%?var#%?tot_no_iva_fact#%?</cmp></riga>
<riga><cmp>154</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?60#%?iva_fact#%?-#%?var#%?tot_costes_tasa_fact#%?</cmp></riga>
<riga><cmp>155</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?35#%?iva_fact#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>156</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?une_descuento_a_tarifa#%?=#%?txt#%?SI#@?oper#%?39#%?costo_tariffa_senza_tasse#%?-#%?var#%?sconto_senza_tasse#%?</cmp></riga>
<riga><cmp>157</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?une_descuento_a_tarifa#%?=#%?txt#%?SI#@?set#%?46#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>158</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?54#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>159</cmp><cmp>cond2</cmp><cmp>rpt#@?and#$?num_persone_tot#%?!=#%?txt#%?#$?num_persone_tot#%?!=#%?txt#%?0#@?set#%?54#%?=#%?txt#%? para x personas#%?txt#%?x#%?var#%?num_persone_tot#%?</cmp></riga>
<riga><cmp>160</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?num_ripeticion_fact#%?>#%?txt#%?1#@?break#%?</cmp></riga>
<riga><cmp>161</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?33#%?coste_tot_fact#%?+#%?var#%?costo_tot#%?</cmp></riga>
<riga><cmp>162</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?34#%?coste_tot_fact#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>163</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?codice_fiscale_struttura#%?!=#%?txt#%?#@?set#%?24#%?=#%?txt#%?- N.I.F. #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>164</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?codice_fiscale_struttura#%?!=#%?txt#%?#@?set#%?24#%?.=#%?var#%?codice_fiscale_struttura#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>165</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?telefono_struttura#%?!=#%?txt#%?#@?set#%?27#%?=#%?txt#%?Tel. #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>166</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?telefono_struttura#%?!=#%?txt#%?#@?set#%?27#%?.=#%?var#%?telefono_struttura#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>167</cmp><cmp>cond2</cmp><cmp>inr#@?#@?set#%?30#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>168</cmp><cmp>cond2</cmp><cmp>inr#@?#@?oper#%?48#%?num_ripeticion_fact#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>169</cmp><cmp>cond2</cmp><cmp>ind#@?#@?set#%?55#%?=#%?txt#%?SI#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>170</cmp><cmp>cond2</cmp><cmp>ind#@?#@?set#%?119#%?=#%?txt#%?SI#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>171</cmp><cmp>cond2</cmp><cmp>ind#@?#@?set#%?58#%?=#%?txt#%?nombre del coste a cosiderar como tasa#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>172</cmp><cmp>cond2</cmp><cmp>ind#@?#@?set#%?33#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>173</cmp><cmp>cond2</cmp><cmp>rpt#@?and#$?telefono_struttura#%?!=#%?txt#%?#$?sito_web_struttura#%?!=#%?txt#%?#@?set#%?27#%?.=#%?txt#%? - #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>174</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?sito_web_struttura#%?!=#%?txt#%?#@?set#%?27#%?.=#%?var#%?sito_web_struttura#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>175</cmp><cmp>cond2</cmp><cmp>ind#@?#@?set#%?32#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>176</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?25#%?=#%?var#%?nome#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>177</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?26#%?=#%?var#%?cognome#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>178</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?40#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>179</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?numcivico#%?!=#%?txt#%?#@?set#%?40#%?=#%?txt#%?, #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>180</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?numcivico#%?!=#%?txt#%?#@?set#%?40#%?.=#%?var#%?numcivico#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>181</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?22#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>182</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?citta#%?!=#%?txt#%?#@?set#%?22#%?.=#%?var#%?citta#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>183</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?regione#%?!=#%?txt#%?#@?set#%?22#%?.=#%?txt#%? (#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>184</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?regione#%?!=#%?txt#%?#@?set#%?22#%?.=#%?var#%?regione#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>185</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?regione#%?!=#%?txt#%?#@?set#%?22#%?.=#%?txt#%?)#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>186</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?23#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>187</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?cap#%?!=#%?txt#%?#@?set#%?23#%?.=#%?var#%?cap#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>188</cmp><cmp>cond2</cmp><cmp>rpt#@?and#$?cap#%?!=#%?txt#%?#$?nazione#%?!=#%?txt#%?#@?set#%?23#%?.=#%?txt#%? #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>189</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?nazione#%?!=#%?txt#%?#@?set#%?23#%?.=#%?var#%?nazione#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>190</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?41#%?=#%?var#%?partita_iva#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>191</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?42#%?=#%?var#%?codice_fiscale#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>192</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?43#%?=#%?var#%?via#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>193</cmp><cmp>cond2</cmp><cmp>ind#@?#@?set#%?44#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>194</cmp><cmp>cond2</cmp><cmp>ind#@?#@?set#%?48#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>195</cmp><cmp>cond2</cmp><cmp>inr#@?#@?set#%?49#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>196</cmp><cmp>cond2</cmp><cmp>inr#@?#@?set#%?50#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>197</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?logo_struttura#%?!=#%?txt#%?#@?set#%?56#%?=#%?txt#%?<img src="#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>198</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?logo_struttura#%?!=#%?txt#%?#@?set#%?56#%?.=#%?var#%?logo_struttura#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>199</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?logo_struttura#%?!=#%?txt#%?#@?set#%?56#%?.=#%?txt#%?" alt="Logo" style="float: right;">#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>200</cmp><cmp>cond2</cmp><cmp>inr#@?#@?set#%?61#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>201</cmp><cmp>cond2</cmp><cmp>inr#@?#@?set#%?120#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>1</cmp><cmp>cond11</cmp><cmp>rpt#@?#@?set#%?106#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>2</cmp><cmp>cond11</cmp><cmp>rpt#@?or#$?cognome#%?{}#%?txt#%?&quot;#$?cognome#%?{}#%?txt#%?,#@?set#%?106#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>3</cmp><cmp>cond11</cmp><cmp>rpt#@?#@?set#%?106#%?.=#%?var#%?cognome#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>4</cmp><cmp>cond11</cmp><cmp>rpt#@?or#$?cognome#%?{}#%?txt#%?&quot;#$?cognome#%?{}#%?txt#%?,#@?set#%?106#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>5</cmp><cmp>cond11</cmp><cmp>rpt#@?#@?set#%?107#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>6</cmp><cmp>cond11</cmp><cmp>rpt#@?or#$?nome#%?{}#%?txt#%?&quot;#$?nome#%?{}#%?txt#%?,#@?set#%?107#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>7</cmp><cmp>cond11</cmp><cmp>rpt#@?#@?set#%?107#%?.=#%?var#%?nome#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>8</cmp><cmp>cond11</cmp><cmp>rpt#@?or#$?nome#%?{}#%?txt#%?&quot;#$?nome#%?{}#%?txt#%?,#@?set#%?107#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>9</cmp><cmp>cond11</cmp><cmp>rpt#@?#@?set#%?108#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>10</cmp><cmp>cond11</cmp><cmp>rpt#@?or#$?unita_occupata#%?{}#%?txt#%?&quot;#$?unita_occupata#%?{}#%?txt#%?,#@?set#%?108#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>11</cmp><cmp>cond11</cmp><cmp>rpt#@?#@?set#%?108#%?.=#%?var#%?unita_occupata#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>12</cmp><cmp>cond11</cmp><cmp>rpt#@?or#$?unita_occupata#%?{}#%?txt#%?&quot;#$?unita_occupata#%?{}#%?txt#%?,#@?set#%?108#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>13</cmp><cmp>cond11</cmp><cmp>rpt#@?#@?set#%?109#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>14</cmp><cmp>cond11</cmp><cmp>rpt#@?or#$?nome_tariffa#%?{}#%?txt#%?&quot;#$?nome_tariffa#%?{}#%?txt#%?,#@?set#%?109#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>15</cmp><cmp>cond11</cmp><cmp>rpt#@?#@?set#%?109#%?.=#%?var#%?nome_tariffa#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>16</cmp><cmp>cond11</cmp><cmp>rpt#@?or#$?nome_tariffa#%?{}#%?txt#%?&quot;#$?nome_tariffa#%?{}#%?txt#%?,#@?set#%?109#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>17</cmp><cmp>cond11</cmp><cmp>rpt#@?#@?set#%?110#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>18</cmp><cmp>cond11</cmp><cmp>rpt#@?or#$?email#%?{}#%?txt#%?&quot;#$?email#%?{}#%?txt#%?,#@?set#%?110#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>19</cmp><cmp>cond11</cmp><cmp>rpt#@?#@?set#%?110#%?.=#%?var#%?email#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>20</cmp><cmp>cond11</cmp><cmp>rpt#@?or#$?email#%?{}#%?txt#%?&quot;#$?email#%?{}#%?txt#%?,#@?set#%?110#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>21</cmp><cmp>cond11</cmp><cmp>rpt#@?#@?set#%?111#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>22</cmp><cmp>cond11</cmp><cmp>rpt#@?or#$?telefono#%?{}#%?txt#%?&quot;#$?telefono#%?{}#%?txt#%?,#@?set#%?111#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>23</cmp><cmp>cond11</cmp><cmp>rpt#@?#@?set#%?111#%?.=#%?var#%?telefono#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>24</cmp><cmp>cond11</cmp><cmp>rpt#@?or#$?telefono#%?{}#%?txt#%?&quot;#$?telefono#%?{}#%?txt#%?,#@?set#%?111#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>25</cmp><cmp>cond11</cmp><cmp>rpt#@?#@?set#%?112#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>26</cmp><cmp>cond11</cmp><cmp>rpt#@?or#$?costo_tariffa#%?{}#%?txt#%?&quot;#$?costo_tariffa#%?{}#%?txt#%?,#@?set#%?112#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>27</cmp><cmp>cond11</cmp><cmp>rpt#@?#@?set#%?112#%?.=#%?var#%?costo_tariffa#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>28</cmp><cmp>cond11</cmp><cmp>rpt#@?or#$?costo_tariffa#%?{}#%?txt#%?&quot;#$?costo_tariffa#%?{}#%?txt#%?,#@?set#%?112#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>29</cmp><cmp>cond11</cmp><cmp>rpt#@?#@?set#%?113#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>30</cmp><cmp>cond11</cmp><cmp>rpt#@?or#$?costo_tot#%?{}#%?txt#%?&quot;#$?costo_tot#%?{}#%?txt#%?,#@?set#%?113#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>31</cmp><cmp>cond11</cmp><cmp>rpt#@?#@?set#%?113#%?.=#%?var#%?costo_tot#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>32</cmp><cmp>cond11</cmp><cmp>rpt#@?or#$?costo_tot#%?{}#%?txt#%?&quot;#$?costo_tot#%?{}#%?txt#%?,#@?set#%?113#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>33</cmp><cmp>cond11</cmp><cmp>rpt#@?#@?set#%?114#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>34</cmp><cmp>cond11</cmp><cmp>rpt#@?or#$?pagato#%?{}#%?txt#%?&quot;#$?pagato#%?{}#%?txt#%?,#@?set#%?114#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>35</cmp><cmp>cond11</cmp><cmp>rpt#@?#@?set#%?114#%?.=#%?var#%?pagato#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>36</cmp><cmp>cond11</cmp><cmp>rpt#@?or#$?pagato#%?{}#%?txt#%?&quot;#$?pagato#%?{}#%?txt#%?,#@?set#%?114#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>37</cmp><cmp>cond11</cmp><cmp>rpt#@?#@?set#%?115#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>38</cmp><cmp>cond11</cmp><cmp>rpt#@?or#$?num_persone_tot#%?{}#%?txt#%?&quot;#$?num_persone_tot#%?{}#%?txt#%?,#@?set#%?115#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>39</cmp><cmp>cond11</cmp><cmp>rpt#@?#@?set#%?115#%?.=#%?var#%?num_persone_tot#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>40</cmp><cmp>cond11</cmp><cmp>rpt#@?or#$?num_persone_tot#%?{}#%?txt#%?&quot;#$?num_persone_tot#%?{}#%?txt#%?,#@?set#%?115#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>48</cmp><cmp>cond11</cmp><cmp>rpt#@?#@?set#%?116#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>49</cmp><cmp>cond11</cmp><cmp>rpt#@?or#$?commento#%?{}#%?txt#%?&quot;#$?commento#%?{}#%?txt#%?,#@?set#%?116#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>50</cmp><cmp>cond11</cmp><cmp>rpt#@?#@?set#%?116#%?.=#%?var#%?commento#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>51</cmp><cmp>cond11</cmp><cmp>rpt#@?#@?set#%?116#%?=#%?var#%?comentario_rcsv#%?var#%?avanzamento_riga#%?txt#%?#%?</cmp></riga>
<riga><cmp>56</cmp><cmp>cond11</cmp><cmp>rpt#@?or#$?commento#%?{}#%?txt#%?&quot;#$?commento#%?{}#%?txt#%?,#@?set#%?116#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>79</cmp><cmp>cond11</cmp><cmp>rpt#@?#@?date#%?117#%?data_inizio#%?is#%?0#%?g</cmp></riga>
<riga><cmp>80</cmp><cmp>cond11</cmp><cmp>rpt#@?#@?date#%?118#%?data_fine#%?is#%?0#%?g</cmp></riga>
<riga><cmp>1</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?64#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>2</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?cognome#%?{}#%?txt#%?&quot;#$?cognome#%?{}#%?txt#%?,#@?set#%?64#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>3</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?64#%?.=#%?var#%?cognome#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>4</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?cognome#%?{}#%?txt#%?&quot;#$?cognome#%?{}#%?txt#%?,#@?set#%?64#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>5</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?65#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>6</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?nome#%?{}#%?txt#%?&quot;#$?nome#%?{}#%?txt#%?,#@?set#%?65#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>7</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?65#%?.=#%?var#%?nome#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>8</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?nome#%?{}#%?txt#%?&quot;#$?nome#%?{}#%?txt#%?,#@?set#%?65#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>9</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?66#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>10</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?soprannome#%?{}#%?txt#%?&quot;#$?soprannome#%?{}#%?txt#%?,#@?set#%?66#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>11</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?66#%?.=#%?var#%?soprannome#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>12</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?soprannome#%?{}#%?txt#%?&quot;#$?soprannome#%?{}#%?txt#%?,#@?set#%?66#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>13</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?67#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>14</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?titolo#%?{}#%?txt#%?&quot;#$?titolo#%?{}#%?txt#%?,#@?set#%?67#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>15</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?67#%?.=#%?var#%?titolo#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>16</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?titolo#%?{}#%?txt#%?&quot;#$?titolo#%?{}#%?txt#%?,#@?set#%?67#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>17</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?68#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>18</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?email#%?{}#%?txt#%?&quot;#$?email#%?{}#%?txt#%?,#@?set#%?68#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>19</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?68#%?.=#%?var#%?email#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>20</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?email#%?{}#%?txt#%?&quot;#$?email#%?{}#%?txt#%?,#@?set#%?68#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>21</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?69#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>22</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?telefono#%?{}#%?txt#%?&quot;#$?telefono#%?{}#%?txt#%?,#@?set#%?69#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>23</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?69#%?.=#%?var#%?telefono#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>24</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?telefono#%?{}#%?txt#%?&quot;#$?telefono#%?{}#%?txt#%?,#@?set#%?69#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>25</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?70#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>26</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?fax#%?{}#%?txt#%?&quot;#$?fax#%?{}#%?txt#%?,#@?set#%?70#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>27</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?70#%?.=#%?var#%?fax#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>28</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?fax#%?{}#%?txt#%?&quot;#$?fax#%?{}#%?txt#%?,#@?set#%?70#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>29</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?71#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>30</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?nazione#%?{}#%?txt#%?&quot;#$?nazione#%?{}#%?txt#%?,#@?set#%?71#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>31</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?71#%?.=#%?var#%?nazione#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>32</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?nazione#%?{}#%?txt#%?&quot;#$?nazione#%?{}#%?txt#%?,#@?set#%?71#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>33</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?72#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>34</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?regione#%?{}#%?txt#%?&quot;#$?regione#%?{}#%?txt#%?,#@?set#%?72#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>35</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?72#%?.=#%?var#%?regione#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>36</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?regione#%?{}#%?txt#%?&quot;#$?regione#%?{}#%?txt#%?,#@?set#%?72#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>37</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?73#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>38</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?citta#%?{}#%?txt#%?&quot;#$?citta#%?{}#%?txt#%?,#@?set#%?73#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>39</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?73#%?.=#%?var#%?citta#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>40</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?citta#%?{}#%?txt#%?&quot;#$?citta#%?{}#%?txt#%?,#@?set#%?73#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>41</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?79#%?=#%?var#%?via#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>42</cmp><cmp>cond10</cmp><cmp>rpt#@?#$?numcivico#%?!=#%?txt#%?#@?set#%?79#%?.=#%?txt#%? #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>43</cmp><cmp>cond10</cmp><cmp>rpt#@?#$?numcivico#%?!=#%?txt#%?#@?set#%?79#%?.=#%?var#%?numcivico#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>44</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?74#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>45</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?tmp_csv#%?{}#%?txt#%?&quot;#$?tmp_csv#%?{}#%?txt#%?,#@?set#%?74#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>46</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?74#%?.=#%?var#%?tmp_csv#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>47</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?tmp_csv#%?{}#%?txt#%?&quot;#$?tmp_csv#%?{}#%?txt#%?,#@?set#%?74#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>48</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?75#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>49</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?cap#%?{}#%?txt#%?&quot;#$?cap#%?{}#%?txt#%?,#@?set#%?75#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>50</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?75#%?.=#%?var#%?cap#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>51</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?cap#%?{}#%?txt#%?&quot;#$?cap#%?{}#%?txt#%?,#@?set#%?75#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>52</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?76#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>53</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?cittadinanza#%?{}#%?txt#%?&quot;#$?cittadinanza#%?{}#%?txt#%?,#@?set#%?76#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>54</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?76#%?.=#%?var#%?cittadinanza#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>55</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?cittadinanza#%?{}#%?txt#%?&quot;#$?cittadinanza#%?{}#%?txt#%?,#@?set#%?76#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>56</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?77#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>57</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?date#%?77#%?data_nascita#%?da#%?0#%?g</cmp></riga>
<riga><cmp>58</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?78#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>59</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?partita_iva#%?{}#%?txt#%?&quot;#$?partita_iva#%?{}#%?txt#%?,#@?set#%?78#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>60</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?78#%?.=#%?var#%?partita_iva#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>61</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?partita_iva#%?{}#%?txt#%?&quot;#$?partita_iva#%?{}#%?txt#%?,#@?set#%?78#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>62</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?80#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>63</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?email2#%?{}#%?txt#%?&quot;#$?email2#%?{}#%?txt#%?,#@?set#%?80#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>64</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?80#%?.=#%?var#%?email2#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>65</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?email2#%?{}#%?txt#%?&quot;#$?email2#%?{}#%?txt#%?,#@?set#%?80#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>66</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?81#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>67</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?email_certificata#%?{}#%?txt#%?&quot;#$?email_certificata#%?{}#%?txt#%?,#@?set#%?81#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>68</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?81#%?.=#%?var#%?email_certificata#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>69</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?email_certificata#%?{}#%?txt#%?&quot;#$?email_certificata#%?{}#%?txt#%?,#@?set#%?81#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>70</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?82#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>71</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?telefono2#%?{}#%?txt#%?&quot;#$?telefono2#%?{}#%?txt#%?,#@?set#%?82#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>72</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?82#%?.=#%?var#%?telefono2#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>73</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?telefono2#%?{}#%?txt#%?&quot;#$?telefono2#%?{}#%?txt#%?,#@?set#%?82#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>74</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?83#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>75</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?telefono3#%?{}#%?txt#%?&quot;#$?telefono3#%?{}#%?txt#%?,#@?set#%?83#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>76</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?83#%?.=#%?var#%?telefono3#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>77</cmp><cmp>cond10</cmp><cmp>rpt#@?or#$?telefono3#%?{}#%?txt#%?&quot;#$?telefono3#%?{}#%?txt#%?,#@?set#%?83#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>78</cmp><cmp>cond10</cmp><cmp>rpt#@?#$?cliente_visto_csv(numero_cliente)#%?=#%?txt#%?1#@?set#%?-2#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>79</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?a2335#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>1</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?=#%?txt#%?f#@?set#%?1#%?=#%?txt#%?s#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>3</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?!=#%?txt#%?f#@?set#%?2#%?=#%?txt#%?il#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>4</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?=#%?txt#%?f#@?set#%?2#%?=#%?txt#%?la#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>5</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?!=#%?txt#%?f#@?set#%?3#%?=#%?txt#%?Il#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>6</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?=#%?txt#%?f#@?set#%?3#%?=#%?txt#%?La#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>7</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?!=#%?txt#%?f#@?set#%?4#%?=#%?txt#%?al#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>8</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?=#%?txt#%?f#@?set#%?4#%?=#%?txt#%?alla#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>9</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?!=#%?txt#%?f#@?set#%?5#%?=#%?txt#%?e#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>10</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?=#%?txt#%?f#@?set#%?5#%?=#%?txt#%?a#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>11</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?!=#%?txt#%?f#@?set#%?6#%?=#%?txt#%?o#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>12</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?=#%?txt#%?f#@?set#%?6#%?=#%?txt#%?a#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>23</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?!=#%?txt#%?f#@?set#%?7#%?=#%?txt#%?el#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>24</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?=#%?txt#%?f#@?set#%?7#%?=#%?txt#%?la#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>25</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?!=#%?txt#%?f#@?set#%?8#%?=#%?txt#%?El#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>26</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?=#%?txt#%?f#@?set#%?8#%?=#%?txt#%?La#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>27</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?!=#%?txt#%?f#@?set#%?9#%?=#%?txt#%?al#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>28</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?=#%?txt#%?f#@?set#%?9#%?=#%?txt#%?a la#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>29</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?!=#%?txt#%?f#@?set#%?10#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>30</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?=#%?txt#%?f#@?set#%?10#%?=#%?txt#%?a#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>31</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?!=#%?txt#%?f#@?set#%?11#%?=#%?txt#%?o#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>32</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?=#%?txt#%?f#@?set#%?11#%?=#%?txt#%?a#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>2</cmp><cmp>compress</cmp><cmp>gz</cmp></riga>
<riga><cmp>3</cmp><cmp>compress</cmp><cmp>gz</cmp></riga>
<riga><cmp>6</cmp><cmp>allegato</cmp><cmp>0</cmp></riga>
<riga><cmp>7</cmp><cmp>allegato</cmp><cmp>0</cmp></riga>
<riga><cmp>8</cmp><cmp>allegato</cmp><cmp>0</cmp></riga>
</righetabella>
</tabella>
<tabella>
<nometabella>cache</nometabella>
<colonnetabella>
<nomecolonna>numero</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>tipo</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>testo</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>data_modifica</nomecolonna>
<tipocolonna>12</tipocolonna>
<nomecolonna>datainserimento</nomecolonna>
<tipocolonna>12</tipocolonna>
</colonnetabella>
<righetabella>
</righetabella>
</tabella>
<tabella>
<nometabella>interconnessioni</nometabella>
<colonnetabella>
<nomecolonna>idlocale</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>idremoto1</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>idremoto2</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>tipoid</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>nome_ic</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>anno</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>datainserimento</nomecolonna>
<tipocolonna>12</tipocolonna>
<nomecolonna>hostinserimento</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>utente_inserimento</nomecolonna>
<tipocolonna>3</tipocolonna>
</colonnetabella>
<righetabella>
</righetabella>
</tabella>
<tabella>
<nometabella>messaggi</nometabella>
<colonnetabella>
<nomecolonna>idmessaggi</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>tipo_messaggio</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>stato</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>idutenti</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>idutenti_visto</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>datavisione</nomecolonna>
<tipocolonna>12</tipocolonna>
<nomecolonna>mittente</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>testo</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_messaggio1</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_messaggio2</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_messaggio3</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_messaggio4</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_messaggio5</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_messaggio6</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_messaggio7</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_messaggio8</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_messaggio9</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_messaggio10</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_messaggio11</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_messaggio12</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_messaggio13</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_messaggio14</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_messaggio15</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_messaggio16</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_messaggio17</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_messaggio18</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_messaggio19</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_messaggio20</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_messaggio21</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>dati_messaggio22</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>datainserimento</nomecolonna>
<tipocolonna>12</tipocolonna>
</colonnetabella>
<righetabella>
<riga><cmp>1</cmp><cmp>sistema</cmp><cmp></cmp><cmp>,1,</cmp><cmp>,1,</cmp><cmp>2025-10-26 08:40:30</cmp><cmp>1</cmp><cmp><div style="max-width: 600px; line-height: 1.1;"><h4>Bienvenido a HotelDruid!</h4><br>Estos son algunos simples pasos a seguir para configurar las funciones de base de HotelDruid:<br>
<ul style="line-height: 1.2;">
<li>Insertar las informaciones sobre las habitaciones desde la
 <em><b><a href="./visualizza_tabelle.php?tipo_tabella=appartamenti&amp;<sessione>">tabla habitaciones</a></b></em>, 
 utilizando el botón que está debajo de ella. Las habitaciones pueden ser creadas, borradas y cambiadas de nombre. 
 Se aconseja insertar por lo menos la capacidad máxima para cada habitación.<br><br></li>
<li>Insertar el número de tarifas, un nombre para cada una de ellas y los precios correspondientes desde la 
 <em><b><a href="./creaprezzi.php?<sessione>">página de inserción de precios</a></b></em>.
 Considerar que las tarifas de HotelDruid actuan también como tipologías de habitaciones (mirar el paso siguiente).<br><br></li>
<li>Asociar una lista de habitaciones para cada tarifa, insertando una regla de asignación 2 para cada una de ellas, desde la 
 <em><b><a href="./crearegole.php?<sessione>#regola2">página de inserción de reglas</a></b></em>.
 Cada habitación puede estar asociada a más tarifas.<br><br></li>
<li>Si este servidor web es público se puede habilitar el login y crear nuevos usuarios desde la
 <em><b><a href="./gestione_utenti.php?<sessione>">página de gestión de usuarios</a></b></em>.<br><br></li>
<li>Ir a la página
 "<em><b><a href="./personalizza.php?<sessione>">configurar y personalizar</a></b></em>"
 para cambiar el nombre de la divisa, habilitar el registro de entradas, insertar los métodos de pago, y configurar muchas otras opciones.<br><br></li>
</ul></div></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp>2025-10-26 08:40:30</cmp></riga>
</righetabella>
</tabella>
<tabella>
<nometabella>prenota2025</nometabella>
<colonnetabella>
<nomecolonna>idprenota</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>idclienti</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>idappartamenti</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>iddatainizio</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>iddatafine</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>assegnazioneapp</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>app_assegnabili</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>num_persone</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>cat_persone</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>idprenota_compagna</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>tariffa</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>tariffesettimanali</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>incompatibilita</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>sconto</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>tariffa_tot</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>caparra</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>commissioni</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>tasseperc</nomecolonna>
<tipocolonna>4</tipocolonna>
<nomecolonna>pagato</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>valuta</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>metodo_pagamento</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>codice</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>origine</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>commento</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>conferma</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>checkin</nomecolonna>
<tipocolonna>12</tipocolonna>
<nomecolonna>checkout</nomecolonna>
<tipocolonna>12</tipocolonna>
<nomecolonna>id_anni_prec</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>datainserimento</nomecolonna>
<tipocolonna>12</tipocolonna>
<nomecolonna>hostinserimento</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>data_modifica</nomecolonna>
<tipocolonna>12</tipocolonna>
<nomecolonna>utente_inserimento</nomecolonna>
<tipocolonna>3</tipocolonna>
</colonnetabella>
<righetabella>
</righetabella>
</tabella>
<tabella>
<nometabella>prenotacanc2025</nometabella>
<colonnetabella>
<nomecolonna>idprenota</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>idclienti</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>idappartamenti</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>iddatainizio</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>iddatafine</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>assegnazioneapp</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>app_assegnabili</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>num_persone</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>cat_persone</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>idprenota_compagna</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>tariffa</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>tariffesettimanali</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>incompatibilita</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>sconto</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>tariffa_tot</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>caparra</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>commissioni</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>tasseperc</nomecolonna>
<tipocolonna>4</tipocolonna>
<nomecolonna>pagato</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>valuta</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>metodo_pagamento</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>codice</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>origine</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>commento</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>conferma</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>checkin</nomecolonna>
<tipocolonna>12</tipocolonna>
<nomecolonna>checkout</nomecolonna>
<tipocolonna>12</tipocolonna>
<nomecolonna>id_anni_prec</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>datainserimento</nomecolonna>
<tipocolonna>12</tipocolonna>
<nomecolonna>hostinserimento</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>data_modifica</nomecolonna>
<tipocolonna>12</tipocolonna>
<nomecolonna>utente_inserimento</nomecolonna>
<tipocolonna>3</tipocolonna>
</colonnetabella>
<righetabella>
</righetabella>
</tabella>
<tabella>
<nometabella>costiprenota2025</nometabella>
<colonnetabella>
<nomecolonna>idcostiprenota</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>idprenota</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>tipo</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>nome</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>valore</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>valore_perc</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>arrotonda</nomecolonna>
<tipocolonna>4</tipocolonna>
<nomecolonna>tasseperc</nomecolonna>
<tipocolonna>4</tipocolonna>
<nomecolonna>associasett</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>settimane</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>moltiplica</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>categoria</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>letto</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>cat_persone</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>numlimite</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>idntariffe</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>variazione</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>varmoltiplica</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>varnumsett</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>varperiodipermessi</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>varbeniinv</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>varappincompatibili</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>vartariffeassociate</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>vartariffeincomp</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>datainserimento</nomecolonna>
<tipocolonna>12</tipocolonna>
<nomecolonna>hostinserimento</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>utente_inserimento</nomecolonna>
<tipocolonna>3</tipocolonna>
</colonnetabella>
<righetabella>
<riga><cmp>1</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp>1</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
</righetabella>
</tabella>
<tabella>
<nometabella>rclientiprenota2025</nometabella>
<colonnetabella>
<nomecolonna>idprenota</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>idclienti</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>num_ordine</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>parentela</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>datainserimento</nomecolonna>
<tipocolonna>12</tipocolonna>
<nomecolonna>hostinserimento</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>utente_inserimento</nomecolonna>
<tipocolonna>3</tipocolonna>
</colonnetabella>
<righetabella>
</righetabella>
</tabella>
<tabella>
<nometabella>periodi2025</nometabella>
<colonnetabella>
<nomecolonna>idperiodi</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>datainizio</nomecolonna>
<tipocolonna>10</tipocolonna>
<nomecolonna>datafine</nomecolonna>
<tipocolonna>10</tipocolonna>
<nomecolonna>tariffa1</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>tariffa1p</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>tariffa2</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>tariffa2p</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>tariffa3</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>tariffa3p</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>tariffa4</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>tariffa4p</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>tariffa5</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>tariffa5p</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>tariffa6</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>tariffa6p</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>tariffa7</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>tariffa7p</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>tariffa8</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>tariffa8p</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>tariffa9</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>tariffa9p</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>tariffa10</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>tariffa10p</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>tariffa11</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>tariffa11p</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>tariffa12</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>tariffa12p</nomecolonna>
<tipocolonna>5</tipocolonna>
</colonnetabella>
<righetabella>
<riga><cmp>1</cmp><cmp>2025-01-01</cmp><cmp>2025-01-02</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>2</cmp><cmp>2025-01-02</cmp><cmp>2025-01-03</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>3</cmp><cmp>2025-01-03</cmp><cmp>2025-01-04</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>4</cmp><cmp>2025-01-04</cmp><cmp>2025-01-05</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>5</cmp><cmp>2025-01-05</cmp><cmp>2025-01-06</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>6</cmp><cmp>2025-01-06</cmp><cmp>2025-01-07</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>7</cmp><cmp>2025-01-07</cmp><cmp>2025-01-08</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>8</cmp><cmp>2025-01-08</cmp><cmp>2025-01-09</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>9</cmp><cmp>2025-01-09</cmp><cmp>2025-01-10</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>10</cmp><cmp>2025-01-10</cmp><cmp>2025-01-11</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>11</cmp><cmp>2025-01-11</cmp><cmp>2025-01-12</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>12</cmp><cmp>2025-01-12</cmp><cmp>2025-01-13</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>13</cmp><cmp>2025-01-13</cmp><cmp>2025-01-14</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>14</cmp><cmp>2025-01-14</cmp><cmp>2025-01-15</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>15</cmp><cmp>2025-01-15</cmp><cmp>2025-01-16</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>16</cmp><cmp>2025-01-16</cmp><cmp>2025-01-17</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>17</cmp><cmp>2025-01-17</cmp><cmp>2025-01-18</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>18</cmp><cmp>2025-01-18</cmp><cmp>2025-01-19</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>19</cmp><cmp>2025-01-19</cmp><cmp>2025-01-20</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>20</cmp><cmp>2025-01-20</cmp><cmp>2025-01-21</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>21</cmp><cmp>2025-01-21</cmp><cmp>2025-01-22</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>22</cmp><cmp>2025-01-22</cmp><cmp>2025-01-23</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>23</cmp><cmp>2025-01-23</cmp><cmp>2025-01-24</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>24</cmp><cmp>2025-01-24</cmp><cmp>2025-01-25</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>25</cmp><cmp>2025-01-25</cmp><cmp>2025-01-26</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>26</cmp><cmp>2025-01-26</cmp><cmp>2025-01-27</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>27</cmp><cmp>2025-01-27</cmp><cmp>2025-01-28</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>28</cmp><cmp>2025-01-28</cmp><cmp>2025-01-29</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>29</cmp><cmp>2025-01-29</cmp><cmp>2025-01-30</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>30</cmp><cmp>2025-01-30</cmp><cmp>2025-01-31</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>31</cmp><cmp>2025-01-31</cmp><cmp>2025-02-01</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>32</cmp><cmp>2025-02-01</cmp><cmp>2025-02-02</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>33</cmp><cmp>2025-02-02</cmp><cmp>2025-02-03</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>34</cmp><cmp>2025-02-03</cmp><cmp>2025-02-04</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>35</cmp><cmp>2025-02-04</cmp><cmp>2025-02-05</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>36</cmp><cmp>2025-02-05</cmp><cmp>2025-02-06</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>37</cmp><cmp>2025-02-06</cmp><cmp>2025-02-07</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>38</cmp><cmp>2025-02-07</cmp><cmp>2025-02-08</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>39</cmp><cmp>2025-02-08</cmp><cmp>2025-02-09</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>40</cmp><cmp>2025-02-09</cmp><cmp>2025-02-10</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>41</cmp><cmp>2025-02-10</cmp><cmp>2025-02-11</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>42</cmp><cmp>2025-02-11</cmp><cmp>2025-02-12</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>43</cmp><cmp>2025-02-12</cmp><cmp>2025-02-13</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>44</cmp><cmp>2025-02-13</cmp><cmp>2025-02-14</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>45</cmp><cmp>2025-02-14</cmp><cmp>2025-02-15</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>46</cmp><cmp>2025-02-15</cmp><cmp>2025-02-16</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>47</cmp><cmp>2025-02-16</cmp><cmp>2025-02-17</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>48</cmp><cmp>2025-02-17</cmp><cmp>2025-02-18</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>49</cmp><cmp>2025-02-18</cmp><cmp>2025-02-19</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>50</cmp><cmp>2025-02-19</cmp><cmp>2025-02-20</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>51</cmp><cmp>2025-02-20</cmp><cmp>2025-02-21</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>52</cmp><cmp>2025-02-21</cmp><cmp>2025-02-22</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>53</cmp><cmp>2025-02-22</cmp><cmp>2025-02-23</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>54</cmp><cmp>2025-02-23</cmp><cmp>2025-02-24</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>55</cmp><cmp>2025-02-24</cmp><cmp>2025-02-25</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>56</cmp><cmp>2025-02-25</cmp><cmp>2025-02-26</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>57</cmp><cmp>2025-02-26</cmp><cmp>2025-02-27</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>58</cmp><cmp>2025-02-27</cmp><cmp>2025-02-28</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>59</cmp><cmp>2025-02-28</cmp><cmp>2025-03-01</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>60</cmp><cmp>2025-03-01</cmp><cmp>2025-03-02</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>61</cmp><cmp>2025-03-02</cmp><cmp>2025-03-03</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>62</cmp><cmp>2025-03-03</cmp><cmp>2025-03-04</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>63</cmp><cmp>2025-03-04</cmp><cmp>2025-03-05</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>64</cmp><cmp>2025-03-05</cmp><cmp>2025-03-06</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>65</cmp><cmp>2025-03-06</cmp><cmp>2025-03-07</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>66</cmp><cmp>2025-03-07</cmp><cmp>2025-03-08</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>67</cmp><cmp>2025-03-08</cmp><cmp>2025-03-09</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>68</cmp><cmp>2025-03-09</cmp><cmp>2025-03-10</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>69</cmp><cmp>2025-03-10</cmp><cmp>2025-03-11</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>70</cmp><cmp>2025-03-11</cmp><cmp>2025-03-12</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>71</cmp><cmp>2025-03-12</cmp><cmp>2025-03-13</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>72</cmp><cmp>2025-03-13</cmp><cmp>2025-03-14</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>73</cmp><cmp>2025-03-14</cmp><cmp>2025-03-15</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>74</cmp><cmp>2025-03-15</cmp><cmp>2025-03-16</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>75</cmp><cmp>2025-03-16</cmp><cmp>2025-03-17</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>76</cmp><cmp>2025-03-17</cmp><cmp>2025-03-18</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>77</cmp><cmp>2025-03-18</cmp><cmp>2025-03-19</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>78</cmp><cmp>2025-03-19</cmp><cmp>2025-03-20</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>79</cmp><cmp>2025-03-20</cmp><cmp>2025-03-21</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>80</cmp><cmp>2025-03-21</cmp><cmp>2025-03-22</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>81</cmp><cmp>2025-03-22</cmp><cmp>2025-03-23</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>82</cmp><cmp>2025-03-23</cmp><cmp>2025-03-24</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>83</cmp><cmp>2025-03-24</cmp><cmp>2025-03-25</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>84</cmp><cmp>2025-03-25</cmp><cmp>2025-03-26</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>85</cmp><cmp>2025-03-26</cmp><cmp>2025-03-27</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>86</cmp><cmp>2025-03-27</cmp><cmp>2025-03-28</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>87</cmp><cmp>2025-03-28</cmp><cmp>2025-03-29</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>88</cmp><cmp>2025-03-29</cmp><cmp>2025-03-30</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>89</cmp><cmp>2025-03-30</cmp><cmp>2025-03-31</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>90</cmp><cmp>2025-03-31</cmp><cmp>2025-04-01</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>91</cmp><cmp>2025-04-01</cmp><cmp>2025-04-02</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>92</cmp><cmp>2025-04-02</cmp><cmp>2025-04-03</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>93</cmp><cmp>2025-04-03</cmp><cmp>2025-04-04</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>94</cmp><cmp>2025-04-04</cmp><cmp>2025-04-05</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>95</cmp><cmp>2025-04-05</cmp><cmp>2025-04-06</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>96</cmp><cmp>2025-04-06</cmp><cmp>2025-04-07</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>97</cmp><cmp>2025-04-07</cmp><cmp>2025-04-08</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>98</cmp><cmp>2025-04-08</cmp><cmp>2025-04-09</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>99</cmp><cmp>2025-04-09</cmp><cmp>2025-04-10</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>100</cmp><cmp>2025-04-10</cmp><cmp>2025-04-11</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>101</cmp><cmp>2025-04-11</cmp><cmp>2025-04-12</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>102</cmp><cmp>2025-04-12</cmp><cmp>2025-04-13</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>103</cmp><cmp>2025-04-13</cmp><cmp>2025-04-14</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>104</cmp><cmp>2025-04-14</cmp><cmp>2025-04-15</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>105</cmp><cmp>2025-04-15</cmp><cmp>2025-04-16</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>106</cmp><cmp>2025-04-16</cmp><cmp>2025-04-17</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>107</cmp><cmp>2025-04-17</cmp><cmp>2025-04-18</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>108</cmp><cmp>2025-04-18</cmp><cmp>2025-04-19</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>109</cmp><cmp>2025-04-19</cmp><cmp>2025-04-20</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>110</cmp><cmp>2025-04-20</cmp><cmp>2025-04-21</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>111</cmp><cmp>2025-04-21</cmp><cmp>2025-04-22</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>112</cmp><cmp>2025-04-22</cmp><cmp>2025-04-23</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>113</cmp><cmp>2025-04-23</cmp><cmp>2025-04-24</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>114</cmp><cmp>2025-04-24</cmp><cmp>2025-04-25</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>115</cmp><cmp>2025-04-25</cmp><cmp>2025-04-26</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>116</cmp><cmp>2025-04-26</cmp><cmp>2025-04-27</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>117</cmp><cmp>2025-04-27</cmp><cmp>2025-04-28</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>118</cmp><cmp>2025-04-28</cmp><cmp>2025-04-29</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>119</cmp><cmp>2025-04-29</cmp><cmp>2025-04-30</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>120</cmp><cmp>2025-04-30</cmp><cmp>2025-05-01</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>121</cmp><cmp>2025-05-01</cmp><cmp>2025-05-02</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>122</cmp><cmp>2025-05-02</cmp><cmp>2025-05-03</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>123</cmp><cmp>2025-05-03</cmp><cmp>2025-05-04</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>124</cmp><cmp>2025-05-04</cmp><cmp>2025-05-05</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>125</cmp><cmp>2025-05-05</cmp><cmp>2025-05-06</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>126</cmp><cmp>2025-05-06</cmp><cmp>2025-05-07</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>127</cmp><cmp>2025-05-07</cmp><cmp>2025-05-08</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>128</cmp><cmp>2025-05-08</cmp><cmp>2025-05-09</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>129</cmp><cmp>2025-05-09</cmp><cmp>2025-05-10</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>130</cmp><cmp>2025-05-10</cmp><cmp>2025-05-11</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>131</cmp><cmp>2025-05-11</cmp><cmp>2025-05-12</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>132</cmp><cmp>2025-05-12</cmp><cmp>2025-05-13</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>133</cmp><cmp>2025-05-13</cmp><cmp>2025-05-14</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>134</cmp><cmp>2025-05-14</cmp><cmp>2025-05-15</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>135</cmp><cmp>2025-05-15</cmp><cmp>2025-05-16</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>136</cmp><cmp>2025-05-16</cmp><cmp>2025-05-17</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>137</cmp><cmp>2025-05-17</cmp><cmp>2025-05-18</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>138</cmp><cmp>2025-05-18</cmp><cmp>2025-05-19</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>139</cmp><cmp>2025-05-19</cmp><cmp>2025-05-20</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>140</cmp><cmp>2025-05-20</cmp><cmp>2025-05-21</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>141</cmp><cmp>2025-05-21</cmp><cmp>2025-05-22</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>142</cmp><cmp>2025-05-22</cmp><cmp>2025-05-23</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>143</cmp><cmp>2025-05-23</cmp><cmp>2025-05-24</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>144</cmp><cmp>2025-05-24</cmp><cmp>2025-05-25</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>145</cmp><cmp>2025-05-25</cmp><cmp>2025-05-26</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>146</cmp><cmp>2025-05-26</cmp><cmp>2025-05-27</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>147</cmp><cmp>2025-05-27</cmp><cmp>2025-05-28</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>148</cmp><cmp>2025-05-28</cmp><cmp>2025-05-29</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>149</cmp><cmp>2025-05-29</cmp><cmp>2025-05-30</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>150</cmp><cmp>2025-05-30</cmp><cmp>2025-05-31</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>151</cmp><cmp>2025-05-31</cmp><cmp>2025-06-01</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>152</cmp><cmp>2025-06-01</cmp><cmp>2025-06-02</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>153</cmp><cmp>2025-06-02</cmp><cmp>2025-06-03</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>154</cmp><cmp>2025-06-03</cmp><cmp>2025-06-04</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>155</cmp><cmp>2025-06-04</cmp><cmp>2025-06-05</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>156</cmp><cmp>2025-06-05</cmp><cmp>2025-06-06</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>157</cmp><cmp>2025-06-06</cmp><cmp>2025-06-07</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>158</cmp><cmp>2025-06-07</cmp><cmp>2025-06-08</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>159</cmp><cmp>2025-06-08</cmp><cmp>2025-06-09</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>160</cmp><cmp>2025-06-09</cmp><cmp>2025-06-10</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>161</cmp><cmp>2025-06-10</cmp><cmp>2025-06-11</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>162</cmp><cmp>2025-06-11</cmp><cmp>2025-06-12</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>163</cmp><cmp>2025-06-12</cmp><cmp>2025-06-13</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>164</cmp><cmp>2025-06-13</cmp><cmp>2025-06-14</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>165</cmp><cmp>2025-06-14</cmp><cmp>2025-06-15</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>166</cmp><cmp>2025-06-15</cmp><cmp>2025-06-16</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>167</cmp><cmp>2025-06-16</cmp><cmp>2025-06-17</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>168</cmp><cmp>2025-06-17</cmp><cmp>2025-06-18</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>169</cmp><cmp>2025-06-18</cmp><cmp>2025-06-19</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>170</cmp><cmp>2025-06-19</cmp><cmp>2025-06-20</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>171</cmp><cmp>2025-06-20</cmp><cmp>2025-06-21</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>172</cmp><cmp>2025-06-21</cmp><cmp>2025-06-22</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>173</cmp><cmp>2025-06-22</cmp><cmp>2025-06-23</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>174</cmp><cmp>2025-06-23</cmp><cmp>2025-06-24</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>175</cmp><cmp>2025-06-24</cmp><cmp>2025-06-25</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>176</cmp><cmp>2025-06-25</cmp><cmp>2025-06-26</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>177</cmp><cmp>2025-06-26</cmp><cmp>2025-06-27</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>178</cmp><cmp>2025-06-27</cmp><cmp>2025-06-28</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>179</cmp><cmp>2025-06-28</cmp><cmp>2025-06-29</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>180</cmp><cmp>2025-06-29</cmp><cmp>2025-06-30</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>181</cmp><cmp>2025-06-30</cmp><cmp>2025-07-01</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>182</cmp><cmp>2025-07-01</cmp><cmp>2025-07-02</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>183</cmp><cmp>2025-07-02</cmp><cmp>2025-07-03</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>184</cmp><cmp>2025-07-03</cmp><cmp>2025-07-04</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>185</cmp><cmp>2025-07-04</cmp><cmp>2025-07-05</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>186</cmp><cmp>2025-07-05</cmp><cmp>2025-07-06</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>187</cmp><cmp>2025-07-06</cmp><cmp>2025-07-07</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>188</cmp><cmp>2025-07-07</cmp><cmp>2025-07-08</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>189</cmp><cmp>2025-07-08</cmp><cmp>2025-07-09</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>190</cmp><cmp>2025-07-09</cmp><cmp>2025-07-10</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>191</cmp><cmp>2025-07-10</cmp><cmp>2025-07-11</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>192</cmp><cmp>2025-07-11</cmp><cmp>2025-07-12</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>193</cmp><cmp>2025-07-12</cmp><cmp>2025-07-13</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>194</cmp><cmp>2025-07-13</cmp><cmp>2025-07-14</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>195</cmp><cmp>2025-07-14</cmp><cmp>2025-07-15</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>196</cmp><cmp>2025-07-15</cmp><cmp>2025-07-16</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>197</cmp><cmp>2025-07-16</cmp><cmp>2025-07-17</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>198</cmp><cmp>2025-07-17</cmp><cmp>2025-07-18</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>199</cmp><cmp>2025-07-18</cmp><cmp>2025-07-19</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>200</cmp><cmp>2025-07-19</cmp><cmp>2025-07-20</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>201</cmp><cmp>2025-07-20</cmp><cmp>2025-07-21</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>202</cmp><cmp>2025-07-21</cmp><cmp>2025-07-22</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>203</cmp><cmp>2025-07-22</cmp><cmp>2025-07-23</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>204</cmp><cmp>2025-07-23</cmp><cmp>2025-07-24</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>205</cmp><cmp>2025-07-24</cmp><cmp>2025-07-25</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>206</cmp><cmp>2025-07-25</cmp><cmp>2025-07-26</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>207</cmp><cmp>2025-07-26</cmp><cmp>2025-07-27</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>208</cmp><cmp>2025-07-27</cmp><cmp>2025-07-28</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>209</cmp><cmp>2025-07-28</cmp><cmp>2025-07-29</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>210</cmp><cmp>2025-07-29</cmp><cmp>2025-07-30</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>211</cmp><cmp>2025-07-30</cmp><cmp>2025-07-31</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>212</cmp><cmp>2025-07-31</cmp><cmp>2025-08-01</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>213</cmp><cmp>2025-08-01</cmp><cmp>2025-08-02</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>214</cmp><cmp>2025-08-02</cmp><cmp>2025-08-03</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>215</cmp><cmp>2025-08-03</cmp><cmp>2025-08-04</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>216</cmp><cmp>2025-08-04</cmp><cmp>2025-08-05</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>217</cmp><cmp>2025-08-05</cmp><cmp>2025-08-06</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>218</cmp><cmp>2025-08-06</cmp><cmp>2025-08-07</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>219</cmp><cmp>2025-08-07</cmp><cmp>2025-08-08</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>220</cmp><cmp>2025-08-08</cmp><cmp>2025-08-09</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>221</cmp><cmp>2025-08-09</cmp><cmp>2025-08-10</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>222</cmp><cmp>2025-08-10</cmp><cmp>2025-08-11</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>223</cmp><cmp>2025-08-11</cmp><cmp>2025-08-12</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>224</cmp><cmp>2025-08-12</cmp><cmp>2025-08-13</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>225</cmp><cmp>2025-08-13</cmp><cmp>2025-08-14</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>226</cmp><cmp>2025-08-14</cmp><cmp>2025-08-15</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>227</cmp><cmp>2025-08-15</cmp><cmp>2025-08-16</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>228</cmp><cmp>2025-08-16</cmp><cmp>2025-08-17</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>229</cmp><cmp>2025-08-17</cmp><cmp>2025-08-18</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>230</cmp><cmp>2025-08-18</cmp><cmp>2025-08-19</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>231</cmp><cmp>2025-08-19</cmp><cmp>2025-08-20</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>232</cmp><cmp>2025-08-20</cmp><cmp>2025-08-21</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>233</cmp><cmp>2025-08-21</cmp><cmp>2025-08-22</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>234</cmp><cmp>2025-08-22</cmp><cmp>2025-08-23</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>235</cmp><cmp>2025-08-23</cmp><cmp>2025-08-24</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>236</cmp><cmp>2025-08-24</cmp><cmp>2025-08-25</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>237</cmp><cmp>2025-08-25</cmp><cmp>2025-08-26</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>238</cmp><cmp>2025-08-26</cmp><cmp>2025-08-27</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>239</cmp><cmp>2025-08-27</cmp><cmp>2025-08-28</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>240</cmp><cmp>2025-08-28</cmp><cmp>2025-08-29</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>241</cmp><cmp>2025-08-29</cmp><cmp>2025-08-30</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>242</cmp><cmp>2025-08-30</cmp><cmp>2025-08-31</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>243</cmp><cmp>2025-08-31</cmp><cmp>2025-09-01</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>244</cmp><cmp>2025-09-01</cmp><cmp>2025-09-02</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>245</cmp><cmp>2025-09-02</cmp><cmp>2025-09-03</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>246</cmp><cmp>2025-09-03</cmp><cmp>2025-09-04</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>247</cmp><cmp>2025-09-04</cmp><cmp>2025-09-05</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>248</cmp><cmp>2025-09-05</cmp><cmp>2025-09-06</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>249</cmp><cmp>2025-09-06</cmp><cmp>2025-09-07</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>250</cmp><cmp>2025-09-07</cmp><cmp>2025-09-08</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>251</cmp><cmp>2025-09-08</cmp><cmp>2025-09-09</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>252</cmp><cmp>2025-09-09</cmp><cmp>2025-09-10</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>253</cmp><cmp>2025-09-10</cmp><cmp>2025-09-11</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>254</cmp><cmp>2025-09-11</cmp><cmp>2025-09-12</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>255</cmp><cmp>2025-09-12</cmp><cmp>2025-09-13</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>256</cmp><cmp>2025-09-13</cmp><cmp>2025-09-14</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>257</cmp><cmp>2025-09-14</cmp><cmp>2025-09-15</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>258</cmp><cmp>2025-09-15</cmp><cmp>2025-09-16</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>259</cmp><cmp>2025-09-16</cmp><cmp>2025-09-17</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>260</cmp><cmp>2025-09-17</cmp><cmp>2025-09-18</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>261</cmp><cmp>2025-09-18</cmp><cmp>2025-09-19</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>262</cmp><cmp>2025-09-19</cmp><cmp>2025-09-20</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>263</cmp><cmp>2025-09-20</cmp><cmp>2025-09-21</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>264</cmp><cmp>2025-09-21</cmp><cmp>2025-09-22</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>265</cmp><cmp>2025-09-22</cmp><cmp>2025-09-23</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>266</cmp><cmp>2025-09-23</cmp><cmp>2025-09-24</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>267</cmp><cmp>2025-09-24</cmp><cmp>2025-09-25</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>268</cmp><cmp>2025-09-25</cmp><cmp>2025-09-26</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>269</cmp><cmp>2025-09-26</cmp><cmp>2025-09-27</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>270</cmp><cmp>2025-09-27</cmp><cmp>2025-09-28</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>271</cmp><cmp>2025-09-28</cmp><cmp>2025-09-29</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>272</cmp><cmp>2025-09-29</cmp><cmp>2025-09-30</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>273</cmp><cmp>2025-09-30</cmp><cmp>2025-10-01</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>274</cmp><cmp>2025-10-01</cmp><cmp>2025-10-02</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>275</cmp><cmp>2025-10-02</cmp><cmp>2025-10-03</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>276</cmp><cmp>2025-10-03</cmp><cmp>2025-10-04</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>277</cmp><cmp>2025-10-04</cmp><cmp>2025-10-05</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>278</cmp><cmp>2025-10-05</cmp><cmp>2025-10-06</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>279</cmp><cmp>2025-10-06</cmp><cmp>2025-10-07</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>280</cmp><cmp>2025-10-07</cmp><cmp>2025-10-08</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>281</cmp><cmp>2025-10-08</cmp><cmp>2025-10-09</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>282</cmp><cmp>2025-10-09</cmp><cmp>2025-10-10</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>283</cmp><cmp>2025-10-10</cmp><cmp>2025-10-11</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>284</cmp><cmp>2025-10-11</cmp><cmp>2025-10-12</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>285</cmp><cmp>2025-10-12</cmp><cmp>2025-10-13</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>286</cmp><cmp>2025-10-13</cmp><cmp>2025-10-14</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>287</cmp><cmp>2025-10-14</cmp><cmp>2025-10-15</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>288</cmp><cmp>2025-10-15</cmp><cmp>2025-10-16</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>289</cmp><cmp>2025-10-16</cmp><cmp>2025-10-17</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>290</cmp><cmp>2025-10-17</cmp><cmp>2025-10-18</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>291</cmp><cmp>2025-10-18</cmp><cmp>2025-10-19</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>292</cmp><cmp>2025-10-19</cmp><cmp>2025-10-20</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>293</cmp><cmp>2025-10-20</cmp><cmp>2025-10-21</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>294</cmp><cmp>2025-10-21</cmp><cmp>2025-10-22</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>295</cmp><cmp>2025-10-22</cmp><cmp>2025-10-23</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>296</cmp><cmp>2025-10-23</cmp><cmp>2025-10-24</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>297</cmp><cmp>2025-10-24</cmp><cmp>2025-10-25</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>298</cmp><cmp>2025-10-25</cmp><cmp>2025-10-26</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>299</cmp><cmp>2025-10-26</cmp><cmp>2025-10-27</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>300</cmp><cmp>2025-10-27</cmp><cmp>2025-10-28</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>301</cmp><cmp>2025-10-28</cmp><cmp>2025-10-29</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>302</cmp><cmp>2025-10-29</cmp><cmp>2025-10-30</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>303</cmp><cmp>2025-10-30</cmp><cmp>2025-10-31</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>304</cmp><cmp>2025-10-31</cmp><cmp>2025-11-01</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>305</cmp><cmp>2025-11-01</cmp><cmp>2025-11-02</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>306</cmp><cmp>2025-11-02</cmp><cmp>2025-11-03</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>307</cmp><cmp>2025-11-03</cmp><cmp>2025-11-04</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>308</cmp><cmp>2025-11-04</cmp><cmp>2025-11-05</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>309</cmp><cmp>2025-11-05</cmp><cmp>2025-11-06</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>310</cmp><cmp>2025-11-06</cmp><cmp>2025-11-07</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>311</cmp><cmp>2025-11-07</cmp><cmp>2025-11-08</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>312</cmp><cmp>2025-11-08</cmp><cmp>2025-11-09</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>313</cmp><cmp>2025-11-09</cmp><cmp>2025-11-10</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>314</cmp><cmp>2025-11-10</cmp><cmp>2025-11-11</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>315</cmp><cmp>2025-11-11</cmp><cmp>2025-11-12</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>316</cmp><cmp>2025-11-12</cmp><cmp>2025-11-13</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>317</cmp><cmp>2025-11-13</cmp><cmp>2025-11-14</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>318</cmp><cmp>2025-11-14</cmp><cmp>2025-11-15</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>319</cmp><cmp>2025-11-15</cmp><cmp>2025-11-16</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>320</cmp><cmp>2025-11-16</cmp><cmp>2025-11-17</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>321</cmp><cmp>2025-11-17</cmp><cmp>2025-11-18</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>322</cmp><cmp>2025-11-18</cmp><cmp>2025-11-19</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>323</cmp><cmp>2025-11-19</cmp><cmp>2025-11-20</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>324</cmp><cmp>2025-11-20</cmp><cmp>2025-11-21</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>325</cmp><cmp>2025-11-21</cmp><cmp>2025-11-22</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>326</cmp><cmp>2025-11-22</cmp><cmp>2025-11-23</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>327</cmp><cmp>2025-11-23</cmp><cmp>2025-11-24</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>328</cmp><cmp>2025-11-24</cmp><cmp>2025-11-25</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>329</cmp><cmp>2025-11-25</cmp><cmp>2025-11-26</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>330</cmp><cmp>2025-11-26</cmp><cmp>2025-11-27</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>331</cmp><cmp>2025-11-27</cmp><cmp>2025-11-28</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>332</cmp><cmp>2025-11-28</cmp><cmp>2025-11-29</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>333</cmp><cmp>2025-11-29</cmp><cmp>2025-11-30</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>334</cmp><cmp>2025-11-30</cmp><cmp>2025-12-01</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>335</cmp><cmp>2025-12-01</cmp><cmp>2025-12-02</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>336</cmp><cmp>2025-12-02</cmp><cmp>2025-12-03</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>337</cmp><cmp>2025-12-03</cmp><cmp>2025-12-04</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>338</cmp><cmp>2025-12-04</cmp><cmp>2025-12-05</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>339</cmp><cmp>2025-12-05</cmp><cmp>2025-12-06</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>340</cmp><cmp>2025-12-06</cmp><cmp>2025-12-07</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>341</cmp><cmp>2025-12-07</cmp><cmp>2025-12-08</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>342</cmp><cmp>2025-12-08</cmp><cmp>2025-12-09</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>343</cmp><cmp>2025-12-09</cmp><cmp>2025-12-10</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>344</cmp><cmp>2025-12-10</cmp><cmp>2025-12-11</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>345</cmp><cmp>2025-12-11</cmp><cmp>2025-12-12</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>346</cmp><cmp>2025-12-12</cmp><cmp>2025-12-13</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>347</cmp><cmp>2025-12-13</cmp><cmp>2025-12-14</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>348</cmp><cmp>2025-12-14</cmp><cmp>2025-12-15</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>349</cmp><cmp>2025-12-15</cmp><cmp>2025-12-16</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>350</cmp><cmp>2025-12-16</cmp><cmp>2025-12-17</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>351</cmp><cmp>2025-12-17</cmp><cmp>2025-12-18</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>352</cmp><cmp>2025-12-18</cmp><cmp>2025-12-19</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>353</cmp><cmp>2025-12-19</cmp><cmp>2025-12-20</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>354</cmp><cmp>2025-12-20</cmp><cmp>2025-12-21</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>355</cmp><cmp>2025-12-21</cmp><cmp>2025-12-22</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>356</cmp><cmp>2025-12-22</cmp><cmp>2025-12-23</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>357</cmp><cmp>2025-12-23</cmp><cmp>2025-12-24</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>358</cmp><cmp>2025-12-24</cmp><cmp>2025-12-25</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>359</cmp><cmp>2025-12-25</cmp><cmp>2025-12-26</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>360</cmp><cmp>2025-12-26</cmp><cmp>2025-12-27</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>361</cmp><cmp>2025-12-27</cmp><cmp>2025-12-28</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>362</cmp><cmp>2025-12-28</cmp><cmp>2025-12-29</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>363</cmp><cmp>2025-12-29</cmp><cmp>2025-12-30</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>364</cmp><cmp>2025-12-30</cmp><cmp>2025-12-31</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>365</cmp><cmp>2025-12-31</cmp><cmp>2026-01-01</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>366</cmp><cmp>2026-01-01</cmp><cmp>2026-01-02</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>367</cmp><cmp>2026-01-02</cmp><cmp>2026-01-03</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>368</cmp><cmp>2026-01-03</cmp><cmp>2026-01-04</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>369</cmp><cmp>2026-01-04</cmp><cmp>2026-01-05</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>370</cmp><cmp>2026-01-05</cmp><cmp>2026-01-06</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>371</cmp><cmp>2026-01-06</cmp><cmp>2026-01-07</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>372</cmp><cmp>2026-01-07</cmp><cmp>2026-01-08</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>373</cmp><cmp>2026-01-08</cmp><cmp>2026-01-09</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>374</cmp><cmp>2026-01-09</cmp><cmp>2026-01-10</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>375</cmp><cmp>2026-01-10</cmp><cmp>2026-01-11</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>376</cmp><cmp>2026-01-11</cmp><cmp>2026-01-12</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>377</cmp><cmp>2026-01-12</cmp><cmp>2026-01-13</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>378</cmp><cmp>2026-01-13</cmp><cmp>2026-01-14</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>379</cmp><cmp>2026-01-14</cmp><cmp>2026-01-15</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>380</cmp><cmp>2026-01-15</cmp><cmp>2026-01-16</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>381</cmp><cmp>2026-01-16</cmp><cmp>2026-01-17</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>382</cmp><cmp>2026-01-17</cmp><cmp>2026-01-18</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>383</cmp><cmp>2026-01-18</cmp><cmp>2026-01-19</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>384</cmp><cmp>2026-01-19</cmp><cmp>2026-01-20</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>385</cmp><cmp>2026-01-20</cmp><cmp>2026-01-21</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>386</cmp><cmp>2026-01-21</cmp><cmp>2026-01-22</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>387</cmp><cmp>2026-01-22</cmp><cmp>2026-01-23</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>388</cmp><cmp>2026-01-23</cmp><cmp>2026-01-24</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>389</cmp><cmp>2026-01-24</cmp><cmp>2026-01-25</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>390</cmp><cmp>2026-01-25</cmp><cmp>2026-01-26</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>391</cmp><cmp>2026-01-26</cmp><cmp>2026-01-27</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>392</cmp><cmp>2026-01-27</cmp><cmp>2026-01-28</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>393</cmp><cmp>2026-01-28</cmp><cmp>2026-01-29</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>394</cmp><cmp>2026-01-29</cmp><cmp>2026-01-30</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>395</cmp><cmp>2026-01-30</cmp><cmp>2026-01-31</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>396</cmp><cmp>2026-01-31</cmp><cmp>2026-02-01</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>397</cmp><cmp>2026-02-01</cmp><cmp>2026-02-02</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>398</cmp><cmp>2026-02-02</cmp><cmp>2026-02-03</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>399</cmp><cmp>2026-02-03</cmp><cmp>2026-02-04</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>400</cmp><cmp>2026-02-04</cmp><cmp>2026-02-05</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>401</cmp><cmp>2026-02-05</cmp><cmp>2026-02-06</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>402</cmp><cmp>2026-02-06</cmp><cmp>2026-02-07</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>403</cmp><cmp>2026-02-07</cmp><cmp>2026-02-08</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>404</cmp><cmp>2026-02-08</cmp><cmp>2026-02-09</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>405</cmp><cmp>2026-02-09</cmp><cmp>2026-02-10</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>406</cmp><cmp>2026-02-10</cmp><cmp>2026-02-11</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>407</cmp><cmp>2026-02-11</cmp><cmp>2026-02-12</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>408</cmp><cmp>2026-02-12</cmp><cmp>2026-02-13</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>409</cmp><cmp>2026-02-13</cmp><cmp>2026-02-14</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>410</cmp><cmp>2026-02-14</cmp><cmp>2026-02-15</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>411</cmp><cmp>2026-02-15</cmp><cmp>2026-02-16</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>412</cmp><cmp>2026-02-16</cmp><cmp>2026-02-17</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>413</cmp><cmp>2026-02-17</cmp><cmp>2026-02-18</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>414</cmp><cmp>2026-02-18</cmp><cmp>2026-02-19</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>415</cmp><cmp>2026-02-19</cmp><cmp>2026-02-20</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>416</cmp><cmp>2026-02-20</cmp><cmp>2026-02-21</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>417</cmp><cmp>2026-02-21</cmp><cmp>2026-02-22</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>418</cmp><cmp>2026-02-22</cmp><cmp>2026-02-23</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>419</cmp><cmp>2026-02-23</cmp><cmp>2026-02-24</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>420</cmp><cmp>2026-02-24</cmp><cmp>2026-02-25</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>421</cmp><cmp>2026-02-25</cmp><cmp>2026-02-26</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>422</cmp><cmp>2026-02-26</cmp><cmp>2026-02-27</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>423</cmp><cmp>2026-02-27</cmp><cmp>2026-02-28</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>424</cmp><cmp>2026-02-28</cmp><cmp>2026-03-01</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>425</cmp><cmp>2026-03-01</cmp><cmp>2026-03-02</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>426</cmp><cmp>2026-03-02</cmp><cmp>2026-03-03</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>427</cmp><cmp>2026-03-03</cmp><cmp>2026-03-04</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>428</cmp><cmp>2026-03-04</cmp><cmp>2026-03-05</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>429</cmp><cmp>2026-03-05</cmp><cmp>2026-03-06</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>430</cmp><cmp>2026-03-06</cmp><cmp>2026-03-07</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>431</cmp><cmp>2026-03-07</cmp><cmp>2026-03-08</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>432</cmp><cmp>2026-03-08</cmp><cmp>2026-03-09</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>433</cmp><cmp>2026-03-09</cmp><cmp>2026-03-10</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>434</cmp><cmp>2026-03-10</cmp><cmp>2026-03-11</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>435</cmp><cmp>2026-03-11</cmp><cmp>2026-03-12</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>436</cmp><cmp>2026-03-12</cmp><cmp>2026-03-13</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>437</cmp><cmp>2026-03-13</cmp><cmp>2026-03-14</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>438</cmp><cmp>2026-03-14</cmp><cmp>2026-03-15</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>439</cmp><cmp>2026-03-15</cmp><cmp>2026-03-16</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>440</cmp><cmp>2026-03-16</cmp><cmp>2026-03-17</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>441</cmp><cmp>2026-03-17</cmp><cmp>2026-03-18</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>442</cmp><cmp>2026-03-18</cmp><cmp>2026-03-19</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>443</cmp><cmp>2026-03-19</cmp><cmp>2026-03-20</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>444</cmp><cmp>2026-03-20</cmp><cmp>2026-03-21</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>445</cmp><cmp>2026-03-21</cmp><cmp>2026-03-22</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>446</cmp><cmp>2026-03-22</cmp><cmp>2026-03-23</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>447</cmp><cmp>2026-03-23</cmp><cmp>2026-03-24</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>448</cmp><cmp>2026-03-24</cmp><cmp>2026-03-25</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>449</cmp><cmp>2026-03-25</cmp><cmp>2026-03-26</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>450</cmp><cmp>2026-03-26</cmp><cmp>2026-03-27</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>451</cmp><cmp>2026-03-27</cmp><cmp>2026-03-28</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>452</cmp><cmp>2026-03-28</cmp><cmp>2026-03-29</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>453</cmp><cmp>2026-03-29</cmp><cmp>2026-03-30</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>454</cmp><cmp>2026-03-30</cmp><cmp>2026-03-31</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>455</cmp><cmp>2026-03-31</cmp><cmp>2026-04-01</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>456</cmp><cmp>2026-04-01</cmp><cmp>2026-04-02</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>457</cmp><cmp>2026-04-02</cmp><cmp>2026-04-03</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>458</cmp><cmp>2026-04-03</cmp><cmp>2026-04-04</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>459</cmp><cmp>2026-04-04</cmp><cmp>2026-04-05</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>460</cmp><cmp>2026-04-05</cmp><cmp>2026-04-06</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>461</cmp><cmp>2026-04-06</cmp><cmp>2026-04-07</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>462</cmp><cmp>2026-04-07</cmp><cmp>2026-04-08</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>463</cmp><cmp>2026-04-08</cmp><cmp>2026-04-09</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>464</cmp><cmp>2026-04-09</cmp><cmp>2026-04-10</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>465</cmp><cmp>2026-04-10</cmp><cmp>2026-04-11</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>466</cmp><cmp>2026-04-11</cmp><cmp>2026-04-12</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>467</cmp><cmp>2026-04-12</cmp><cmp>2026-04-13</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>468</cmp><cmp>2026-04-13</cmp><cmp>2026-04-14</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>469</cmp><cmp>2026-04-14</cmp><cmp>2026-04-15</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>470</cmp><cmp>2026-04-15</cmp><cmp>2026-04-16</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>471</cmp><cmp>2026-04-16</cmp><cmp>2026-04-17</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>472</cmp><cmp>2026-04-17</cmp><cmp>2026-04-18</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>473</cmp><cmp>2026-04-18</cmp><cmp>2026-04-19</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>474</cmp><cmp>2026-04-19</cmp><cmp>2026-04-20</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>475</cmp><cmp>2026-04-20</cmp><cmp>2026-04-21</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>476</cmp><cmp>2026-04-21</cmp><cmp>2026-04-22</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>477</cmp><cmp>2026-04-22</cmp><cmp>2026-04-23</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>478</cmp><cmp>2026-04-23</cmp><cmp>2026-04-24</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>479</cmp><cmp>2026-04-24</cmp><cmp>2026-04-25</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>480</cmp><cmp>2026-04-25</cmp><cmp>2026-04-26</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>481</cmp><cmp>2026-04-26</cmp><cmp>2026-04-27</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>482</cmp><cmp>2026-04-27</cmp><cmp>2026-04-28</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>483</cmp><cmp>2026-04-28</cmp><cmp>2026-04-29</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>484</cmp><cmp>2026-04-29</cmp><cmp>2026-04-30</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>485</cmp><cmp>2026-04-30</cmp><cmp>2026-05-01</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>486</cmp><cmp>2026-05-01</cmp><cmp>2026-05-02</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>487</cmp><cmp>2026-05-02</cmp><cmp>2026-05-03</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>488</cmp><cmp>2026-05-03</cmp><cmp>2026-05-04</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>489</cmp><cmp>2026-05-04</cmp><cmp>2026-05-05</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>490</cmp><cmp>2026-05-05</cmp><cmp>2026-05-06</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>491</cmp><cmp>2026-05-06</cmp><cmp>2026-05-07</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>492</cmp><cmp>2026-05-07</cmp><cmp>2026-05-08</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>493</cmp><cmp>2026-05-08</cmp><cmp>2026-05-09</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>494</cmp><cmp>2026-05-09</cmp><cmp>2026-05-10</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>495</cmp><cmp>2026-05-10</cmp><cmp>2026-05-11</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>496</cmp><cmp>2026-05-11</cmp><cmp>2026-05-12</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>497</cmp><cmp>2026-05-12</cmp><cmp>2026-05-13</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>498</cmp><cmp>2026-05-13</cmp><cmp>2026-05-14</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>499</cmp><cmp>2026-05-14</cmp><cmp>2026-05-15</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>500</cmp><cmp>2026-05-15</cmp><cmp>2026-05-16</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>501</cmp><cmp>2026-05-16</cmp><cmp>2026-05-17</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>502</cmp><cmp>2026-05-17</cmp><cmp>2026-05-18</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>503</cmp><cmp>2026-05-18</cmp><cmp>2026-05-19</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>504</cmp><cmp>2026-05-19</cmp><cmp>2026-05-20</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>505</cmp><cmp>2026-05-20</cmp><cmp>2026-05-21</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>506</cmp><cmp>2026-05-21</cmp><cmp>2026-05-22</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>507</cmp><cmp>2026-05-22</cmp><cmp>2026-05-23</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>508</cmp><cmp>2026-05-23</cmp><cmp>2026-05-24</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>509</cmp><cmp>2026-05-24</cmp><cmp>2026-05-25</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>510</cmp><cmp>2026-05-25</cmp><cmp>2026-05-26</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>511</cmp><cmp>2026-05-26</cmp><cmp>2026-05-27</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>512</cmp><cmp>2026-05-27</cmp><cmp>2026-05-28</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>513</cmp><cmp>2026-05-28</cmp><cmp>2026-05-29</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>514</cmp><cmp>2026-05-29</cmp><cmp>2026-05-30</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>515</cmp><cmp>2026-05-30</cmp><cmp>2026-05-31</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>516</cmp><cmp>2026-05-31</cmp><cmp>2026-06-01</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>517</cmp><cmp>2026-06-01</cmp><cmp>2026-06-02</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>518</cmp><cmp>2026-06-02</cmp><cmp>2026-06-03</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>519</cmp><cmp>2026-06-03</cmp><cmp>2026-06-04</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>520</cmp><cmp>2026-06-04</cmp><cmp>2026-06-05</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>521</cmp><cmp>2026-06-05</cmp><cmp>2026-06-06</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>522</cmp><cmp>2026-06-06</cmp><cmp>2026-06-07</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>523</cmp><cmp>2026-06-07</cmp><cmp>2026-06-08</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>524</cmp><cmp>2026-06-08</cmp><cmp>2026-06-09</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>525</cmp><cmp>2026-06-09</cmp><cmp>2026-06-10</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>526</cmp><cmp>2026-06-10</cmp><cmp>2026-06-11</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>527</cmp><cmp>2026-06-11</cmp><cmp>2026-06-12</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>528</cmp><cmp>2026-06-12</cmp><cmp>2026-06-13</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>529</cmp><cmp>2026-06-13</cmp><cmp>2026-06-14</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>530</cmp><cmp>2026-06-14</cmp><cmp>2026-06-15</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>531</cmp><cmp>2026-06-15</cmp><cmp>2026-06-16</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>532</cmp><cmp>2026-06-16</cmp><cmp>2026-06-17</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>533</cmp><cmp>2026-06-17</cmp><cmp>2026-06-18</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>534</cmp><cmp>2026-06-18</cmp><cmp>2026-06-19</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>535</cmp><cmp>2026-06-19</cmp><cmp>2026-06-20</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>536</cmp><cmp>2026-06-20</cmp><cmp>2026-06-21</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>537</cmp><cmp>2026-06-21</cmp><cmp>2026-06-22</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>538</cmp><cmp>2026-06-22</cmp><cmp>2026-06-23</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>539</cmp><cmp>2026-06-23</cmp><cmp>2026-06-24</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>540</cmp><cmp>2026-06-24</cmp><cmp>2026-06-25</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>541</cmp><cmp>2026-06-25</cmp><cmp>2026-06-26</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>542</cmp><cmp>2026-06-26</cmp><cmp>2026-06-27</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>543</cmp><cmp>2026-06-27</cmp><cmp>2026-06-28</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>544</cmp><cmp>2026-06-28</cmp><cmp>2026-06-29</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>545</cmp><cmp>2026-06-29</cmp><cmp>2026-06-30</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>546</cmp><cmp>2026-06-30</cmp><cmp>2026-07-01</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>547</cmp><cmp>2026-07-01</cmp><cmp>2026-07-02</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>548</cmp><cmp>2026-07-02</cmp><cmp>2026-07-03</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>549</cmp><cmp>2026-07-03</cmp><cmp>2026-07-04</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>550</cmp><cmp>2026-07-04</cmp><cmp>2026-07-05</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>551</cmp><cmp>2026-07-05</cmp><cmp>2026-07-06</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>552</cmp><cmp>2026-07-06</cmp><cmp>2026-07-07</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>553</cmp><cmp>2026-07-07</cmp><cmp>2026-07-08</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>554</cmp><cmp>2026-07-08</cmp><cmp>2026-07-09</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>555</cmp><cmp>2026-07-09</cmp><cmp>2026-07-10</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>556</cmp><cmp>2026-07-10</cmp><cmp>2026-07-11</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>557</cmp><cmp>2026-07-11</cmp><cmp>2026-07-12</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>558</cmp><cmp>2026-07-12</cmp><cmp>2026-07-13</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>559</cmp><cmp>2026-07-13</cmp><cmp>2026-07-14</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>560</cmp><cmp>2026-07-14</cmp><cmp>2026-07-15</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>561</cmp><cmp>2026-07-15</cmp><cmp>2026-07-16</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>562</cmp><cmp>2026-07-16</cmp><cmp>2026-07-17</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>563</cmp><cmp>2026-07-17</cmp><cmp>2026-07-18</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>564</cmp><cmp>2026-07-18</cmp><cmp>2026-07-19</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>565</cmp><cmp>2026-07-19</cmp><cmp>2026-07-20</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>566</cmp><cmp>2026-07-20</cmp><cmp>2026-07-21</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>567</cmp><cmp>2026-07-21</cmp><cmp>2026-07-22</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>568</cmp><cmp>2026-07-22</cmp><cmp>2026-07-23</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>569</cmp><cmp>2026-07-23</cmp><cmp>2026-07-24</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>570</cmp><cmp>2026-07-24</cmp><cmp>2026-07-25</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>571</cmp><cmp>2026-07-25</cmp><cmp>2026-07-26</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>572</cmp><cmp>2026-07-26</cmp><cmp>2026-07-27</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>573</cmp><cmp>2026-07-27</cmp><cmp>2026-07-28</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>574</cmp><cmp>2026-07-28</cmp><cmp>2026-07-29</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>575</cmp><cmp>2026-07-29</cmp><cmp>2026-07-30</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>576</cmp><cmp>2026-07-30</cmp><cmp>2026-07-31</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>577</cmp><cmp>2026-07-31</cmp><cmp>2026-08-01</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>578</cmp><cmp>2026-08-01</cmp><cmp>2026-08-02</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>579</cmp><cmp>2026-08-02</cmp><cmp>2026-08-03</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>580</cmp><cmp>2026-08-03</cmp><cmp>2026-08-04</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>581</cmp><cmp>2026-08-04</cmp><cmp>2026-08-05</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>582</cmp><cmp>2026-08-05</cmp><cmp>2026-08-06</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>583</cmp><cmp>2026-08-06</cmp><cmp>2026-08-07</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>584</cmp><cmp>2026-08-07</cmp><cmp>2026-08-08</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>585</cmp><cmp>2026-08-08</cmp><cmp>2026-08-09</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>586</cmp><cmp>2026-08-09</cmp><cmp>2026-08-10</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>587</cmp><cmp>2026-08-10</cmp><cmp>2026-08-11</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>588</cmp><cmp>2026-08-11</cmp><cmp>2026-08-12</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>589</cmp><cmp>2026-08-12</cmp><cmp>2026-08-13</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>590</cmp><cmp>2026-08-13</cmp><cmp>2026-08-14</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>591</cmp><cmp>2026-08-14</cmp><cmp>2026-08-15</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>592</cmp><cmp>2026-08-15</cmp><cmp>2026-08-16</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>593</cmp><cmp>2026-08-16</cmp><cmp>2026-08-17</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>594</cmp><cmp>2026-08-17</cmp><cmp>2026-08-18</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>595</cmp><cmp>2026-08-18</cmp><cmp>2026-08-19</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>596</cmp><cmp>2026-08-19</cmp><cmp>2026-08-20</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>597</cmp><cmp>2026-08-20</cmp><cmp>2026-08-21</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>598</cmp><cmp>2026-08-21</cmp><cmp>2026-08-22</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>599</cmp><cmp>2026-08-22</cmp><cmp>2026-08-23</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>600</cmp><cmp>2026-08-23</cmp><cmp>2026-08-24</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>601</cmp><cmp>2026-08-24</cmp><cmp>2026-08-25</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>602</cmp><cmp>2026-08-25</cmp><cmp>2026-08-26</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>603</cmp><cmp>2026-08-26</cmp><cmp>2026-08-27</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>604</cmp><cmp>2026-08-27</cmp><cmp>2026-08-28</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>605</cmp><cmp>2026-08-28</cmp><cmp>2026-08-29</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>606</cmp><cmp>2026-08-29</cmp><cmp>2026-08-30</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>607</cmp><cmp>2026-08-30</cmp><cmp>2026-08-31</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>608</cmp><cmp>2026-08-31</cmp><cmp>2026-09-01</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>609</cmp><cmp>2026-09-01</cmp><cmp>2026-09-02</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>610</cmp><cmp>2026-09-02</cmp><cmp>2026-09-03</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>611</cmp><cmp>2026-09-03</cmp><cmp>2026-09-04</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>612</cmp><cmp>2026-09-04</cmp><cmp>2026-09-05</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>613</cmp><cmp>2026-09-05</cmp><cmp>2026-09-06</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>614</cmp><cmp>2026-09-06</cmp><cmp>2026-09-07</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>615</cmp><cmp>2026-09-07</cmp><cmp>2026-09-08</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>616</cmp><cmp>2026-09-08</cmp><cmp>2026-09-09</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>617</cmp><cmp>2026-09-09</cmp><cmp>2026-09-10</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>618</cmp><cmp>2026-09-10</cmp><cmp>2026-09-11</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>619</cmp><cmp>2026-09-11</cmp><cmp>2026-09-12</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>620</cmp><cmp>2026-09-12</cmp><cmp>2026-09-13</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>621</cmp><cmp>2026-09-13</cmp><cmp>2026-09-14</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>622</cmp><cmp>2026-09-14</cmp><cmp>2026-09-15</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>623</cmp><cmp>2026-09-15</cmp><cmp>2026-09-16</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>624</cmp><cmp>2026-09-16</cmp><cmp>2026-09-17</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>625</cmp><cmp>2026-09-17</cmp><cmp>2026-09-18</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>626</cmp><cmp>2026-09-18</cmp><cmp>2026-09-19</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>627</cmp><cmp>2026-09-19</cmp><cmp>2026-09-20</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>628</cmp><cmp>2026-09-20</cmp><cmp>2026-09-21</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>629</cmp><cmp>2026-09-21</cmp><cmp>2026-09-22</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>630</cmp><cmp>2026-09-22</cmp><cmp>2026-09-23</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>631</cmp><cmp>2026-09-23</cmp><cmp>2026-09-24</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>632</cmp><cmp>2026-09-24</cmp><cmp>2026-09-25</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>633</cmp><cmp>2026-09-25</cmp><cmp>2026-09-26</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>634</cmp><cmp>2026-09-26</cmp><cmp>2026-09-27</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>635</cmp><cmp>2026-09-27</cmp><cmp>2026-09-28</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>636</cmp><cmp>2026-09-28</cmp><cmp>2026-09-29</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>637</cmp><cmp>2026-09-29</cmp><cmp>2026-09-30</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>638</cmp><cmp>2026-09-30</cmp><cmp>2026-10-01</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>639</cmp><cmp>2026-10-01</cmp><cmp>2026-10-02</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>640</cmp><cmp>2026-10-02</cmp><cmp>2026-10-03</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>641</cmp><cmp>2026-10-03</cmp><cmp>2026-10-04</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>642</cmp><cmp>2026-10-04</cmp><cmp>2026-10-05</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>643</cmp><cmp>2026-10-05</cmp><cmp>2026-10-06</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>644</cmp><cmp>2026-10-06</cmp><cmp>2026-10-07</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>645</cmp><cmp>2026-10-07</cmp><cmp>2026-10-08</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>646</cmp><cmp>2026-10-08</cmp><cmp>2026-10-09</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>647</cmp><cmp>2026-10-09</cmp><cmp>2026-10-10</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>648</cmp><cmp>2026-10-10</cmp><cmp>2026-10-11</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>649</cmp><cmp>2026-10-11</cmp><cmp>2026-10-12</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>650</cmp><cmp>2026-10-12</cmp><cmp>2026-10-13</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>651</cmp><cmp>2026-10-13</cmp><cmp>2026-10-14</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>652</cmp><cmp>2026-10-14</cmp><cmp>2026-10-15</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>653</cmp><cmp>2026-10-15</cmp><cmp>2026-10-16</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>654</cmp><cmp>2026-10-16</cmp><cmp>2026-10-17</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>655</cmp><cmp>2026-10-17</cmp><cmp>2026-10-18</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>656</cmp><cmp>2026-10-18</cmp><cmp>2026-10-19</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>657</cmp><cmp>2026-10-19</cmp><cmp>2026-10-20</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>658</cmp><cmp>2026-10-20</cmp><cmp>2026-10-21</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>659</cmp><cmp>2026-10-21</cmp><cmp>2026-10-22</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>660</cmp><cmp>2026-10-22</cmp><cmp>2026-10-23</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>661</cmp><cmp>2026-10-23</cmp><cmp>2026-10-24</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>662</cmp><cmp>2026-10-24</cmp><cmp>2026-10-25</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>663</cmp><cmp>2026-10-25</cmp><cmp>2026-10-26</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>664</cmp><cmp>2026-10-26</cmp><cmp>2026-10-27</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>665</cmp><cmp>2026-10-27</cmp><cmp>2026-10-28</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>666</cmp><cmp>2026-10-28</cmp><cmp>2026-10-29</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>667</cmp><cmp>2026-10-29</cmp><cmp>2026-10-30</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>668</cmp><cmp>2026-10-30</cmp><cmp>2026-10-31</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>669</cmp><cmp>2026-10-31</cmp><cmp>2026-11-01</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>670</cmp><cmp>2026-11-01</cmp><cmp>2026-11-02</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>671</cmp><cmp>2026-11-02</cmp><cmp>2026-11-03</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>672</cmp><cmp>2026-11-03</cmp><cmp>2026-11-04</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>673</cmp><cmp>2026-11-04</cmp><cmp>2026-11-05</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>674</cmp><cmp>2026-11-05</cmp><cmp>2026-11-06</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>675</cmp><cmp>2026-11-06</cmp><cmp>2026-11-07</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>676</cmp><cmp>2026-11-07</cmp><cmp>2026-11-08</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>677</cmp><cmp>2026-11-08</cmp><cmp>2026-11-09</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>678</cmp><cmp>2026-11-09</cmp><cmp>2026-11-10</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>679</cmp><cmp>2026-11-10</cmp><cmp>2026-11-11</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>680</cmp><cmp>2026-11-11</cmp><cmp>2026-11-12</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>681</cmp><cmp>2026-11-12</cmp><cmp>2026-11-13</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>682</cmp><cmp>2026-11-13</cmp><cmp>2026-11-14</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>683</cmp><cmp>2026-11-14</cmp><cmp>2026-11-15</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>684</cmp><cmp>2026-11-15</cmp><cmp>2026-11-16</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>685</cmp><cmp>2026-11-16</cmp><cmp>2026-11-17</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>686</cmp><cmp>2026-11-17</cmp><cmp>2026-11-18</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>687</cmp><cmp>2026-11-18</cmp><cmp>2026-11-19</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>688</cmp><cmp>2026-11-19</cmp><cmp>2026-11-20</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>689</cmp><cmp>2026-11-20</cmp><cmp>2026-11-21</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>690</cmp><cmp>2026-11-21</cmp><cmp>2026-11-22</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>691</cmp><cmp>2026-11-22</cmp><cmp>2026-11-23</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>692</cmp><cmp>2026-11-23</cmp><cmp>2026-11-24</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>693</cmp><cmp>2026-11-24</cmp><cmp>2026-11-25</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>694</cmp><cmp>2026-11-25</cmp><cmp>2026-11-26</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>695</cmp><cmp>2026-11-26</cmp><cmp>2026-11-27</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>696</cmp><cmp>2026-11-27</cmp><cmp>2026-11-28</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>697</cmp><cmp>2026-11-28</cmp><cmp>2026-11-29</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>698</cmp><cmp>2026-11-29</cmp><cmp>2026-11-30</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>699</cmp><cmp>2026-11-30</cmp><cmp>2026-12-01</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>700</cmp><cmp>2026-12-01</cmp><cmp>2026-12-02</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>701</cmp><cmp>2026-12-02</cmp><cmp>2026-12-03</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>702</cmp><cmp>2026-12-03</cmp><cmp>2026-12-04</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>703</cmp><cmp>2026-12-04</cmp><cmp>2026-12-05</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>704</cmp><cmp>2026-12-05</cmp><cmp>2026-12-06</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>705</cmp><cmp>2026-12-06</cmp><cmp>2026-12-07</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>706</cmp><cmp>2026-12-07</cmp><cmp>2026-12-08</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>707</cmp><cmp>2026-12-08</cmp><cmp>2026-12-09</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>708</cmp><cmp>2026-12-09</cmp><cmp>2026-12-10</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>709</cmp><cmp>2026-12-10</cmp><cmp>2026-12-11</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>710</cmp><cmp>2026-12-11</cmp><cmp>2026-12-12</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>711</cmp><cmp>2026-12-12</cmp><cmp>2026-12-13</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>712</cmp><cmp>2026-12-13</cmp><cmp>2026-12-14</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>713</cmp><cmp>2026-12-14</cmp><cmp>2026-12-15</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>714</cmp><cmp>2026-12-15</cmp><cmp>2026-12-16</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>715</cmp><cmp>2026-12-16</cmp><cmp>2026-12-17</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>716</cmp><cmp>2026-12-17</cmp><cmp>2026-12-18</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>717</cmp><cmp>2026-12-18</cmp><cmp>2026-12-19</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>718</cmp><cmp>2026-12-19</cmp><cmp>2026-12-20</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>719</cmp><cmp>2026-12-20</cmp><cmp>2026-12-21</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>720</cmp><cmp>2026-12-21</cmp><cmp>2026-12-22</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>721</cmp><cmp>2026-12-22</cmp><cmp>2026-12-23</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>722</cmp><cmp>2026-12-23</cmp><cmp>2026-12-24</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>723</cmp><cmp>2026-12-24</cmp><cmp>2026-12-25</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>724</cmp><cmp>2026-12-25</cmp><cmp>2026-12-26</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>725</cmp><cmp>2026-12-26</cmp><cmp>2026-12-27</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>726</cmp><cmp>2026-12-27</cmp><cmp>2026-12-28</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>727</cmp><cmp>2026-12-28</cmp><cmp>2026-12-29</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>728</cmp><cmp>2026-12-29</cmp><cmp>2026-12-30</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>729</cmp><cmp>2026-12-30</cmp><cmp>2026-12-31</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>730</cmp><cmp>2026-12-31</cmp><cmp>2027-01-01</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
</righetabella>
</tabella>
<tabella>
<nometabella>ntariffe2025</nometabella>
<colonnetabella>
<nomecolonna>idntariffe</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>nomecostoagg</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>tipo_ca</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>valore_ca</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>valore_perc_ca</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>arrotonda_ca</nomecolonna>
<tipocolonna>4</tipocolonna>
<nomecolonna>tasseperc_ca</nomecolonna>
<tipocolonna>4</tipocolonna>
<nomecolonna>associasett_ca</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>numsett_ca</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>moltiplica_ca</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>periodipermessi_ca</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>beniinv_ca</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>appincompatibili_ca</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>variazione_ca</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>mostra_ca</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>categoria_ca</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>letto_ca</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>numlimite_ca</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>regoleassegna_ca</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>utente_inserimento</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>tariffa1</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>tariffa2</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>tariffa3</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>tariffa4</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>tariffa5</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>tariffa6</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>tariffa7</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>tariffa8</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>tariffa9</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>tariffa10</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>tariffa11</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>tariffa12</nomecolonna>
<tipocolonna>252</tipocolonna>
</colonnetabella>
<righetabella>
<riga><cmp>1</cmp><cmp>8</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp>11</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>2</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>3</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>4</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>5</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
<riga><cmp>6</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
</righetabella>
</tabella>
<tabella>
<nometabella>regole2025</nometabella>
<colonnetabella>
<nomecolonna>idregole</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>app_agenzia</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>tariffa_chiusa</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>tariffa_per_app</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>tariffa_per_utente</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>tariffa_per_persone</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>tariffa_commissioni</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>iddatainizio</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>iddatafine</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>motivazione</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>motivazione2</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>motivazione3</nomecolonna>
<tipocolonna>252</tipocolonna>
</colonnetabella>
<righetabella>
</righetabella>
</tabella>
<tabella>
<nometabella>soldi2025</nometabella>
<colonnetabella>
<nomecolonna>idsoldi</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>motivazione</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>id_pagamento</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>metodo_pagamento</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>note</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>saldo_prenota</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>saldo_cassa</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>soldi_prima</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>valuta</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>saldo_valuta</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>data_transazione</nomecolonna>
<tipocolonna>12</tipocolonna>
<nomecolonna>data_modifica</nomecolonna>
<tipocolonna>12</tipocolonna>
<nomecolonna>data_inserimento</nomecolonna>
<tipocolonna>12</tipocolonna>
<nomecolonna>utente_inserimento</nomecolonna>
<tipocolonna>3</tipocolonna>
</colonnetabella>
<righetabella>
<riga><cmp>1</cmp><cmp>soldi_prenotazioni_cancellate</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp>0</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
</righetabella>
</tabella>
<tabella>
<nometabella>costi2025</nometabella>
<colonnetabella>
<nomecolonna>idcosti</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>nome_costo</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>val_costo</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>tipo_costo</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>valuta</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>costo_valuta</nomecolonna>
<tipocolonna>5</tipocolonna>
<nomecolonna>nome_cassa</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>persona_costo</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>provenienza_costo</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>id_pagamento</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>metodo_pagamento</nomecolonna>
<tipocolonna>252</tipocolonna>
<nomecolonna>data_transazione</nomecolonna>
<tipocolonna>12</tipocolonna>
<nomecolonna>data_modifica</nomecolonna>
<tipocolonna>12</tipocolonna>
<nomecolonna>datainserimento</nomecolonna>
<tipocolonna>12</tipocolonna>
<nomecolonna>hostinserimento</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>utente_inserimento</nomecolonna>
<tipocolonna>3</tipocolonna>
</colonnetabella>
<righetabella>
<riga><cmp>0</cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp><cmp></cmp></riga>
</righetabella>
</tabella>
</database>
</backup>